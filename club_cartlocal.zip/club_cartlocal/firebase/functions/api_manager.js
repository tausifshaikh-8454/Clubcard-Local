const axios = require("axios").default;
const qs = require("qs");

/// Start SendEmail Api Group Code

function createSendEmailApiGroup() {
  return {
    baseUrl: `https://api.sendgrid.com/v3`,
    headers: {
      Authorization: `Bearer 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`,
      "Content-Type": `application/json`,
    },
  };
}

async function _sendEmailInGroupCall(context, ffVariables) {
  var toemail = ffVariables["toemail"];
  var subject = ffVariables["subject"];
  var body = ffVariables["body"];
  var recipientName = ffVariables["recipientName"];
  var signature = ffVariables["signature"];
  const sendEmailApiGroup = createSendEmailApiGroup();

  var url = `${sendEmailApiGroup.baseUrl}/mail/send`;
  var headers = {
    Authorization: `Bearer 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`,
    "Content-Type": `application/json`,
  };
  var params = {};
  var ffApiRequestBody = `
{
  "personalizations": [
    {
      "to": [
        {
          "email": "${escapeStringForJson(toemail)}",
          "name": "${escapeStringForJson(recipientName)}"
        }
      ],
      "subject": "${escapeStringForJson(subject)}"
    }
  ],
  "content": [
    {
      "type": "text/html",
      "value": "<p>Dear <strong>${escapeStringForJson(recipientName)}</strong>,</p><br><p>${escapeStringForJson(body)}</p><br> <img src='${escapeStringForJson(signature)}' alt='Signature' width='300' />"
    }
  ],
  "from": {
    "email": "hello@clubcardlocal.com",
    "name": "Clubcard Local"
  },
  "reply_to": {
    "email": "hello@clubcardlocal.com",
    "name": "Clubcard Local"
  }
}`;

  return makeApiRequest({
    method: "post",
    url,
    headers,
    params,
    body: createBody({
      headers,
      params,
      body: ffApiRequestBody,
      bodyType: "JSON",
    }),
    returnBody: true,
    isStreamingApi: false,
  });
}

/// End SendEmail Api Group Code

/// Helper functions to route to the appropriate API Call.

async function makeApiCall(context, data) {
  var callName = data["callName"] || "";
  var variables = data["variables"] || {};

  const callMap = {
    SendEmailInGroupCall: _sendEmailInGroupCall,
  };

  if (!(callName in callMap)) {
    return {
      statusCode: 400,
      error: `API Call "${callName}" not defined as private API.`,
    };
  }

  var apiCall = callMap[callName];
  var response = await apiCall(context, variables);
  return response;
}

async function makeApiRequest({
  method,
  url,
  headers,
  params,
  body,
  returnBody,
  isStreamingApi,
}) {
  return axios
    .request({
      method: method,
      url: url,
      headers: headers,
      params: params,
      responseType: isStreamingApi ? "stream" : "json",
      ...(body && { data: body }),
    })
    .then((response) => {
      return {
        statusCode: response.status,
        headers: response.headers,
        ...(returnBody && { body: response.data }),
        isStreamingApi: isStreamingApi,
      };
    })
    .catch(function (error) {
      return {
        statusCode: error.response.status,
        headers: error.response.headers,
        ...(returnBody && { body: error.response.data }),
        error: error.message,
      };
    });
}

const _unauthenticatedResponse = {
  statusCode: 401,
  headers: {},
  error: "API call requires authentication",
};

function createBody({ headers, params, body, bodyType }) {
  switch (bodyType) {
    case "JSON":
      headers["Content-Type"] = "application/json";
      return body;
    case "TEXT":
      headers["Content-Type"] = "text/plain";
      return body;
    case "X_WWW_FORM_URL_ENCODED":
      headers["Content-Type"] = "application/x-www-form-urlencoded";
      return qs.stringify(params);
  }
}
function escapeStringForJson(val) {
  if (typeof val !== "string") {
    return val;
  }
  return val
    .replace(/[\\]/g, "\\\\")
    .replace(/["]/g, '\\"')
    .replace(/[\n]/g, "\\n")
    .replace(/[\t]/g, "\\t");
}

module.exports = { makeApiCall };
