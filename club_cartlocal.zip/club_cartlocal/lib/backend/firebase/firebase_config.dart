import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyACt58k9cdXwr6dq0-D96aFkoz1YB9P0Q0",
            authDomain: "clubcartlocal.firebaseapp.com",
            projectId: "clubcartlocal",
            storageBucket: "clubcartlocal.appspot.com",
            messagingSenderId: "114675121875",
            appId: "1:114675121875:web:36a3918c2b51e913c95e26",
            measurementId: "G-RXX4FPV207"));
  } else {
    await Firebase.initializeApp();
  }
}
