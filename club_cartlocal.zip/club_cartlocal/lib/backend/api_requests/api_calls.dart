import 'dart:convert';
import 'dart:typed_data';
import '../cloud_functions/cloud_functions.dart';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start stripe Group Code

class StripeGroup {
  static String getBaseUrl() => 'https://api.stripe.com/v1';
  static Map<String, String> headers = {
    'Authorization':
        'Bearer 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',
    'content-type': 'application/x-www-form-urlencoded',
  };
  static CheckOutSessionsCall checkOutSessionsCall = CheckOutSessionsCall();
  static CreateCustomerCall createCustomerCall = CreateCustomerCall();
  static RetriveSubscriptionCall retriveSubscriptionCall =
      RetriveSubscriptionCall();
  static UpdateSubscriptionCall updateSubscriptionCall =
      UpdateSubscriptionCall();
  static BillingportalSessionCall billingportalSessionCall =
      BillingportalSessionCall();
  static CreateSusbscriptionfreeCall createSusbscriptionfreeCall =
      CreateSusbscriptionfreeCall();
}

class CheckOutSessionsCall {
  Future<ApiCallResponse> call({
    String? mode = 'subscription',
    String? successUrl = '',
    String? cancelUrl = '',
    String? priceID = '',
    int? quantity = 1,
    String? key =
        'sk_test_51PZWfGL3aBEbReILgdeqafsmf4bR2vTJIuB3B00SrCYmtt3hhmmWZVZYcn9I3SGJVPreOYpVgU1Px6h9cHZBucXS00EvYs7an7',
    String? customer = '',
  }) async {
    final baseUrl = StripeGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'checkOutSessions',
      apiUrl: '${baseUrl}/checkout/sessions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'content-type': 'application/x-www-form-urlencoded',
      },
      params: {
        'mode': mode,
        'success_url': successUrl,
        'cancel_url': cancelUrl,
        'line_items[0][price]': priceID,
        'line_items[0][quantity]': quantity,
        'key': key,
        'customer': customer,
        'saved_payment_method_options[payment_method_save]': "enabled",
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? sessionid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.id''',
      ));
  int? amount(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.amount_subtotal''',
      ));
  String? paymentstatus(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.payment_status''',
      ));
  String? url(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.url''',
      ));
  String? paymethod(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.payment_method_types''',
      ));
  String? custid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.customer''',
      ));
}

class CreateCustomerCall {
  Future<ApiCallResponse> call({
    String? email = '',
    String? name = '',
  }) async {
    final baseUrl = StripeGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'CreateCustomer',
      apiUrl: '${baseUrl}/customers',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'content-type': 'application/x-www-form-urlencoded',
      },
      params: {
        'email': email,
        'name': name,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? custid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.id''',
      ));
  String? custEmail(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.email''',
      ));
  String? custname(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.name''',
      ));
}

class RetriveSubscriptionCall {
  Future<ApiCallResponse> call({
    String? customer = '',
  }) async {
    final baseUrl = StripeGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'retrive subscription',
      apiUrl: '${baseUrl}/subscriptions',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer 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',
        'content-type': 'application/x-www-form-urlencoded',
      },
      params: {
        'customer': customer,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? subsid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].id''',
      ));
  String? custid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].customer''',
      ));
  String? defaultpaymentmethod(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.data[:].default_payment_method''',
      ));
  String? itemid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].items.data[:].id''',
      ));
  String? priceid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].items.data[:].plan.id''',
      ));
  String? planamount(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].items.data[:].plan.amount_decimal''',
      ));
  int? periodstarts(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.data[:].current_period_start''',
      ));
  int? periodend(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.data[:].current_period_end''',
      ));
  String? planInterval(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].items.data[:].plan.interval''',
      ));
  String? subsstatus(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].status''',
      ));
  dynamic? orderid(dynamic response) => getJsonField(
        response,
        r'''$.data[:].metadata''',
      );
  String? productId(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data[:].items.data[:].plan.product''',
      ));
  int? planAmount(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.data[:].items.data[:].plan.amount''',
      ));
}

class UpdateSubscriptionCall {
  Future<ApiCallResponse> call({
    String? itemID = '',
    String? priceID = '',
    String? upDwnSub = '',
  }) async {
    final baseUrl = StripeGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'UpdateSubscription',
      apiUrl: '${baseUrl}/subscriptions/${upDwnSub}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'content-type': 'application/x-www-form-urlencoded',
      },
      params: {
        'items[0][id]': itemID,
        'items[0][price]': priceID,
        'proration_behavior': "always_invoice",
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  List<String>? priceId(dynamic response) => (getJsonField(
        response,
        r'''$.items.data[:].plan.id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  String? paymentmethod(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.default_payment_method''',
      ));
  String? priceid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.items.data[:].price.id''',
      ));
  String? productId(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.items.data[:].plan.product''',
      ));
  String? planAmount(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.plan.amount_decimal''',
      ));
  String? subsStatus(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
  String? orderid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.metadata.order_id''',
      ));
}

class BillingportalSessionCall {
  Future<ApiCallResponse> call({
    String? customer = '',
    String? subscriptionUpdate = '',
  }) async {
    final baseUrl = StripeGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'billingportal session',
      apiUrl: '${baseUrl}/billing_portal/',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'content-type': 'application/x-www-form-urlencoded',
      },
      params: {
        'customer': customer,
        'subscription_update': subscriptionUpdate,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CreateSusbscriptionfreeCall {
  Future<ApiCallResponse> call({
    String? customer = '',
    String? priceID = 'price_1QQMYgL3aBEbReILFcntUECp',
  }) async {
    final baseUrl = StripeGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'createSusbscriptionfree',
      apiUrl: '${baseUrl}/subscriptions',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer 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',
        'content-type': 'application/x-www-form-urlencoded',
      },
      params: {
        'customer': customer,
        'items[0][price]': priceID,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? subscriptionid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.id''',
      ));
  String? itemid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.items.data[:].id''',
      ));
  String? priceid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.items.data[:].plan.id''',
      ));
  String? productid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.items.data[:].plan.product''',
      ));
  String? custid(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.customer''',
      ));
}

/// End stripe Group Code

/// Start SendEmail Api Group Code

class SendEmailApiGroup {
  static SendEmailInGroupCall sendEmailInGroupCall = SendEmailInGroupCall();
}

class SendEmailInGroupCall {
  Future<ApiCallResponse> call({
    String? toemail = '',
    String? subject = '',
    String? body = '',
    String? recipientName = '',
    String? signature = '',
  }) async {
    final response = await makeCloudCall(
      _kPrivateApiFunctionName,
      {
        'callName': 'SendEmailInGroupCall',
        'variables': {
          'toemail': toemail,
          'subject': subject,
          'body': body,
          'recipientName': recipientName,
          'signature': signature,
        },
      },
    );
    return ApiCallResponse.fromCloudCallResponse(response);
  }
}

/// End SendEmail Api Group Code

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
