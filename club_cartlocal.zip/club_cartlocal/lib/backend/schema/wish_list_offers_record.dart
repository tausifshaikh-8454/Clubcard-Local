import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class WishListOffersRecord extends FirestoreRecord {
  WishListOffersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "wishlisted_offer" field.
  DocumentReference? _wishlistedOffer;
  DocumentReference? get wishlistedOffer => _wishlistedOffer;
  bool hasWishlistedOffer() => _wishlistedOffer != null;

  // "wishlisted_date" field.
  DateTime? _wishlistedDate;
  DateTime? get wishlistedDate => _wishlistedDate;
  bool hasWishlistedDate() => _wishlistedDate != null;

  // "Cust_ref" field.
  DocumentReference? _custRef;
  DocumentReference? get custRef => _custRef;
  bool hasCustRef() => _custRef != null;

  // "releated_vendID" field.
  String? _releatedVendID;
  String get releatedVendID => _releatedVendID ?? '';
  bool hasReleatedVendID() => _releatedVendID != null;

  // "cust_id" field.
  String? _custId;
  String get custId => _custId ?? '';
  bool hasCustId() => _custId != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _wishlistedOffer = snapshotData['wishlisted_offer'] as DocumentReference?;
    _wishlistedDate = snapshotData['wishlisted_date'] as DateTime?;
    _custRef = snapshotData['Cust_ref'] as DocumentReference?;
    _releatedVendID = snapshotData['releated_vendID'] as String?;
    _custId = snapshotData['cust_id'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('wishList_offers')
          : FirebaseFirestore.instance.collectionGroup('wishList_offers');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('wishList_offers').doc(id);

  static Stream<WishListOffersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WishListOffersRecord.fromSnapshot(s));

  static Future<WishListOffersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WishListOffersRecord.fromSnapshot(s));

  static WishListOffersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WishListOffersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WishListOffersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WishListOffersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WishListOffersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WishListOffersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWishListOffersRecordData({
  DocumentReference? wishlistedOffer,
  DateTime? wishlistedDate,
  DocumentReference? custRef,
  String? releatedVendID,
  String? custId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'wishlisted_offer': wishlistedOffer,
      'wishlisted_date': wishlistedDate,
      'Cust_ref': custRef,
      'releated_vendID': releatedVendID,
      'cust_id': custId,
    }.withoutNulls,
  );

  return firestoreData;
}

class WishListOffersRecordDocumentEquality
    implements Equality<WishListOffersRecord> {
  const WishListOffersRecordDocumentEquality();

  @override
  bool equals(WishListOffersRecord? e1, WishListOffersRecord? e2) {
    return e1?.wishlistedOffer == e2?.wishlistedOffer &&
        e1?.wishlistedDate == e2?.wishlistedDate &&
        e1?.custRef == e2?.custRef &&
        e1?.releatedVendID == e2?.releatedVendID &&
        e1?.custId == e2?.custId;
  }

  @override
  int hash(WishListOffersRecord? e) => const ListEquality().hash([
        e?.wishlistedOffer,
        e?.wishlistedDate,
        e?.custRef,
        e?.releatedVendID,
        e?.custId
      ]);

  @override
  bool isValidKey(Object? o) => o is WishListOffersRecord;
}
