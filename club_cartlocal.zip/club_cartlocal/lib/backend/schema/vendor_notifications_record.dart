import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VendorNotificationsRecord extends FirestoreRecord {
  VendorNotificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Ven_ref" field.
  DocumentReference? _venRef;
  DocumentReference? get venRef => _venRef;
  bool hasVenRef() => _venRef != null;

  // "notifi" field.
  String? _notifi;
  String get notifi => _notifi ?? '';
  bool hasNotifi() => _notifi != null;

  // "notifi_date" field.
  DateTime? _notifiDate;
  DateTime? get notifiDate => _notifiDate;
  bool hasNotifiDate() => _notifiDate != null;

  // "custref" field.
  List<DocumentReference>? _custref;
  List<DocumentReference> get custref => _custref ?? const [];
  bool hasCustref() => _custref != null;

  void _initializeFields() {
    _venRef = snapshotData['Ven_ref'] as DocumentReference?;
    _notifi = snapshotData['notifi'] as String?;
    _notifiDate = snapshotData['notifi_date'] as DateTime?;
    _custref = getDataList(snapshotData['custref']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('VendorNotifications');

  static Stream<VendorNotificationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VendorNotificationsRecord.fromSnapshot(s));

  static Future<VendorNotificationsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => VendorNotificationsRecord.fromSnapshot(s));

  static VendorNotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VendorNotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VendorNotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VendorNotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VendorNotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VendorNotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVendorNotificationsRecordData({
  DocumentReference? venRef,
  String? notifi,
  DateTime? notifiDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Ven_ref': venRef,
      'notifi': notifi,
      'notifi_date': notifiDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class VendorNotificationsRecordDocumentEquality
    implements Equality<VendorNotificationsRecord> {
  const VendorNotificationsRecordDocumentEquality();

  @override
  bool equals(VendorNotificationsRecord? e1, VendorNotificationsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.venRef == e2?.venRef &&
        e1?.notifi == e2?.notifi &&
        e1?.notifiDate == e2?.notifiDate &&
        listEquality.equals(e1?.custref, e2?.custref);
  }

  @override
  int hash(VendorNotificationsRecord? e) => const ListEquality()
      .hash([e?.venRef, e?.notifi, e?.notifiDate, e?.custref]);

  @override
  bool isValidKey(Object? o) => o is VendorNotificationsRecord;
}
