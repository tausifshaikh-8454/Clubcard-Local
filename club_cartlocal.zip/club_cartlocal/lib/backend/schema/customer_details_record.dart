import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CustomerDetailsRecord extends FirestoreRecord {
  CustomerDetailsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "cust_userid" field.
  String? _custUserid;
  String get custUserid => _custUserid ?? '';
  bool hasCustUserid() => _custUserid != null;

  // "cust_username" field.
  String? _custUsername;
  String get custUsername => _custUsername ?? '';
  bool hasCustUsername() => _custUsername != null;

  // "cust_email" field.
  String? _custEmail;
  String get custEmail => _custEmail ?? '';
  bool hasCustEmail() => _custEmail != null;

  // "cust_phone" field.
  String? _custPhone;
  String get custPhone => _custPhone ?? '';
  bool hasCustPhone() => _custPhone != null;

  // "cust_type" field.
  String? _custType;
  String get custType => _custType ?? '';
  bool hasCustType() => _custType != null;

  // "cust_pass" field.
  String? _custPass;
  String get custPass => _custPass ?? '';
  bool hasCustPass() => _custPass != null;

  // "cust_profile" field.
  String? _custProfile;
  String get custProfile => _custProfile ?? '';
  bool hasCustProfile() => _custProfile != null;

  // "cust_created_date" field.
  DateTime? _custCreatedDate;
  DateTime? get custCreatedDate => _custCreatedDate;
  bool hasCustCreatedDate() => _custCreatedDate != null;

  // "cust_Surname" field.
  String? _custSurname;
  String get custSurname => _custSurname ?? '';
  bool hasCustSurname() => _custSurname != null;

  void _initializeFields() {
    _custUserid = snapshotData['cust_userid'] as String?;
    _custUsername = snapshotData['cust_username'] as String?;
    _custEmail = snapshotData['cust_email'] as String?;
    _custPhone = snapshotData['cust_phone'] as String?;
    _custType = snapshotData['cust_type'] as String?;
    _custPass = snapshotData['cust_pass'] as String?;
    _custProfile = snapshotData['cust_profile'] as String?;
    _custCreatedDate = snapshotData['cust_created_date'] as DateTime?;
    _custSurname = snapshotData['cust_Surname'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('customer-details');

  static Stream<CustomerDetailsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CustomerDetailsRecord.fromSnapshot(s));

  static Future<CustomerDetailsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CustomerDetailsRecord.fromSnapshot(s));

  static CustomerDetailsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CustomerDetailsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CustomerDetailsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CustomerDetailsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CustomerDetailsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CustomerDetailsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCustomerDetailsRecordData({
  String? custUserid,
  String? custUsername,
  String? custEmail,
  String? custPhone,
  String? custType,
  String? custPass,
  String? custProfile,
  DateTime? custCreatedDate,
  String? custSurname,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'cust_userid': custUserid,
      'cust_username': custUsername,
      'cust_email': custEmail,
      'cust_phone': custPhone,
      'cust_type': custType,
      'cust_pass': custPass,
      'cust_profile': custProfile,
      'cust_created_date': custCreatedDate,
      'cust_Surname': custSurname,
    }.withoutNulls,
  );

  return firestoreData;
}

class CustomerDetailsRecordDocumentEquality
    implements Equality<CustomerDetailsRecord> {
  const CustomerDetailsRecordDocumentEquality();

  @override
  bool equals(CustomerDetailsRecord? e1, CustomerDetailsRecord? e2) {
    return e1?.custUserid == e2?.custUserid &&
        e1?.custUsername == e2?.custUsername &&
        e1?.custEmail == e2?.custEmail &&
        e1?.custPhone == e2?.custPhone &&
        e1?.custType == e2?.custType &&
        e1?.custPass == e2?.custPass &&
        e1?.custProfile == e2?.custProfile &&
        e1?.custCreatedDate == e2?.custCreatedDate &&
        e1?.custSurname == e2?.custSurname;
  }

  @override
  int hash(CustomerDetailsRecord? e) => const ListEquality().hash([
        e?.custUserid,
        e?.custUsername,
        e?.custEmail,
        e?.custPhone,
        e?.custType,
        e?.custPass,
        e?.custProfile,
        e?.custCreatedDate,
        e?.custSurname
      ]);

  @override
  bool isValidKey(Object? o) => o is CustomerDetailsRecord;
}
