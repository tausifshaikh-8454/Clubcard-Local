import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FollowedUserRecord extends FirestoreRecord {
  FollowedUserRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Cust_follwed" field.
  DocumentReference? _custFollwed;
  DocumentReference? get custFollwed => _custFollwed;
  bool hasCustFollwed() => _custFollwed != null;

  // "Vend_ref" field.
  DocumentReference? _vendRef;
  DocumentReference? get vendRef => _vendRef;
  bool hasVendRef() => _vendRef != null;

  // "Follwed_date" field.
  DateTime? _follwedDate;
  DateTime? get follwedDate => _follwedDate;
  bool hasFollwedDate() => _follwedDate != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _custFollwed = snapshotData['Cust_follwed'] as DocumentReference?;
    _vendRef = snapshotData['Vend_ref'] as DocumentReference?;
    _follwedDate = snapshotData['Follwed_date'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Followed_user')
          : FirebaseFirestore.instance.collectionGroup('Followed_user');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Followed_user').doc(id);

  static Stream<FollowedUserRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FollowedUserRecord.fromSnapshot(s));

  static Future<FollowedUserRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FollowedUserRecord.fromSnapshot(s));

  static FollowedUserRecord fromSnapshot(DocumentSnapshot snapshot) =>
      FollowedUserRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FollowedUserRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FollowedUserRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FollowedUserRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FollowedUserRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFollowedUserRecordData({
  DocumentReference? custFollwed,
  DocumentReference? vendRef,
  DateTime? follwedDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Cust_follwed': custFollwed,
      'Vend_ref': vendRef,
      'Follwed_date': follwedDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class FollowedUserRecordDocumentEquality
    implements Equality<FollowedUserRecord> {
  const FollowedUserRecordDocumentEquality();

  @override
  bool equals(FollowedUserRecord? e1, FollowedUserRecord? e2) {
    return e1?.custFollwed == e2?.custFollwed &&
        e1?.vendRef == e2?.vendRef &&
        e1?.follwedDate == e2?.follwedDate;
  }

  @override
  int hash(FollowedUserRecord? e) =>
      const ListEquality().hash([e?.custFollwed, e?.vendRef, e?.follwedDate]);

  @override
  bool isValidKey(Object? o) => o is FollowedUserRecord;
}
