import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VendEventRecord extends FirestoreRecord {
  VendEventRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "eventName" field.
  String? _eventName;
  String get eventName => _eventName ?? '';
  bool hasEventName() => _eventName != null;

  // "EventDescription" field.
  String? _eventDescription;
  String get eventDescription => _eventDescription ?? '';
  bool hasEventDescription() => _eventDescription != null;

  // "EventImage" field.
  String? _eventImage;
  String get eventImage => _eventImage ?? '';
  bool hasEventImage() => _eventImage != null;

  // "ownerref" field.
  DocumentReference? _ownerref;
  DocumentReference? get ownerref => _ownerref;
  bool hasOwnerref() => _ownerref != null;

  // "starttime" field.
  List<DateTime>? _starttime;
  List<DateTime> get starttime => _starttime ?? const [];
  bool hasStarttime() => _starttime != null;

  // "endtime" field.
  List<DateTime>? _endtime;
  List<DateTime> get endtime => _endtime ?? const [];
  bool hasEndtime() => _endtime != null;

  // "regularprice" field.
  int? _regularprice;
  int get regularprice => _regularprice ?? 0;
  bool hasRegularprice() => _regularprice != null;

  // "discountedprice" field.
  int? _discountedprice;
  int get discountedprice => _discountedprice ?? 0;
  bool hasDiscountedprice() => _discountedprice != null;

  // "vendoffertags" field.
  List<String>? _vendoffertags;
  List<String> get vendoffertags => _vendoffertags ?? const [];
  bool hasVendoffertags() => _vendoffertags != null;

  // "vend_name" field.
  String? _vendName;
  String get vendName => _vendName ?? '';
  bool hasVendName() => _vendName != null;

  // "vend_appoint_no" field.
  String? _vendAppointNo;
  String get vendAppointNo => _vendAppointNo ?? '';
  bool hasVendAppointNo() => _vendAppointNo != null;

  // "event_createdDate" field.
  DateTime? _eventCreatedDate;
  DateTime? get eventCreatedDate => _eventCreatedDate;
  bool hasEventCreatedDate() => _eventCreatedDate != null;

  // "evntStatus" field.
  String? _evntStatus;
  String get evntStatus => _evntStatus ?? '';
  bool hasEvntStatus() => _evntStatus != null;

  void _initializeFields() {
    _eventName = snapshotData['eventName'] as String?;
    _eventDescription = snapshotData['EventDescription'] as String?;
    _eventImage = snapshotData['EventImage'] as String?;
    _ownerref = snapshotData['ownerref'] as DocumentReference?;
    _starttime = getDataList(snapshotData['starttime']);
    _endtime = getDataList(snapshotData['endtime']);
    _regularprice = castToType<int>(snapshotData['regularprice']);
    _discountedprice = castToType<int>(snapshotData['discountedprice']);
    _vendoffertags = getDataList(snapshotData['vendoffertags']);
    _vendName = snapshotData['vend_name'] as String?;
    _vendAppointNo = snapshotData['vend_appoint_no'] as String?;
    _eventCreatedDate = snapshotData['event_createdDate'] as DateTime?;
    _evntStatus = snapshotData['evntStatus'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('VendEvent');

  static Stream<VendEventRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VendEventRecord.fromSnapshot(s));

  static Future<VendEventRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VendEventRecord.fromSnapshot(s));

  static VendEventRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VendEventRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VendEventRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VendEventRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VendEventRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VendEventRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVendEventRecordData({
  String? eventName,
  String? eventDescription,
  String? eventImage,
  DocumentReference? ownerref,
  int? regularprice,
  int? discountedprice,
  String? vendName,
  String? vendAppointNo,
  DateTime? eventCreatedDate,
  String? evntStatus,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'eventName': eventName,
      'EventDescription': eventDescription,
      'EventImage': eventImage,
      'ownerref': ownerref,
      'regularprice': regularprice,
      'discountedprice': discountedprice,
      'vend_name': vendName,
      'vend_appoint_no': vendAppointNo,
      'event_createdDate': eventCreatedDate,
      'evntStatus': evntStatus,
    }.withoutNulls,
  );

  return firestoreData;
}

class VendEventRecordDocumentEquality implements Equality<VendEventRecord> {
  const VendEventRecordDocumentEquality();

  @override
  bool equals(VendEventRecord? e1, VendEventRecord? e2) {
    const listEquality = ListEquality();
    return e1?.eventName == e2?.eventName &&
        e1?.eventDescription == e2?.eventDescription &&
        e1?.eventImage == e2?.eventImage &&
        e1?.ownerref == e2?.ownerref &&
        listEquality.equals(e1?.starttime, e2?.starttime) &&
        listEquality.equals(e1?.endtime, e2?.endtime) &&
        e1?.regularprice == e2?.regularprice &&
        e1?.discountedprice == e2?.discountedprice &&
        listEquality.equals(e1?.vendoffertags, e2?.vendoffertags) &&
        e1?.vendName == e2?.vendName &&
        e1?.vendAppointNo == e2?.vendAppointNo &&
        e1?.eventCreatedDate == e2?.eventCreatedDate &&
        e1?.evntStatus == e2?.evntStatus;
  }

  @override
  int hash(VendEventRecord? e) => const ListEquality().hash([
        e?.eventName,
        e?.eventDescription,
        e?.eventImage,
        e?.ownerref,
        e?.starttime,
        e?.endtime,
        e?.regularprice,
        e?.discountedprice,
        e?.vendoffertags,
        e?.vendName,
        e?.vendAppointNo,
        e?.eventCreatedDate,
        e?.evntStatus
      ]);

  @override
  bool isValidKey(Object? o) => o is VendEventRecord;
}
