import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReleaseNotificationRecord extends FirestoreRecord {
  ReleaseNotificationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "noti_info" field.
  String? _notiInfo;
  String get notiInfo => _notiInfo ?? '';
  bool hasNotiInfo() => _notiInfo != null;

  // "noti_created" field.
  DateTime? _notiCreated;
  DateTime? get notiCreated => _notiCreated;
  bool hasNotiCreated() => _notiCreated != null;

  // "created_by" field.
  DocumentReference? _createdBy;
  DocumentReference? get createdBy => _createdBy;
  bool hasCreatedBy() => _createdBy != null;

  // "vend_id" field.
  String? _vendId;
  String get vendId => _vendId ?? '';
  bool hasVendId() => _vendId != null;

  // "offer_image" field.
  String? _offerImage;
  String get offerImage => _offerImage ?? '';
  bool hasOfferImage() => _offerImage != null;

  // "offer_ref" field.
  DocumentReference? _offerRef;
  DocumentReference? get offerRef => _offerRef;
  bool hasOfferRef() => _offerRef != null;

  // "offer_read_by" field.
  List<DocumentReference>? _offerReadBy;
  List<DocumentReference> get offerReadBy => _offerReadBy ?? const [];
  bool hasOfferReadBy() => _offerReadBy != null;

  // "offer_name" field.
  String? _offerName;
  String get offerName => _offerName ?? '';
  bool hasOfferName() => _offerName != null;

  // "Vend_name" field.
  String? _vendName;
  String get vendName => _vendName ?? '';
  bool hasVendName() => _vendName != null;

  // "offer_start_date" field.
  DateTime? _offerStartDate;
  DateTime? get offerStartDate => _offerStartDate;
  bool hasOfferStartDate() => _offerStartDate != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _notiInfo = snapshotData['noti_info'] as String?;
    _notiCreated = snapshotData['noti_created'] as DateTime?;
    _createdBy = snapshotData['created_by'] as DocumentReference?;
    _vendId = snapshotData['vend_id'] as String?;
    _offerImage = snapshotData['offer_image'] as String?;
    _offerRef = snapshotData['offer_ref'] as DocumentReference?;
    _offerReadBy = getDataList(snapshotData['offer_read_by']);
    _offerName = snapshotData['offer_name'] as String?;
    _vendName = snapshotData['Vend_name'] as String?;
    _offerStartDate = snapshotData['offer_start_date'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Release_Notification')
          : FirebaseFirestore.instance.collectionGroup('Release_Notification');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Release_Notification').doc(id);

  static Stream<ReleaseNotificationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReleaseNotificationRecord.fromSnapshot(s));

  static Future<ReleaseNotificationRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => ReleaseNotificationRecord.fromSnapshot(s));

  static ReleaseNotificationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReleaseNotificationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReleaseNotificationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReleaseNotificationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReleaseNotificationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReleaseNotificationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReleaseNotificationRecordData({
  String? notiInfo,
  DateTime? notiCreated,
  DocumentReference? createdBy,
  String? vendId,
  String? offerImage,
  DocumentReference? offerRef,
  String? offerName,
  String? vendName,
  DateTime? offerStartDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'noti_info': notiInfo,
      'noti_created': notiCreated,
      'created_by': createdBy,
      'vend_id': vendId,
      'offer_image': offerImage,
      'offer_ref': offerRef,
      'offer_name': offerName,
      'Vend_name': vendName,
      'offer_start_date': offerStartDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReleaseNotificationRecordDocumentEquality
    implements Equality<ReleaseNotificationRecord> {
  const ReleaseNotificationRecordDocumentEquality();

  @override
  bool equals(ReleaseNotificationRecord? e1, ReleaseNotificationRecord? e2) {
    const listEquality = ListEquality();
    return e1?.notiInfo == e2?.notiInfo &&
        e1?.notiCreated == e2?.notiCreated &&
        e1?.createdBy == e2?.createdBy &&
        e1?.vendId == e2?.vendId &&
        e1?.offerImage == e2?.offerImage &&
        e1?.offerRef == e2?.offerRef &&
        listEquality.equals(e1?.offerReadBy, e2?.offerReadBy) &&
        e1?.offerName == e2?.offerName &&
        e1?.vendName == e2?.vendName &&
        e1?.offerStartDate == e2?.offerStartDate;
  }

  @override
  int hash(ReleaseNotificationRecord? e) => const ListEquality().hash([
        e?.notiInfo,
        e?.notiCreated,
        e?.createdBy,
        e?.vendId,
        e?.offerImage,
        e?.offerRef,
        e?.offerReadBy,
        e?.offerName,
        e?.vendName,
        e?.offerStartDate
      ]);

  @override
  bool isValidKey(Object? o) => o is ReleaseNotificationRecord;
}
