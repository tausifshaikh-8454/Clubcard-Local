import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BookingsRecord extends FirestoreRecord {
  BookingsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "appointmentOwnerref" field.
  DocumentReference? _appointmentOwnerref;
  DocumentReference? get appointmentOwnerref => _appointmentOwnerref;
  bool hasAppointmentOwnerref() => _appointmentOwnerref != null;

  // "Bookingdate" field.
  DateTime? _bookingdate;
  DateTime? get bookingdate => _bookingdate;
  bool hasBookingdate() => _bookingdate != null;

  // "BookingID" field.
  String? _bookingID;
  String get bookingID => _bookingID ?? '';
  bool hasBookingID() => _bookingID != null;

  // "OpointmentName" field.
  String? _opointmentName;
  String get opointmentName => _opointmentName ?? '';
  bool hasOpointmentName() => _opointmentName != null;

  // "opointeeuser" field.
  DocumentReference? _opointeeuser;
  DocumentReference? get opointeeuser => _opointeeuser;
  bool hasOpointeeuser() => _opointeeuser != null;

  // "ApointeeID" field.
  String? _apointeeID;
  String get apointeeID => _apointeeID ?? '';
  bool hasApointeeID() => _apointeeID != null;

  // "BookingStatus" field.
  String? _bookingStatus;
  String get bookingStatus => _bookingStatus ?? '';
  bool hasBookingStatus() => _bookingStatus != null;

  // "appointeeName" field.
  String? _appointeeName;
  String get appointeeName => _appointeeName ?? '';
  bool hasAppointeeName() => _appointeeName != null;

  // "evntImage" field.
  String? _evntImage;
  String get evntImage => _evntImage ?? '';
  bool hasEvntImage() => _evntImage != null;

  // "appointmentref" field.
  DocumentReference? _appointmentref;
  DocumentReference? get appointmentref => _appointmentref;
  bool hasAppointmentref() => _appointmentref != null;

  // "appointrefOffer" field.
  DocumentReference? _appointrefOffer;
  DocumentReference? get appointrefOffer => _appointrefOffer;
  bool hasAppointrefOffer() => _appointrefOffer != null;

  // "bookTimeSlot" field.
  String? _bookTimeSlot;
  String get bookTimeSlot => _bookTimeSlot ?? '';
  bool hasBookTimeSlot() => _bookTimeSlot != null;

  // "bookingSlotDateStr" field.
  String? _bookingSlotDateStr;
  String get bookingSlotDateStr => _bookingSlotDateStr ?? '';
  bool hasBookingSlotDateStr() => _bookingSlotDateStr != null;

  // "Appointment_shopName" field.
  String? _appointmentShopName;
  String get appointmentShopName => _appointmentShopName ?? '';
  bool hasAppointmentShopName() => _appointmentShopName != null;

  void _initializeFields() {
    _appointmentOwnerref =
        snapshotData['appointmentOwnerref'] as DocumentReference?;
    _bookingdate = snapshotData['Bookingdate'] as DateTime?;
    _bookingID = snapshotData['BookingID'] as String?;
    _opointmentName = snapshotData['OpointmentName'] as String?;
    _opointeeuser = snapshotData['opointeeuser'] as DocumentReference?;
    _apointeeID = snapshotData['ApointeeID'] as String?;
    _bookingStatus = snapshotData['BookingStatus'] as String?;
    _appointeeName = snapshotData['appointeeName'] as String?;
    _evntImage = snapshotData['evntImage'] as String?;
    _appointmentref = snapshotData['appointmentref'] as DocumentReference?;
    _appointrefOffer = snapshotData['appointrefOffer'] as DocumentReference?;
    _bookTimeSlot = snapshotData['bookTimeSlot'] as String?;
    _bookingSlotDateStr = snapshotData['bookingSlotDateStr'] as String?;
    _appointmentShopName = snapshotData['Appointment_shopName'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Bookings');

  static Stream<BookingsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BookingsRecord.fromSnapshot(s));

  static Future<BookingsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BookingsRecord.fromSnapshot(s));

  static BookingsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BookingsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BookingsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BookingsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BookingsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BookingsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBookingsRecordData({
  DocumentReference? appointmentOwnerref,
  DateTime? bookingdate,
  String? bookingID,
  String? opointmentName,
  DocumentReference? opointeeuser,
  String? apointeeID,
  String? bookingStatus,
  String? appointeeName,
  String? evntImage,
  DocumentReference? appointmentref,
  DocumentReference? appointrefOffer,
  String? bookTimeSlot,
  String? bookingSlotDateStr,
  String? appointmentShopName,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'appointmentOwnerref': appointmentOwnerref,
      'Bookingdate': bookingdate,
      'BookingID': bookingID,
      'OpointmentName': opointmentName,
      'opointeeuser': opointeeuser,
      'ApointeeID': apointeeID,
      'BookingStatus': bookingStatus,
      'appointeeName': appointeeName,
      'evntImage': evntImage,
      'appointmentref': appointmentref,
      'appointrefOffer': appointrefOffer,
      'bookTimeSlot': bookTimeSlot,
      'bookingSlotDateStr': bookingSlotDateStr,
      'Appointment_shopName': appointmentShopName,
    }.withoutNulls,
  );

  return firestoreData;
}

class BookingsRecordDocumentEquality implements Equality<BookingsRecord> {
  const BookingsRecordDocumentEquality();

  @override
  bool equals(BookingsRecord? e1, BookingsRecord? e2) {
    return e1?.appointmentOwnerref == e2?.appointmentOwnerref &&
        e1?.bookingdate == e2?.bookingdate &&
        e1?.bookingID == e2?.bookingID &&
        e1?.opointmentName == e2?.opointmentName &&
        e1?.opointeeuser == e2?.opointeeuser &&
        e1?.apointeeID == e2?.apointeeID &&
        e1?.bookingStatus == e2?.bookingStatus &&
        e1?.appointeeName == e2?.appointeeName &&
        e1?.evntImage == e2?.evntImage &&
        e1?.appointmentref == e2?.appointmentref &&
        e1?.appointrefOffer == e2?.appointrefOffer &&
        e1?.bookTimeSlot == e2?.bookTimeSlot &&
        e1?.bookingSlotDateStr == e2?.bookingSlotDateStr &&
        e1?.appointmentShopName == e2?.appointmentShopName;
  }

  @override
  int hash(BookingsRecord? e) => const ListEquality().hash([
        e?.appointmentOwnerref,
        e?.bookingdate,
        e?.bookingID,
        e?.opointmentName,
        e?.opointeeuser,
        e?.apointeeID,
        e?.bookingStatus,
        e?.appointeeName,
        e?.evntImage,
        e?.appointmentref,
        e?.appointrefOffer,
        e?.bookTimeSlot,
        e?.bookingSlotDateStr,
        e?.appointmentShopName
      ]);

  @override
  bool isValidKey(Object? o) => o is BookingsRecord;
}
