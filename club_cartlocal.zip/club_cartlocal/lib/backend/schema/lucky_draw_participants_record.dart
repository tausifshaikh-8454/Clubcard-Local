import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LuckyDrawParticipantsRecord extends FirestoreRecord {
  LuckyDrawParticipantsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "lukcyDraw_participant_ref" field.
  DocumentReference? _lukcyDrawParticipantRef;
  DocumentReference? get lukcyDrawParticipantRef => _lukcyDrawParticipantRef;
  bool hasLukcyDrawParticipantRef() => _lukcyDrawParticipantRef != null;

  // "lukcyDraw_participant_name" field.
  String? _lukcyDrawParticipantName;
  String get lukcyDrawParticipantName => _lukcyDrawParticipantName ?? '';
  bool hasLukcyDrawParticipantName() => _lukcyDrawParticipantName != null;

  // "lukcyDraw_participant_id" field.
  String? _lukcyDrawParticipantId;
  String get lukcyDrawParticipantId => _lukcyDrawParticipantId ?? '';
  bool hasLukcyDrawParticipantId() => _lukcyDrawParticipantId != null;

  // "lukcyDraw_paticipated_date" field.
  DateTime? _lukcyDrawPaticipatedDate;
  DateTime? get lukcyDrawPaticipatedDate => _lukcyDrawPaticipatedDate;
  bool hasLukcyDrawPaticipatedDate() => _lukcyDrawPaticipatedDate != null;

  // "lukcyDraw_Offer_name" field.
  String? _lukcyDrawOfferName;
  String get lukcyDrawOfferName => _lukcyDrawOfferName ?? '';
  bool hasLukcyDrawOfferName() => _lukcyDrawOfferName != null;

  // "lukcyDraw_Offer_Id" field.
  String? _lukcyDrawOfferId;
  String get lukcyDrawOfferId => _lukcyDrawOfferId ?? '';
  bool hasLukcyDrawOfferId() => _lukcyDrawOfferId != null;

  // "lukcyDraw_Offer_ref" field.
  DocumentReference? _lukcyDrawOfferRef;
  DocumentReference? get lukcyDrawOfferRef => _lukcyDrawOfferRef;
  bool hasLukcyDrawOfferRef() => _lukcyDrawOfferRef != null;

  void _initializeFields() {
    _lukcyDrawParticipantRef =
        snapshotData['lukcyDraw_participant_ref'] as DocumentReference?;
    _lukcyDrawParticipantName =
        snapshotData['lukcyDraw_participant_name'] as String?;
    _lukcyDrawParticipantId =
        snapshotData['lukcyDraw_participant_id'] as String?;
    _lukcyDrawPaticipatedDate =
        snapshotData['lukcyDraw_paticipated_date'] as DateTime?;
    _lukcyDrawOfferName = snapshotData['lukcyDraw_Offer_name'] as String?;
    _lukcyDrawOfferId = snapshotData['lukcyDraw_Offer_Id'] as String?;
    _lukcyDrawOfferRef =
        snapshotData['lukcyDraw_Offer_ref'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('luckyDraw_participants');

  static Stream<LuckyDrawParticipantsRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map((s) => LuckyDrawParticipantsRecord.fromSnapshot(s));

  static Future<LuckyDrawParticipantsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => LuckyDrawParticipantsRecord.fromSnapshot(s));

  static LuckyDrawParticipantsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      LuckyDrawParticipantsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static LuckyDrawParticipantsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      LuckyDrawParticipantsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'LuckyDrawParticipantsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is LuckyDrawParticipantsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createLuckyDrawParticipantsRecordData({
  DocumentReference? lukcyDrawParticipantRef,
  String? lukcyDrawParticipantName,
  String? lukcyDrawParticipantId,
  DateTime? lukcyDrawPaticipatedDate,
  String? lukcyDrawOfferName,
  String? lukcyDrawOfferId,
  DocumentReference? lukcyDrawOfferRef,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'lukcyDraw_participant_ref': lukcyDrawParticipantRef,
      'lukcyDraw_participant_name': lukcyDrawParticipantName,
      'lukcyDraw_participant_id': lukcyDrawParticipantId,
      'lukcyDraw_paticipated_date': lukcyDrawPaticipatedDate,
      'lukcyDraw_Offer_name': lukcyDrawOfferName,
      'lukcyDraw_Offer_Id': lukcyDrawOfferId,
      'lukcyDraw_Offer_ref': lukcyDrawOfferRef,
    }.withoutNulls,
  );

  return firestoreData;
}

class LuckyDrawParticipantsRecordDocumentEquality
    implements Equality<LuckyDrawParticipantsRecord> {
  const LuckyDrawParticipantsRecordDocumentEquality();

  @override
  bool equals(
      LuckyDrawParticipantsRecord? e1, LuckyDrawParticipantsRecord? e2) {
    return e1?.lukcyDrawParticipantRef == e2?.lukcyDrawParticipantRef &&
        e1?.lukcyDrawParticipantName == e2?.lukcyDrawParticipantName &&
        e1?.lukcyDrawParticipantId == e2?.lukcyDrawParticipantId &&
        e1?.lukcyDrawPaticipatedDate == e2?.lukcyDrawPaticipatedDate &&
        e1?.lukcyDrawOfferName == e2?.lukcyDrawOfferName &&
        e1?.lukcyDrawOfferId == e2?.lukcyDrawOfferId &&
        e1?.lukcyDrawOfferRef == e2?.lukcyDrawOfferRef;
  }

  @override
  int hash(LuckyDrawParticipantsRecord? e) => const ListEquality().hash([
        e?.lukcyDrawParticipantRef,
        e?.lukcyDrawParticipantName,
        e?.lukcyDrawParticipantId,
        e?.lukcyDrawPaticipatedDate,
        e?.lukcyDrawOfferName,
        e?.lukcyDrawOfferId,
        e?.lukcyDrawOfferRef
      ]);

  @override
  bool isValidKey(Object? o) => o is LuckyDrawParticipantsRecord;
}
