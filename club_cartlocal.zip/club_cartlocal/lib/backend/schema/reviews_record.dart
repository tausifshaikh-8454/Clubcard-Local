import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReviewsRecord extends FirestoreRecord {
  ReviewsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "CustomerName" field.
  String? _customerName;
  String get customerName => _customerName ?? '';
  bool hasCustomerName() => _customerName != null;

  // "ReviewComments" field.
  String? _reviewComments;
  String get reviewComments => _reviewComments ?? '';
  bool hasReviewComments() => _reviewComments != null;

  // "VendorId" field.
  String? _vendorId;
  String get vendorId => _vendorId ?? '';
  bool hasVendorId() => _vendorId != null;

  // "custId" field.
  String? _custId;
  String get custId => _custId ?? '';
  bool hasCustId() => _custId != null;

  // "reviewtitle" field.
  String? _reviewtitle;
  String get reviewtitle => _reviewtitle ?? '';
  bool hasReviewtitle() => _reviewtitle != null;

  // "reviewRating" field.
  int? _reviewRating;
  int get reviewRating => _reviewRating ?? 0;
  bool hasReviewRating() => _reviewRating != null;

  // "cust_profile" field.
  String? _custProfile;
  String get custProfile => _custProfile ?? '';
  bool hasCustProfile() => _custProfile != null;

  // "created_date" field.
  DateTime? _createdDate;
  DateTime? get createdDate => _createdDate;
  bool hasCreatedDate() => _createdDate != null;

  // "custnumber" field.
  String? _custnumber;
  String get custnumber => _custnumber ?? '';
  bool hasCustnumber() => _custnumber != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _customerName = snapshotData['CustomerName'] as String?;
    _reviewComments = snapshotData['ReviewComments'] as String?;
    _vendorId = snapshotData['VendorId'] as String?;
    _custId = snapshotData['custId'] as String?;
    _reviewtitle = snapshotData['reviewtitle'] as String?;
    _reviewRating = castToType<int>(snapshotData['reviewRating']);
    _custProfile = snapshotData['cust_profile'] as String?;
    _createdDate = snapshotData['created_date'] as DateTime?;
    _custnumber = snapshotData['custnumber'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Reviews')
          : FirebaseFirestore.instance.collectionGroup('Reviews');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Reviews').doc(id);

  static Stream<ReviewsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReviewsRecord.fromSnapshot(s));

  static Future<ReviewsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReviewsRecord.fromSnapshot(s));

  static ReviewsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReviewsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReviewsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReviewsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReviewsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReviewsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReviewsRecordData({
  String? customerName,
  String? reviewComments,
  String? vendorId,
  String? custId,
  String? reviewtitle,
  int? reviewRating,
  String? custProfile,
  DateTime? createdDate,
  String? custnumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'CustomerName': customerName,
      'ReviewComments': reviewComments,
      'VendorId': vendorId,
      'custId': custId,
      'reviewtitle': reviewtitle,
      'reviewRating': reviewRating,
      'cust_profile': custProfile,
      'created_date': createdDate,
      'custnumber': custnumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReviewsRecordDocumentEquality implements Equality<ReviewsRecord> {
  const ReviewsRecordDocumentEquality();

  @override
  bool equals(ReviewsRecord? e1, ReviewsRecord? e2) {
    return e1?.customerName == e2?.customerName &&
        e1?.reviewComments == e2?.reviewComments &&
        e1?.vendorId == e2?.vendorId &&
        e1?.custId == e2?.custId &&
        e1?.reviewtitle == e2?.reviewtitle &&
        e1?.reviewRating == e2?.reviewRating &&
        e1?.custProfile == e2?.custProfile &&
        e1?.createdDate == e2?.createdDate &&
        e1?.custnumber == e2?.custnumber;
  }

  @override
  int hash(ReviewsRecord? e) => const ListEquality().hash([
        e?.customerName,
        e?.reviewComments,
        e?.vendorId,
        e?.custId,
        e?.reviewtitle,
        e?.reviewRating,
        e?.custProfile,
        e?.createdDate,
        e?.custnumber
      ]);

  @override
  bool isValidKey(Object? o) => o is ReviewsRecord;
}
