import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VendorDetailsRecord extends FirestoreRecord {
  VendorDetailsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "vendor_id" field.
  String? _vendorId;
  String get vendorId => _vendorId ?? '';
  bool hasVendorId() => _vendorId != null;

  // "vendor_username" field.
  String? _vendorUsername;
  String get vendorUsername => _vendorUsername ?? '';
  bool hasVendorUsername() => _vendorUsername != null;

  // "vendor_email" field.
  String? _vendorEmail;
  String get vendorEmail => _vendorEmail ?? '';
  bool hasVendorEmail() => _vendorEmail != null;

  // "vendor_phone" field.
  String? _vendorPhone;
  String get vendorPhone => _vendorPhone ?? '';
  bool hasVendorPhone() => _vendorPhone != null;

  // "vendor_type" field.
  String? _vendorType;
  String get vendorType => _vendorType ?? '';
  bool hasVendorType() => _vendorType != null;

  // "vend_pass" field.
  String? _vendPass;
  String get vendPass => _vendPass ?? '';
  bool hasVendPass() => _vendPass != null;

  // "vend_company_house_no" field.
  String? _vendCompanyHouseNo;
  String get vendCompanyHouseNo => _vendCompanyHouseNo ?? '';
  bool hasVendCompanyHouseNo() => _vendCompanyHouseNo != null;

  // "vend_company_vat_no" field.
  String? _vendCompanyVatNo;
  String get vendCompanyVatNo => _vendCompanyVatNo ?? '';
  bool hasVendCompanyVatNo() => _vendCompanyVatNo != null;

  // "business_name" field.
  String? _businessName;
  String get businessName => _businessName ?? '';
  bool hasBusinessName() => _businessName != null;

  // "business_telephone" field.
  String? _businessTelephone;
  String get businessTelephone => _businessTelephone ?? '';
  bool hasBusinessTelephone() => _businessTelephone != null;

  // "business_mob" field.
  String? _businessMob;
  String get businessMob => _businessMob ?? '';
  bool hasBusinessMob() => _businessMob != null;

  // "business_email" field.
  String? _businessEmail;
  String get businessEmail => _businessEmail ?? '';
  bool hasBusinessEmail() => _businessEmail != null;

  // "business_website" field.
  String? _businessWebsite;
  String get businessWebsite => _businessWebsite ?? '';
  bool hasBusinessWebsite() => _businessWebsite != null;

  // "business_city" field.
  String? _businessCity;
  String get businessCity => _businessCity ?? '';
  bool hasBusinessCity() => _businessCity != null;

  // "business_zipcode" field.
  String? _businessZipcode;
  String get businessZipcode => _businessZipcode ?? '';
  bool hasBusinessZipcode() => _businessZipcode != null;

  // "business_country" field.
  String? _businessCountry;
  String get businessCountry => _businessCountry ?? '';
  bool hasBusinessCountry() => _businessCountry != null;

  // "business_profile_logo" field.
  String? _businessProfileLogo;
  String get businessProfileLogo => _businessProfileLogo ?? '';
  bool hasBusinessProfileLogo() => _businessProfileLogo != null;

  // "business_profile_image" field.
  String? _businessProfileImage;
  String get businessProfileImage => _businessProfileImage ?? '';
  bool hasBusinessProfileImage() => _businessProfileImage != null;

  // "shopTags" field.
  List<String>? _shopTags;
  List<String> get shopTags => _shopTags ?? const [];
  bool hasShopTags() => _shopTags != null;

  // "typeOfBusiness" field.
  String? _typeOfBusiness;
  String get typeOfBusiness => _typeOfBusiness ?? '';
  bool hasTypeOfBusiness() => _typeOfBusiness != null;

  // "subs_packname" field.
  String? _subsPackname;
  String get subsPackname => _subsPackname ?? '';
  bool hasSubsPackname() => _subsPackname != null;

  // "subs_start_date" field.
  DateTime? _subsStartDate;
  DateTime? get subsStartDate => _subsStartDate;
  bool hasSubsStartDate() => _subsStartDate != null;

  // "subsprice" field.
  int? _subsprice;
  int get subsprice => _subsprice ?? 0;
  bool hasSubsprice() => _subsprice != null;

  // "business_street" field.
  String? _businessStreet;
  String get businessStreet => _businessStreet ?? '';
  bool hasBusinessStreet() => _businessStreet != null;

  // "business_address" field.
  String? _businessAddress;
  String get businessAddress => _businessAddress ?? '';
  bool hasBusinessAddress() => _businessAddress != null;

  // "offer_limit" field.
  String? _offerLimit;
  String get offerLimit => _offerLimit ?? '';
  bool hasOfferLimit() => _offerLimit != null;

  // "lot_partip_list" field.
  List<DocumentReference>? _lotPartipList;
  List<DocumentReference> get lotPartipList => _lotPartipList ?? const [];
  bool hasLotPartipList() => _lotPartipList != null;

  // "vend_Surname" field.
  String? _vendSurname;
  String get vendSurname => _vendSurname ?? '';
  bool hasVendSurname() => _vendSurname != null;

  void _initializeFields() {
    _vendorId = snapshotData['vendor_id'] as String?;
    _vendorUsername = snapshotData['vendor_username'] as String?;
    _vendorEmail = snapshotData['vendor_email'] as String?;
    _vendorPhone = snapshotData['vendor_phone'] as String?;
    _vendorType = snapshotData['vendor_type'] as String?;
    _vendPass = snapshotData['vend_pass'] as String?;
    _vendCompanyHouseNo = snapshotData['vend_company_house_no'] as String?;
    _vendCompanyVatNo = snapshotData['vend_company_vat_no'] as String?;
    _businessName = snapshotData['business_name'] as String?;
    _businessTelephone = snapshotData['business_telephone'] as String?;
    _businessMob = snapshotData['business_mob'] as String?;
    _businessEmail = snapshotData['business_email'] as String?;
    _businessWebsite = snapshotData['business_website'] as String?;
    _businessCity = snapshotData['business_city'] as String?;
    _businessZipcode = snapshotData['business_zipcode'] as String?;
    _businessCountry = snapshotData['business_country'] as String?;
    _businessProfileLogo = snapshotData['business_profile_logo'] as String?;
    _businessProfileImage = snapshotData['business_profile_image'] as String?;
    _shopTags = getDataList(snapshotData['shopTags']);
    _typeOfBusiness = snapshotData['typeOfBusiness'] as String?;
    _subsPackname = snapshotData['subs_packname'] as String?;
    _subsStartDate = snapshotData['subs_start_date'] as DateTime?;
    _subsprice = castToType<int>(snapshotData['subsprice']);
    _businessStreet = snapshotData['business_street'] as String?;
    _businessAddress = snapshotData['business_address'] as String?;
    _offerLimit = snapshotData['offer_limit'] as String?;
    _lotPartipList = getDataList(snapshotData['lot_partip_list']);
    _vendSurname = snapshotData['vend_Surname'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('vendor-details');

  static Stream<VendorDetailsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VendorDetailsRecord.fromSnapshot(s));

  static Future<VendorDetailsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VendorDetailsRecord.fromSnapshot(s));

  static VendorDetailsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VendorDetailsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VendorDetailsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VendorDetailsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VendorDetailsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VendorDetailsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVendorDetailsRecordData({
  String? vendorId,
  String? vendorUsername,
  String? vendorEmail,
  String? vendorPhone,
  String? vendorType,
  String? vendPass,
  String? vendCompanyHouseNo,
  String? vendCompanyVatNo,
  String? businessName,
  String? businessTelephone,
  String? businessMob,
  String? businessEmail,
  String? businessWebsite,
  String? businessCity,
  String? businessZipcode,
  String? businessCountry,
  String? businessProfileLogo,
  String? businessProfileImage,
  String? typeOfBusiness,
  String? subsPackname,
  DateTime? subsStartDate,
  int? subsprice,
  String? businessStreet,
  String? businessAddress,
  String? offerLimit,
  String? vendSurname,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'vendor_id': vendorId,
      'vendor_username': vendorUsername,
      'vendor_email': vendorEmail,
      'vendor_phone': vendorPhone,
      'vendor_type': vendorType,
      'vend_pass': vendPass,
      'vend_company_house_no': vendCompanyHouseNo,
      'vend_company_vat_no': vendCompanyVatNo,
      'business_name': businessName,
      'business_telephone': businessTelephone,
      'business_mob': businessMob,
      'business_email': businessEmail,
      'business_website': businessWebsite,
      'business_city': businessCity,
      'business_zipcode': businessZipcode,
      'business_country': businessCountry,
      'business_profile_logo': businessProfileLogo,
      'business_profile_image': businessProfileImage,
      'typeOfBusiness': typeOfBusiness,
      'subs_packname': subsPackname,
      'subs_start_date': subsStartDate,
      'subsprice': subsprice,
      'business_street': businessStreet,
      'business_address': businessAddress,
      'offer_limit': offerLimit,
      'vend_Surname': vendSurname,
    }.withoutNulls,
  );

  return firestoreData;
}

class VendorDetailsRecordDocumentEquality
    implements Equality<VendorDetailsRecord> {
  const VendorDetailsRecordDocumentEquality();

  @override
  bool equals(VendorDetailsRecord? e1, VendorDetailsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.vendorId == e2?.vendorId &&
        e1?.vendorUsername == e2?.vendorUsername &&
        e1?.vendorEmail == e2?.vendorEmail &&
        e1?.vendorPhone == e2?.vendorPhone &&
        e1?.vendorType == e2?.vendorType &&
        e1?.vendPass == e2?.vendPass &&
        e1?.vendCompanyHouseNo == e2?.vendCompanyHouseNo &&
        e1?.vendCompanyVatNo == e2?.vendCompanyVatNo &&
        e1?.businessName == e2?.businessName &&
        e1?.businessTelephone == e2?.businessTelephone &&
        e1?.businessMob == e2?.businessMob &&
        e1?.businessEmail == e2?.businessEmail &&
        e1?.businessWebsite == e2?.businessWebsite &&
        e1?.businessCity == e2?.businessCity &&
        e1?.businessZipcode == e2?.businessZipcode &&
        e1?.businessCountry == e2?.businessCountry &&
        e1?.businessProfileLogo == e2?.businessProfileLogo &&
        e1?.businessProfileImage == e2?.businessProfileImage &&
        listEquality.equals(e1?.shopTags, e2?.shopTags) &&
        e1?.typeOfBusiness == e2?.typeOfBusiness &&
        e1?.subsPackname == e2?.subsPackname &&
        e1?.subsStartDate == e2?.subsStartDate &&
        e1?.subsprice == e2?.subsprice &&
        e1?.businessStreet == e2?.businessStreet &&
        e1?.businessAddress == e2?.businessAddress &&
        e1?.offerLimit == e2?.offerLimit &&
        listEquality.equals(e1?.lotPartipList, e2?.lotPartipList) &&
        e1?.vendSurname == e2?.vendSurname;
  }

  @override
  int hash(VendorDetailsRecord? e) => const ListEquality().hash([
        e?.vendorId,
        e?.vendorUsername,
        e?.vendorEmail,
        e?.vendorPhone,
        e?.vendorType,
        e?.vendPass,
        e?.vendCompanyHouseNo,
        e?.vendCompanyVatNo,
        e?.businessName,
        e?.businessTelephone,
        e?.businessMob,
        e?.businessEmail,
        e?.businessWebsite,
        e?.businessCity,
        e?.businessZipcode,
        e?.businessCountry,
        e?.businessProfileLogo,
        e?.businessProfileImage,
        e?.shopTags,
        e?.typeOfBusiness,
        e?.subsPackname,
        e?.subsStartDate,
        e?.subsprice,
        e?.businessStreet,
        e?.businessAddress,
        e?.offerLimit,
        e?.lotPartipList,
        e?.vendSurname
      ]);

  @override
  bool isValidKey(Object? o) => o is VendorDetailsRecord;
}
