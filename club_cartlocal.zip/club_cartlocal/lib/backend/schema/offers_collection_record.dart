import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OffersCollectionRecord extends FirestoreRecord {
  OffersCollectionRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Offer_title" field.
  String? _offerTitle;
  String get offerTitle => _offerTitle ?? '';
  bool hasOfferTitle() => _offerTitle != null;

  // "Offer_category" field.
  String? _offerCategory;
  String get offerCategory => _offerCategory ?? '';
  bool hasOfferCategory() => _offerCategory != null;

  // "Offer_price" field.
  int? _offerPrice;
  int get offerPrice => _offerPrice ?? 0;
  bool hasOfferPrice() => _offerPrice != null;

  // "regular_price" field.
  int? _regularPrice;
  int get regularPrice => _regularPrice ?? 0;
  bool hasRegularPrice() => _regularPrice != null;

  // "Tags" field.
  List<String>? _tags;
  List<String> get tags => _tags ?? const [];
  bool hasTags() => _tags != null;

  // "offfer_Short_description" field.
  String? _offferShortDescription;
  String get offferShortDescription => _offferShortDescription ?? '';
  bool hasOffferShortDescription() => _offferShortDescription != null;

  // "Offer_publishe_date" field.
  DateTime? _offerPublisheDate;
  DateTime? get offerPublisheDate => _offerPublisheDate;
  bool hasOfferPublisheDate() => _offerPublisheDate != null;

  // "Offer_expiry_date" field.
  DateTime? _offerExpiryDate;
  DateTime? get offerExpiryDate => _offerExpiryDate;
  bool hasOfferExpiryDate() => _offerExpiryDate != null;

  // "offr_image" field.
  String? _offrImage;
  String get offrImage => _offrImage ?? '';
  bool hasOffrImage() => _offrImage != null;

  // "Offer_number" field.
  String? _offerNumber;
  String get offerNumber => _offerNumber ?? '';
  bool hasOfferNumber() => _offerNumber != null;

  // "Vendor_id" field.
  String? _vendorId;
  String get vendorId => _vendorId ?? '';
  bool hasVendorId() => _vendorId != null;

  // "offer_status" field.
  String? _offerStatus;
  String get offerStatus => _offerStatus ?? '';
  bool hasOfferStatus() => _offerStatus != null;

  // "vendor_Name" field.
  String? _vendorName;
  String get vendorName => _vendorName ?? '';
  bool hasVendorName() => _vendorName != null;

  // "vend_Ref" field.
  DocumentReference? _vendRef;
  DocumentReference? get vendRef => _vendRef;
  bool hasVendRef() => _vendRef != null;

  // "offerType" field.
  String? _offerType;
  String get offerType => _offerType ?? '';
  bool hasOfferType() => _offerType != null;

  // "offer_Created_Date" field.
  DateTime? _offerCreatedDate;
  DateTime? get offerCreatedDate => _offerCreatedDate;
  bool hasOfferCreatedDate() => _offerCreatedDate != null;

  // "startTimeStr" field.
  List<String>? _startTimeStr;
  List<String> get startTimeStr => _startTimeStr ?? const [];
  bool hasStartTimeStr() => _startTimeStr != null;

  void _initializeFields() {
    _offerTitle = snapshotData['Offer_title'] as String?;
    _offerCategory = snapshotData['Offer_category'] as String?;
    _offerPrice = castToType<int>(snapshotData['Offer_price']);
    _regularPrice = castToType<int>(snapshotData['regular_price']);
    _tags = getDataList(snapshotData['Tags']);
    _offferShortDescription =
        snapshotData['offfer_Short_description'] as String?;
    _offerPublisheDate = snapshotData['Offer_publishe_date'] as DateTime?;
    _offerExpiryDate = snapshotData['Offer_expiry_date'] as DateTime?;
    _offrImage = snapshotData['offr_image'] as String?;
    _offerNumber = snapshotData['Offer_number'] as String?;
    _vendorId = snapshotData['Vendor_id'] as String?;
    _offerStatus = snapshotData['offer_status'] as String?;
    _vendorName = snapshotData['vendor_Name'] as String?;
    _vendRef = snapshotData['vend_Ref'] as DocumentReference?;
    _offerType = snapshotData['offerType'] as String?;
    _offerCreatedDate = snapshotData['offer_Created_Date'] as DateTime?;
    _startTimeStr = getDataList(snapshotData['startTimeStr']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Offers-collection');

  static Stream<OffersCollectionRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OffersCollectionRecord.fromSnapshot(s));

  static Future<OffersCollectionRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => OffersCollectionRecord.fromSnapshot(s));

  static OffersCollectionRecord fromSnapshot(DocumentSnapshot snapshot) =>
      OffersCollectionRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OffersCollectionRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OffersCollectionRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OffersCollectionRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OffersCollectionRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOffersCollectionRecordData({
  String? offerTitle,
  String? offerCategory,
  int? offerPrice,
  int? regularPrice,
  String? offferShortDescription,
  DateTime? offerPublisheDate,
  DateTime? offerExpiryDate,
  String? offrImage,
  String? offerNumber,
  String? vendorId,
  String? offerStatus,
  String? vendorName,
  DocumentReference? vendRef,
  String? offerType,
  DateTime? offerCreatedDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Offer_title': offerTitle,
      'Offer_category': offerCategory,
      'Offer_price': offerPrice,
      'regular_price': regularPrice,
      'offfer_Short_description': offferShortDescription,
      'Offer_publishe_date': offerPublisheDate,
      'Offer_expiry_date': offerExpiryDate,
      'offr_image': offrImage,
      'Offer_number': offerNumber,
      'Vendor_id': vendorId,
      'offer_status': offerStatus,
      'vendor_Name': vendorName,
      'vend_Ref': vendRef,
      'offerType': offerType,
      'offer_Created_Date': offerCreatedDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class OffersCollectionRecordDocumentEquality
    implements Equality<OffersCollectionRecord> {
  const OffersCollectionRecordDocumentEquality();

  @override
  bool equals(OffersCollectionRecord? e1, OffersCollectionRecord? e2) {
    const listEquality = ListEquality();
    return e1?.offerTitle == e2?.offerTitle &&
        e1?.offerCategory == e2?.offerCategory &&
        e1?.offerPrice == e2?.offerPrice &&
        e1?.regularPrice == e2?.regularPrice &&
        listEquality.equals(e1?.tags, e2?.tags) &&
        e1?.offferShortDescription == e2?.offferShortDescription &&
        e1?.offerPublisheDate == e2?.offerPublisheDate &&
        e1?.offerExpiryDate == e2?.offerExpiryDate &&
        e1?.offrImage == e2?.offrImage &&
        e1?.offerNumber == e2?.offerNumber &&
        e1?.vendorId == e2?.vendorId &&
        e1?.offerStatus == e2?.offerStatus &&
        e1?.vendorName == e2?.vendorName &&
        e1?.vendRef == e2?.vendRef &&
        e1?.offerType == e2?.offerType &&
        e1?.offerCreatedDate == e2?.offerCreatedDate &&
        listEquality.equals(e1?.startTimeStr, e2?.startTimeStr);
  }

  @override
  int hash(OffersCollectionRecord? e) => const ListEquality().hash([
        e?.offerTitle,
        e?.offerCategory,
        e?.offerPrice,
        e?.regularPrice,
        e?.tags,
        e?.offferShortDescription,
        e?.offerPublisheDate,
        e?.offerExpiryDate,
        e?.offrImage,
        e?.offerNumber,
        e?.vendorId,
        e?.offerStatus,
        e?.vendorName,
        e?.vendRef,
        e?.offerType,
        e?.offerCreatedDate,
        e?.startTimeStr
      ]);

  @override
  bool isValidKey(Object? o) => o is OffersCollectionRecord;
}
