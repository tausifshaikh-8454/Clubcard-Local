import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LuckyDrawOfferRecord extends FirestoreRecord {
  LuckyDrawOfferRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "luckyDraw_Offr_name" field.
  String? _luckyDrawOffrName;
  String get luckyDrawOffrName => _luckyDrawOffrName ?? '';
  bool hasLuckyDrawOffrName() => _luckyDrawOffrName != null;

  // "lukcyDraw_Offer_Desc" field.
  String? _lukcyDrawOfferDesc;
  String get lukcyDrawOfferDesc => _lukcyDrawOfferDesc ?? '';
  bool hasLukcyDrawOfferDesc() => _lukcyDrawOfferDesc != null;

  // "lukcyDraw_Offer_image" field.
  String? _lukcyDrawOfferImage;
  String get lukcyDrawOfferImage => _lukcyDrawOfferImage ?? '';
  bool hasLukcyDrawOfferImage() => _lukcyDrawOfferImage != null;

  // "lukcyDraw_Offer_publishDate" field.
  DateTime? _lukcyDrawOfferPublishDate;
  DateTime? get lukcyDrawOfferPublishDate => _lukcyDrawOfferPublishDate;
  bool hasLukcyDrawOfferPublishDate() => _lukcyDrawOfferPublishDate != null;

  // "lukcyDraw_Offer_active_period" field.
  DateTime? _lukcyDrawOfferActivePeriod;
  DateTime? get lukcyDrawOfferActivePeriod => _lukcyDrawOfferActivePeriod;
  bool hasLukcyDrawOfferActivePeriod() => _lukcyDrawOfferActivePeriod != null;

  // "lukcyDraw_Offer_status" field.
  String? _lukcyDrawOfferStatus;
  String get lukcyDrawOfferStatus => _lukcyDrawOfferStatus ?? '';
  bool hasLukcyDrawOfferStatus() => _lukcyDrawOfferStatus != null;

  // "lukcyDraw_Offer_id" field.
  String? _lukcyDrawOfferId;
  String get lukcyDrawOfferId => _lukcyDrawOfferId ?? '';
  bool hasLukcyDrawOfferId() => _lukcyDrawOfferId != null;

  // "luckyDraw_offer_end_period" field.
  DateTime? _luckyDrawOfferEndPeriod;
  DateTime? get luckyDrawOfferEndPeriod => _luckyDrawOfferEndPeriod;
  bool hasLuckyDrawOfferEndPeriod() => _luckyDrawOfferEndPeriod != null;

  // "luckyDraw_offer_participant_id" field.
  List<String>? _luckyDrawOfferParticipantId;
  List<String> get luckyDrawOfferParticipantId =>
      _luckyDrawOfferParticipantId ?? const [];
  bool hasLuckyDrawOfferParticipantId() => _luckyDrawOfferParticipantId != null;

  void _initializeFields() {
    _luckyDrawOffrName = snapshotData['luckyDraw_Offr_name'] as String?;
    _lukcyDrawOfferDesc = snapshotData['lukcyDraw_Offer_Desc'] as String?;
    _lukcyDrawOfferImage = snapshotData['lukcyDraw_Offer_image'] as String?;
    _lukcyDrawOfferPublishDate =
        snapshotData['lukcyDraw_Offer_publishDate'] as DateTime?;
    _lukcyDrawOfferActivePeriod =
        snapshotData['lukcyDraw_Offer_active_period'] as DateTime?;
    _lukcyDrawOfferStatus = snapshotData['lukcyDraw_Offer_status'] as String?;
    _lukcyDrawOfferId = snapshotData['lukcyDraw_Offer_id'] as String?;
    _luckyDrawOfferEndPeriod =
        snapshotData['luckyDraw_offer_end_period'] as DateTime?;
    _luckyDrawOfferParticipantId =
        getDataList(snapshotData['luckyDraw_offer_participant_id']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('luckyDraw_Offer');

  static Stream<LuckyDrawOfferRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => LuckyDrawOfferRecord.fromSnapshot(s));

  static Future<LuckyDrawOfferRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => LuckyDrawOfferRecord.fromSnapshot(s));

  static LuckyDrawOfferRecord fromSnapshot(DocumentSnapshot snapshot) =>
      LuckyDrawOfferRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static LuckyDrawOfferRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      LuckyDrawOfferRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'LuckyDrawOfferRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is LuckyDrawOfferRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createLuckyDrawOfferRecordData({
  String? luckyDrawOffrName,
  String? lukcyDrawOfferDesc,
  String? lukcyDrawOfferImage,
  DateTime? lukcyDrawOfferPublishDate,
  DateTime? lukcyDrawOfferActivePeriod,
  String? lukcyDrawOfferStatus,
  String? lukcyDrawOfferId,
  DateTime? luckyDrawOfferEndPeriod,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'luckyDraw_Offr_name': luckyDrawOffrName,
      'lukcyDraw_Offer_Desc': lukcyDrawOfferDesc,
      'lukcyDraw_Offer_image': lukcyDrawOfferImage,
      'lukcyDraw_Offer_publishDate': lukcyDrawOfferPublishDate,
      'lukcyDraw_Offer_active_period': lukcyDrawOfferActivePeriod,
      'lukcyDraw_Offer_status': lukcyDrawOfferStatus,
      'lukcyDraw_Offer_id': lukcyDrawOfferId,
      'luckyDraw_offer_end_period': luckyDrawOfferEndPeriod,
    }.withoutNulls,
  );

  return firestoreData;
}

class LuckyDrawOfferRecordDocumentEquality
    implements Equality<LuckyDrawOfferRecord> {
  const LuckyDrawOfferRecordDocumentEquality();

  @override
  bool equals(LuckyDrawOfferRecord? e1, LuckyDrawOfferRecord? e2) {
    const listEquality = ListEquality();
    return e1?.luckyDrawOffrName == e2?.luckyDrawOffrName &&
        e1?.lukcyDrawOfferDesc == e2?.lukcyDrawOfferDesc &&
        e1?.lukcyDrawOfferImage == e2?.lukcyDrawOfferImage &&
        e1?.lukcyDrawOfferPublishDate == e2?.lukcyDrawOfferPublishDate &&
        e1?.lukcyDrawOfferActivePeriod == e2?.lukcyDrawOfferActivePeriod &&
        e1?.lukcyDrawOfferStatus == e2?.lukcyDrawOfferStatus &&
        e1?.lukcyDrawOfferId == e2?.lukcyDrawOfferId &&
        e1?.luckyDrawOfferEndPeriod == e2?.luckyDrawOfferEndPeriod &&
        listEquality.equals(
            e1?.luckyDrawOfferParticipantId, e2?.luckyDrawOfferParticipantId);
  }

  @override
  int hash(LuckyDrawOfferRecord? e) => const ListEquality().hash([
        e?.luckyDrawOffrName,
        e?.lukcyDrawOfferDesc,
        e?.lukcyDrawOfferImage,
        e?.lukcyDrawOfferPublishDate,
        e?.lukcyDrawOfferActivePeriod,
        e?.lukcyDrawOfferStatus,
        e?.lukcyDrawOfferId,
        e?.luckyDrawOfferEndPeriod,
        e?.luckyDrawOfferParticipantId
      ]);

  @override
  bool isValidKey(Object? o) => o is LuckyDrawOfferRecord;
}
