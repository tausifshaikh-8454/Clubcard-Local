import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FollowedshopRecord extends FirestoreRecord {
  FollowedshopRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Followed_date" field.
  DateTime? _followedDate;
  DateTime? get followedDate => _followedDate;
  bool hasFollowedDate() => _followedDate != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "followedshop" field.
  DocumentReference? _followedshop;
  DocumentReference? get followedshop => _followedshop;
  bool hasFollowedshop() => _followedshop != null;

  // "User_Id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "follwedShopId" field.
  String? _follwedShopId;
  String get follwedShopId => _follwedShopId ?? '';
  bool hasFollwedShopId() => _follwedShopId != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _followedDate = snapshotData['Followed_date'] as DateTime?;
    _user = snapshotData['user'] as DocumentReference?;
    _followedshop = snapshotData['followedshop'] as DocumentReference?;
    _userId = snapshotData['User_Id'] as String?;
    _follwedShopId = snapshotData['follwedShopId'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('followedshop')
          : FirebaseFirestore.instance.collectionGroup('followedshop');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('followedshop').doc(id);

  static Stream<FollowedshopRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FollowedshopRecord.fromSnapshot(s));

  static Future<FollowedshopRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FollowedshopRecord.fromSnapshot(s));

  static FollowedshopRecord fromSnapshot(DocumentSnapshot snapshot) =>
      FollowedshopRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FollowedshopRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FollowedshopRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FollowedshopRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FollowedshopRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFollowedshopRecordData({
  DateTime? followedDate,
  DocumentReference? user,
  DocumentReference? followedshop,
  String? userId,
  String? follwedShopId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Followed_date': followedDate,
      'user': user,
      'followedshop': followedshop,
      'User_Id': userId,
      'follwedShopId': follwedShopId,
    }.withoutNulls,
  );

  return firestoreData;
}

class FollowedshopRecordDocumentEquality
    implements Equality<FollowedshopRecord> {
  const FollowedshopRecordDocumentEquality();

  @override
  bool equals(FollowedshopRecord? e1, FollowedshopRecord? e2) {
    return e1?.followedDate == e2?.followedDate &&
        e1?.user == e2?.user &&
        e1?.followedshop == e2?.followedshop &&
        e1?.userId == e2?.userId &&
        e1?.follwedShopId == e2?.follwedShopId;
  }

  @override
  int hash(FollowedshopRecord? e) => const ListEquality().hash(
      [e?.followedDate, e?.user, e?.followedshop, e?.userId, e?.follwedShopId]);

  @override
  bool isValidKey(Object? o) => o is FollowedshopRecord;
}
