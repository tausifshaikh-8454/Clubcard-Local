import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SubscriptionsRecord extends FirestoreRecord {
  SubscriptionsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "subscrib_user" field.
  String? _subscribUser;
  String get subscribUser => _subscribUser ?? '';
  bool hasSubscribUser() => _subscribUser != null;

  // "subsPack_name" field.
  String? _subsPackName;
  String get subsPackName => _subsPackName ?? '';
  bool hasSubsPackName() => _subsPackName != null;

  // "subsc_sessionid" field.
  String? _subscSessionid;
  String get subscSessionid => _subscSessionid ?? '';
  bool hasSubscSessionid() => _subscSessionid != null;

  // "payment_method" field.
  String? _paymentMethod;
  String get paymentMethod => _paymentMethod ?? '';
  bool hasPaymentMethod() => _paymentMethod != null;

  // "payment_staus" field.
  String? _paymentStaus;
  String get paymentStaus => _paymentStaus ?? '';
  bool hasPaymentStaus() => _paymentStaus != null;

  // "subs_amount" field.
  double? _subsAmount;
  double get subsAmount => _subsAmount ?? 0.0;
  bool hasSubsAmount() => _subsAmount != null;

  // "subs_cust_Id" field.
  String? _subsCustId;
  String get subsCustId => _subsCustId ?? '';
  bool hasSubsCustId() => _subsCustId != null;

  // "Subs_id" field.
  String? _subsId;
  String get subsId => _subsId ?? '';
  bool hasSubsId() => _subsId != null;

  // "Subs_start_date" field.
  DateTime? _subsStartDate;
  DateTime? get subsStartDate => _subsStartDate;
  bool hasSubsStartDate() => _subsStartDate != null;

  // "Subs_End_date" field.
  DateTime? _subsEndDate;
  DateTime? get subsEndDate => _subsEndDate;
  bool hasSubsEndDate() => _subsEndDate != null;

  // "subs_item_id" field.
  String? _subsItemId;
  String get subsItemId => _subsItemId ?? '';
  bool hasSubsItemId() => _subsItemId != null;

  // "product_id" field.
  String? _productId;
  String get productId => _productId ?? '';
  bool hasProductId() => _productId != null;

  // "subs_price_id" field.
  String? _subsPriceId;
  String get subsPriceId => _subsPriceId ?? '';
  bool hasSubsPriceId() => _subsPriceId != null;

  // "order_id" field.
  String? _orderId;
  String get orderId => _orderId ?? '';
  bool hasOrderId() => _orderId != null;

  void _initializeFields() {
    _subscribUser = snapshotData['subscrib_user'] as String?;
    _subsPackName = snapshotData['subsPack_name'] as String?;
    _subscSessionid = snapshotData['subsc_sessionid'] as String?;
    _paymentMethod = snapshotData['payment_method'] as String?;
    _paymentStaus = snapshotData['payment_staus'] as String?;
    _subsAmount = castToType<double>(snapshotData['subs_amount']);
    _subsCustId = snapshotData['subs_cust_Id'] as String?;
    _subsId = snapshotData['Subs_id'] as String?;
    _subsStartDate = snapshotData['Subs_start_date'] as DateTime?;
    _subsEndDate = snapshotData['Subs_End_date'] as DateTime?;
    _subsItemId = snapshotData['subs_item_id'] as String?;
    _productId = snapshotData['product_id'] as String?;
    _subsPriceId = snapshotData['subs_price_id'] as String?;
    _orderId = snapshotData['order_id'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Subscriptions');

  static Stream<SubscriptionsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SubscriptionsRecord.fromSnapshot(s));

  static Future<SubscriptionsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SubscriptionsRecord.fromSnapshot(s));

  static SubscriptionsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SubscriptionsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SubscriptionsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SubscriptionsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SubscriptionsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SubscriptionsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSubscriptionsRecordData({
  String? subscribUser,
  String? subsPackName,
  String? subscSessionid,
  String? paymentMethod,
  String? paymentStaus,
  double? subsAmount,
  String? subsCustId,
  String? subsId,
  DateTime? subsStartDate,
  DateTime? subsEndDate,
  String? subsItemId,
  String? productId,
  String? subsPriceId,
  String? orderId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'subscrib_user': subscribUser,
      'subsPack_name': subsPackName,
      'subsc_sessionid': subscSessionid,
      'payment_method': paymentMethod,
      'payment_staus': paymentStaus,
      'subs_amount': subsAmount,
      'subs_cust_Id': subsCustId,
      'Subs_id': subsId,
      'Subs_start_date': subsStartDate,
      'Subs_End_date': subsEndDate,
      'subs_item_id': subsItemId,
      'product_id': productId,
      'subs_price_id': subsPriceId,
      'order_id': orderId,
    }.withoutNulls,
  );

  return firestoreData;
}

class SubscriptionsRecordDocumentEquality
    implements Equality<SubscriptionsRecord> {
  const SubscriptionsRecordDocumentEquality();

  @override
  bool equals(SubscriptionsRecord? e1, SubscriptionsRecord? e2) {
    return e1?.subscribUser == e2?.subscribUser &&
        e1?.subsPackName == e2?.subsPackName &&
        e1?.subscSessionid == e2?.subscSessionid &&
        e1?.paymentMethod == e2?.paymentMethod &&
        e1?.paymentStaus == e2?.paymentStaus &&
        e1?.subsAmount == e2?.subsAmount &&
        e1?.subsCustId == e2?.subsCustId &&
        e1?.subsId == e2?.subsId &&
        e1?.subsStartDate == e2?.subsStartDate &&
        e1?.subsEndDate == e2?.subsEndDate &&
        e1?.subsItemId == e2?.subsItemId &&
        e1?.productId == e2?.productId &&
        e1?.subsPriceId == e2?.subsPriceId &&
        e1?.orderId == e2?.orderId;
  }

  @override
  int hash(SubscriptionsRecord? e) => const ListEquality().hash([
        e?.subscribUser,
        e?.subsPackName,
        e?.subscSessionid,
        e?.paymentMethod,
        e?.paymentStaus,
        e?.subsAmount,
        e?.subsCustId,
        e?.subsId,
        e?.subsStartDate,
        e?.subsEndDate,
        e?.subsItemId,
        e?.productId,
        e?.subsPriceId,
        e?.orderId
      ]);

  @override
  bool isValidKey(Object? o) => o is SubscriptionsRecord;
}
