import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ServiceSlotsRecord extends FirestoreRecord {
  ServiceSlotsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "vend_ref" field.
  DocumentReference? _vendRef;
  DocumentReference? get vendRef => _vendRef;
  bool hasVendRef() => _vendRef != null;

  // "timeSlots" field.
  String? _timeSlots;
  String get timeSlots => _timeSlots ?? '';
  bool hasTimeSlots() => _timeSlots != null;

  // "bookedBy" field.
  DocumentReference? _bookedBy;
  DocumentReference? get bookedBy => _bookedBy;
  bool hasBookedBy() => _bookedBy != null;

  // "offerref" field.
  DocumentReference? _offerref;
  DocumentReference? get offerref => _offerref;
  bool hasOfferref() => _offerref != null;

  // "isslotbooked" field.
  bool? _isslotbooked;
  bool get isslotbooked => _isslotbooked ?? false;
  bool hasIsslotbooked() => _isslotbooked != null;

  // "ServiceDate" field.
  DateTime? _serviceDate;
  DateTime? get serviceDate => _serviceDate;
  bool hasServiceDate() => _serviceDate != null;

  void _initializeFields() {
    _vendRef = snapshotData['vend_ref'] as DocumentReference?;
    _timeSlots = snapshotData['timeSlots'] as String?;
    _bookedBy = snapshotData['bookedBy'] as DocumentReference?;
    _offerref = snapshotData['offerref'] as DocumentReference?;
    _isslotbooked = snapshotData['isslotbooked'] as bool?;
    _serviceDate = snapshotData['ServiceDate'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('service_Slots');

  static Stream<ServiceSlotsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ServiceSlotsRecord.fromSnapshot(s));

  static Future<ServiceSlotsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ServiceSlotsRecord.fromSnapshot(s));

  static ServiceSlotsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ServiceSlotsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ServiceSlotsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ServiceSlotsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ServiceSlotsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ServiceSlotsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createServiceSlotsRecordData({
  DocumentReference? vendRef,
  String? timeSlots,
  DocumentReference? bookedBy,
  DocumentReference? offerref,
  bool? isslotbooked,
  DateTime? serviceDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'vend_ref': vendRef,
      'timeSlots': timeSlots,
      'bookedBy': bookedBy,
      'offerref': offerref,
      'isslotbooked': isslotbooked,
      'ServiceDate': serviceDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class ServiceSlotsRecordDocumentEquality
    implements Equality<ServiceSlotsRecord> {
  const ServiceSlotsRecordDocumentEquality();

  @override
  bool equals(ServiceSlotsRecord? e1, ServiceSlotsRecord? e2) {
    return e1?.vendRef == e2?.vendRef &&
        e1?.timeSlots == e2?.timeSlots &&
        e1?.bookedBy == e2?.bookedBy &&
        e1?.offerref == e2?.offerref &&
        e1?.isslotbooked == e2?.isslotbooked &&
        e1?.serviceDate == e2?.serviceDate;
  }

  @override
  int hash(ServiceSlotsRecord? e) => const ListEquality().hash([
        e?.vendRef,
        e?.timeSlots,
        e?.bookedBy,
        e?.offerref,
        e?.isslotbooked,
        e?.serviceDate
      ]);

  @override
  bool isValidKey(Object? o) => o is ServiceSlotsRecord;
}
