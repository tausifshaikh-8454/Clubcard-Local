import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'bookingstatus_model.dart';
export 'bookingstatus_model.dart';

class BookingstatusWidget extends StatefulWidget {
  const BookingstatusWidget({
    super.key,
    this.parameter1,
  });

  final DocumentReference? parameter1;

  @override
  State<BookingstatusWidget> createState() => _BookingstatusWidgetState();
}

class _BookingstatusWidgetState extends State<BookingstatusWidget> {
  late BookingstatusModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BookingstatusModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 10.0, 0.0),
      child: Container(
        height: 50.0,
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        child: FlutterFlowChoiceChips(
          options: [ChipData('Not Attended'), ChipData('Completed')],
          onChanged: (val) async {
            safeSetState(() => _model.choiceChipsValue = val?.firstOrNull);
            await widget!.parameter1!.update(createBookingsRecordData(
              bookingStatus: _model.choiceChipsValue,
            ));
          },
          selectedChipStyle: ChipStyle(
            backgroundColor: Color(0xFFFF7622),
            textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Sen',
                  color: Colors.white,
                  fontSize: 16.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
            iconColor: Colors.white,
            iconSize: 16.0,
            labelPadding: EdgeInsets.all(10.0),
            elevation: 0.0,
            borderRadius: BorderRadius.circular(8.0),
          ),
          unselectedChipStyle: ChipStyle(
            backgroundColor: Colors.white,
            textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Sen',
                  color: Color(0xFF7C7C7C),
                  fontSize: 16.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
            iconColor: Color(0xFF57636C),
            iconSize: 16.0,
            labelPadding: EdgeInsets.all(10.0),
            elevation: 0.0,
            borderColor: Color(0xFFDCDCDC),
            borderWidth: 1.0,
            borderRadius: BorderRadius.circular(8.0),
          ),
          chipSpacing: 8.0,
          rowSpacing: 8.0,
          multiselect: false,
          alignment: WrapAlignment.start,
          controller: _model.choiceChipsValueController ??=
              FormFieldController<List<String>>(
            [],
          ),
          wrapped: true,
        ),
      ),
    );
  }
}
