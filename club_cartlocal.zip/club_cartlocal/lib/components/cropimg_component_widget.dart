import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'cropimg_component_model.dart';
export 'cropimg_component_model.dart';

class CropimgComponentWidget extends StatefulWidget {
  const CropimgComponentWidget({
    super.key,
    required this.uploadedimageurl,
  });

  final String? uploadedimageurl;

  @override
  State<CropimgComponentWidget> createState() => _CropimgComponentWidgetState();
}

class _CropimgComponentWidgetState extends State<CropimgComponentWidget> {
  late CropimgComponentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CropimgComponentModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Padding(
        padding: EdgeInsets.all(20.0),
        child: Container(
          width: 500.0,
          height: 500.0,
          decoration: BoxDecoration(
            color: Color(0xFFFFECD4),
          ),
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Container(
              width: MediaQuery.sizeOf(context).width * 1.0,
              height: MediaQuery.sizeOf(context).height * 1.0,
              child: custom_widgets.ImageCropper(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: MediaQuery.sizeOf(context).height * 1.0,
                imageUrl: widget!.uploadedimageurl,
                callBackAction: (url) async {
                  Navigator.pop(context, url);
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
