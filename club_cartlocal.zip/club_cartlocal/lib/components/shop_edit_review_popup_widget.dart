import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'shop_edit_review_popup_model.dart';
export 'shop_edit_review_popup_model.dart';

class ShopEditReviewPopupWidget extends StatefulWidget {
  const ShopEditReviewPopupWidget({
    super.key,
    required this.vendref,
    required this.custdoc,
    required this.venddoc,
  });

  final DocumentReference? vendref;
  final CustomerDetailsRecord? custdoc;
  final VendorDetailsRecord? venddoc;

  @override
  State<ShopEditReviewPopupWidget> createState() =>
      _ShopEditReviewPopupWidgetState();
}

class _ShopEditReviewPopupWidgetState extends State<ShopEditReviewPopupWidget> {
  late ShopEditReviewPopupModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ShopEditReviewPopupModel());

    _model.rvwtitleFocusNode ??= FocusNode();

    _model.rvwdescFocusNode ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: StreamBuilder<List<ReviewsRecord>>(
        stream: queryReviewsRecord(
          queryBuilder: (reviewsRecord) => reviewsRecord
              .where(
                'custId',
                isEqualTo: widget!.custdoc?.custUserid != ''
                    ? widget!.custdoc?.custUserid
                    : null,
              )
              .where(
                'VendorId',
                isEqualTo: widget!.venddoc?.vendorId != ''
                    ? widget!.venddoc?.vendorId
                    : null,
              ),
          singleRecord: true,
        ),
        builder: (context, snapshot) {
          // Customize what your widget looks like when it's loading.
          if (!snapshot.hasData) {
            return Center(
              child: SizedBox(
                width: 60.0,
                height: 60.0,
                child: SpinKitRipple(
                  color: Color(0xFFFF7622),
                  size: 60.0,
                ),
              ),
            );
          }
          List<ReviewsRecord> containerReviewsRecordList = snapshot.data!;
          final containerReviewsRecord = containerReviewsRecordList.isNotEmpty
              ? containerReviewsRecordList.first
              : null;

          return Container(
            width: MediaQuery.sizeOf(context).width * 1.0,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 20.0),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                    child: Text(
                      'Your word matters!',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Poppins',
                            color: Color(0xFFFF7622),
                            fontSize: 26.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                      child: RatingBar.builder(
                        onRatingUpdate: (newValue) => safeSetState(
                            () => _model.ratingBarValue = newValue),
                        itemBuilder: (context, index) => Icon(
                          Icons.star_rounded,
                          color: Color(0xFFFF7622),
                        ),
                        direction: Axis.horizontal,
                        initialRating: _model.ratingBarValue ??=
                            containerReviewsRecord!.reviewRating.toDouble(),
                        unratedColor: Color(0xFFD3D8D5),
                        itemCount: 5,
                        itemSize: 35.0,
                        glowColor: Color(0xFFFF7622),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 0.9,
                      child: TextFormField(
                        controller: _model.rvwtitleTextController ??=
                            TextEditingController(
                          text: containerReviewsRecord?.reviewtitle == null ||
                                  containerReviewsRecord?.reviewtitle == ''
                              ? ''
                              : containerReviewsRecord?.reviewtitle,
                        ),
                        focusNode: _model.rvwtitleFocusNode,
                        autofocus: true,
                        obscureText: false,
                        decoration: InputDecoration(
                          isDense: true,
                          labelStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'Poppins',
                                    color: Color(0xFF333333),
                                    fontSize: 16.0,
                                    letterSpacing: 0.0,
                                  ),
                          hintText: '“Tap on stars to create a title”',
                          hintStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'Poppins',
                                    color: Color(0xFF7C7C7C),
                                    fontSize: 16.0,
                                    letterSpacing: 0.0,
                                  ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          filled: true,
                          fillColor: Color(0xFFFFECD4),
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Sen',
                              color: Color(0xFF333222),
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w600,
                            ),
                        maxLines: 2,
                        cursorColor: Colors.black,
                        validator: _model.rvwtitleTextControllerValidator
                            .asValidator(context),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 0.9,
                      child: TextFormField(
                        controller: _model.rvwdescTextController ??=
                            TextEditingController(
                          text: containerReviewsRecord?.reviewComments ==
                                      null ||
                                  containerReviewsRecord?.reviewComments == ''
                              ? ''
                              : containerReviewsRecord?.reviewComments,
                        ),
                        focusNode: _model.rvwdescFocusNode,
                        autofocus: true,
                        obscureText: false,
                        decoration: InputDecoration(
                          isDense: true,
                          labelStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'Sen',
                                    color: Color(0xFF7C7C7C),
                                    letterSpacing: 0.0,
                                  ),
                          hintText: 'Type your feedback here',
                          hintStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'Sen',
                                    color: Color(0xFF7C7C7C),
                                    letterSpacing: 0.0,
                                  ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0x00000000),
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          filled: true,
                          fillColor: Color(0xFFFFECD4),
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Sen',
                              color: Color(0xFF333333),
                              letterSpacing: 0.0,
                            ),
                        maxLines: 5,
                        cursorColor: Colors.black,
                        validator: _model.rvwdescTextControllerValidator
                            .asValidator(context),
                      ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: FFButtonWidget(
                        onPressed: () async {
                          await containerReviewsRecord!.reference
                              .update(createReviewsRecordData(
                            reviewComments: _model.rvwdescTextController.text,
                            reviewtitle: _model.rvwtitleTextController.text,
                            reviewRating: _model.ratingBarValue?.round(),
                          ));
                          Navigator.pop(context);
                        },
                        text: 'Submit',
                        options: FFButtonOptions(
                          width: MediaQuery.sizeOf(context).width * 0.9,
                          height: 50.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 0.0, 16.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Color(0xFFFF7622),
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Poppins',
                                    color: Colors.white,
                                    fontSize: 20.0,
                                    letterSpacing: 0.0,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
