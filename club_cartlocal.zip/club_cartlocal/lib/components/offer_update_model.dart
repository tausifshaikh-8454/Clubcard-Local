import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'offer_update_widget.dart' show OfferUpdateWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OfferUpdateModel extends FlutterFlowModel<OfferUpdateWidget> {
  ///  Local state fields for this component.

  List<String> tagslist = [];
  void addToTagslist(String item) => tagslist.add(item);
  void removeFromTagslist(String item) => tagslist.remove(item);
  void removeAtIndexFromTagslist(int index) => tagslist.removeAt(index);
  void insertAtIndexInTagslist(int index, String item) =>
      tagslist.insert(index, item);
  void updateTagslistAtIndex(int index, Function(String) updateFn) =>
      tagslist[index] = updateFn(tagslist[index]);

  List<String> srttimeEdit = [];
  void addToSrttimeEdit(String item) => srttimeEdit.add(item);
  void removeFromSrttimeEdit(String item) => srttimeEdit.remove(item);
  void removeAtIndexFromSrttimeEdit(int index) => srttimeEdit.removeAt(index);
  void insertAtIndexInSrttimeEdit(int index, String item) =>
      srttimeEdit.insert(index, item);
  void updateSrttimeEditAtIndex(int index, Function(String) updateFn) =>
      srttimeEdit[index] = updateFn(srttimeEdit[index]);

  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for productname widget.
  FocusNode? productnameFocusNode;
  TextEditingController? productnameTextController;
  String? Function(BuildContext, String?)? productnameTextControllerValidator;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  DateTime? datePicked1;
  // State field(s) for Prod_RegularPrice widget.
  FocusNode? prodRegularPriceFocusNode;
  TextEditingController? prodRegularPriceTextController;
  String? Function(BuildContext, String?)?
      prodRegularPriceTextControllerValidator;
  // State field(s) for prod_saleprice widget.
  FocusNode? prodSalepriceFocusNode;
  TextEditingController? prodSalepriceTextController;
  String? Function(BuildContext, String?)? prodSalepriceTextControllerValidator;
  // State field(s) for products_tags widget.
  FocusNode? productsTagsFocusNode;
  TextEditingController? productsTagsTextController;
  String? Function(BuildContext, String?)? productsTagsTextControllerValidator;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for product_deascr widget.
  FocusNode? productDeascrFocusNode;
  TextEditingController? productDeascrTextController;
  String? Function(BuildContext, String?)? productDeascrTextControllerValidator;
  DateTime? datePicked2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    productnameFocusNode?.dispose();
    productnameTextController?.dispose();

    prodRegularPriceFocusNode?.dispose();
    prodRegularPriceTextController?.dispose();

    prodSalepriceFocusNode?.dispose();
    prodSalepriceTextController?.dispose();

    productsTagsFocusNode?.dispose();
    productsTagsTextController?.dispose();

    productDeascrFocusNode?.dispose();
    productDeascrTextController?.dispose();
  }
}
