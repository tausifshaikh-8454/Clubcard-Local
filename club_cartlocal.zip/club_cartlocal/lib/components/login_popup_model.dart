import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'login_popup_widget.dart' show LoginPopupWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoginPopupModel extends FlutterFlowModel<LoginPopupWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for emailAddresspop widget.
  FocusNode? emailAddresspopFocusNode;
  TextEditingController? emailAddresspopTextController;
  String? Function(BuildContext, String?)?
      emailAddresspopTextControllerValidator;
  // State field(s) for passwordpop widget.
  FocusNode? passwordpopFocusNode;
  TextEditingController? passwordpopTextController;
  late bool passwordpopVisibility;
  String? Function(BuildContext, String?)? passwordpopTextControllerValidator;

  @override
  void initState(BuildContext context) {
    passwordpopVisibility = false;
  }

  @override
  void dispose() {
    emailAddresspopFocusNode?.dispose();
    emailAddresspopTextController?.dispose();

    passwordpopFocusNode?.dispose();
    passwordpopTextController?.dispose();
  }
}
