import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

DateTime? stringtoTime(
  String? hourArg,
  DateTime? dateArg,
) {
  // output the combination of date from dateArg and hourArg (HH:mm format)
  if (hourArg == null || dateArg == null) {
    return null;
  }
  final hourMin = hourArg.split(':');
  final hour = int.tryParse(hourMin[0]) ?? 0;
  final minute = int.tryParse(hourMin[1]) ?? 0;
  return DateTime(dateArg.year, dateArg.month, dateArg.day, hour, minute);
}

int formFieldRepeater(List<int>? formFieldCountList) {
  return (formFieldCountList!.last + 1);
}

double? sumOfNum(List<int> ratinglist) {
  // calculate avreage rating
  if (ratinglist.isEmpty) {
    return null;
  }
  double sum = 0;
  for (int rating in ratinglist) {
    sum += rating;
  }
  return sum / ratinglist.length;
}

String? updateStatusOffer(
  DateTime? startDate,
  DateTime? endDate,
) {
  final DateTime currentDate = DateTime.now();

  if (startDate == null || endDate == null) {
    return 'Invalid Dates'; // Handle cases where dates are null
  }

  if (currentDate.isBefore(startDate)) {
    return 'Draft'; // Current date is before the start date
  } else if (currentDate.isAfter(endDate)) {
    return 'Expired'; // Current date is after the end date
  } else {
    return 'Live'; // Current date is between start and end date
  }
}

String? stringtoImagePAth(String? imagestring) {
  return imagestring;
}

String? uniqueidgen() {
  final String datePart = DateFormat('ddMM').format(DateTime.now());

  // Static variable to maintain counter state across function calls
  int counter = 0;
  counter = (counter % 999) + 1; // Increment and reset after 999

  // Ensure the number part is always three digits
  String numberPart = counter.toString().padLeft(3, '0');

  return '$datePart-$numberPart';
}
