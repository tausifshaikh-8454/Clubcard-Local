// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future updateOfferStatus(
  String? collectionName,
  String? activePeriodField,
  String? endPeriodField,
  String? statusField,
) async {
  try {
    if (collectionName == null) {
      throw ArgumentError('Collection name cannot be null.');
    }
    if (activePeriodField == null ||
        endPeriodField == null ||
        statusField == null) {
      throw ArgumentError('Field names cannot be null.');
    }

    final collection = FirebaseFirestore.instance.collection(collectionName);
    final querySnapshot = await collection.get();

    if (querySnapshot.docs.isEmpty) {
      print('No documents found in collection: $collectionName');
      return;
    }

    for (var doc in querySnapshot.docs) {
      final data = doc.data() as Map<String, dynamic>;

      if (!data.containsKey(activePeriodField) ||
          !data.containsKey(endPeriodField) ||
          !data.containsKey(statusField) ||
          data[activePeriodField] == null ||
          data[endPeriodField] == null ||
          data[statusField] == null) {
        print('Missing or null fields in document ${doc.id}: $data');
        continue;
      }

      try {
        DateTime startDate = (data[activePeriodField] as Timestamp).toDate();
        DateTime endDate = (data[endPeriodField] as Timestamp).toDate();
        DateTime currentDate = DateTime.now();
        String currentStatus = data[statusField] as String;

        String newStatus;
        if (currentStatus == 'Expired') {
          // Skip updating if the current status is already 'Expired'
          print(
              'Skipping update for document ${doc.id} as it is already Expired.');
          continue;
        }

        if (currentDate.isBefore(startDate)) {
          newStatus = 'Draft';
          // } else if (currentDate.isAfter(endDate)) {
          //   newStatus = 'Expired';
        } else if (currentDate.isAfter(
            endDate.add(Duration(days: 1)).subtract(Duration(seconds: 1)))) {
          newStatus = 'Expired';
        } else {
          newStatus = 'Live';
        }

        if (newStatus != currentStatus) {
          await collection.doc(doc.id).update({statusField: newStatus});
          print('Updated document ${doc.id} with status: $newStatus');
        } else {
          print(
              'No update needed for document ${doc.id}, status remains: $currentStatus');
        }
      } catch (e) {
        print('Failed to process document ${doc.id}: $e');
      }
    }
  } catch (e) {
    print('Error: $e');
  }
}
