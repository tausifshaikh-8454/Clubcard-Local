// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<void> updateLotteryOfferStatus() async {
  final collection = FirebaseFirestore.instance.collection('luckyDraw_Offer');
  final querySnapshot = await collection.get();

  for (var doc in querySnapshot.docs) {
    final data = doc.data();
    DateTime startDate =
        (data['lukcyDraw_Offer_active_period'] as Timestamp).toDate();
    DateTime endDate =
        (data['luckyDraw_offer_end_period'] as Timestamp).toDate();
    DateTime currentDate = DateTime.now();

    // Format to d/m/y
    DateFormat dateFormat = DateFormat('dd/MM/yyyy');
    String formattedStartDate = dateFormat.format(startDate);
    String formattedEndDate = dateFormat.format(endDate);
    String formattedCurrentDate = dateFormat.format(currentDate);

    // Parse back into DateTime
    DateTime parsedStartDate = dateFormat.parse(formattedStartDate);
    DateTime parsedEndDate = dateFormat.parse(formattedEndDate);
    DateTime parsedCurrentDate = dateFormat.parse(formattedCurrentDate);

    // Determine status
    String status;
    if (parsedCurrentDate.isBefore(parsedStartDate)) {
      status = 'Draft';
    } else if (parsedCurrentDate.isAfter(parsedEndDate)) {
      status = 'Expired';
    } else {
      status = 'Live';
    }

    // Debugging
    print('Start Date: $formattedStartDate');
    print('End Date: $formattedEndDate');
    print('Current Date: $formattedCurrentDate');
    print('Calculated Status: $status');

    // Update Firestore
    await collection.doc(doc.id).update({'lukcyDraw_Offer_status': status});
  }
}
