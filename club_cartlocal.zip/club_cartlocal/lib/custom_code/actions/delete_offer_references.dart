// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> deleteOfferReferences(String offerId) async {
  try {
    // Reference to the 'customer-details' collection
    final customerCollection =
        FirebaseFirestore.instance.collection('customer-details');

    // Get all documents in the 'customer-details' collection
    final customerDocs = await customerCollection.get();

    for (var customerDoc in customerDocs.docs) {
      // Reference to the 'wishList_offers' subcollection
      final wishListCollection =
          customerDoc.reference.collection('wishList_offers');

      // Query documents where 'wishlisted_offer' matches the offerId
      final querySnapshot = await wishListCollection
          .where('wishlisted_offer', isEqualTo: offerId)
          .get();

      // Delete matching documents
      for (var doc in querySnapshot.docs) {
        await doc.reference.delete();
      }
    }

    print('Successfully deleted references to offerId: $offerId');
  } catch (e) {
    print('Error deleting references: $e');
    throw Exception('Failed to delete offer references');
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
