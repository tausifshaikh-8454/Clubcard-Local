// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:math';

Future<String?> generateUniqueUserId() async {
  final String datePart = DateFormat('yyMM').format(DateTime.now());
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  Random random = Random();

  while (true) {
    int randomNumber =
        random.nextInt(999) + 1; // Generates number from 1 to 999
    String numberPart =
        randomNumber.toString().padLeft(3, '0'); // Ensures 3 digits
    String uniqueId = '$datePart-$numberPart';

    // Check if the ID already exists in Firestore
    QuerySnapshot query = await firestore
        .collection('users')
        .where('user_id', isEqualTo: uniqueId)
        .get();

    if (query.docs.isEmpty) {
      return uniqueId; // If ID does not exist, return it
    }
  }
}
