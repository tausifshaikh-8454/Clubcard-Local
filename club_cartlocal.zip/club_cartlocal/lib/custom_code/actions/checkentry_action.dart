// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<bool> checkentryAction(String? email) async {
  try {
    // Query Firestore to find a document where 'Cust_email' equals the provided email
    final QuerySnapshot<Map<String, dynamic>> result = await FirebaseFirestore
        .instance
        .collection('customer-details') // Specify the collection name
        .where('cust_email',
            isEqualTo: email) // Add a filter for the 'Cust_email' field
        .get();

    // Check if any documents were returned
    return result.docs.isNotEmpty;
  } catch (e) {
    // Handle any errors during the Firestore query
    print('Error checking email: $e');
    return false;
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
