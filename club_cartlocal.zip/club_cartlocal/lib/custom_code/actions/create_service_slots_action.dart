// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future createServiceSlotsAction(
  List<String> startTimes,
  DocumentReference vendRef,
  DocumentReference offerRef,
  DateTime serviceDate,
) async {
  try {
    // Get reference to the "service_slots" collection
    final serviceSlotsCollection =
        FirebaseFirestore.instance.collection('service_Slots');

    // Iterate over the startTime list and create documents
    for (String time in startTimes) {
      await serviceSlotsCollection.add({
        'vend_ref': vendRef, // Vendor reference
        'timeSlots': time, // Time slot
        'offerref': offerRef, // Offer reference
        'isslotbooked': false, // Whether the slot is booked or not
        'ServiceDate': serviceDate, // Date of service
        'created_at': FieldValue.serverTimestamp(), // Optional timestamp field
      });
    }
  } catch (e) {
    print('Error creating service slots: $e');
    throw e;
  }
}
