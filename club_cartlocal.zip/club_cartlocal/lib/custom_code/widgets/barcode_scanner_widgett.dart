// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:url_launcher/url_launcher.dart';

class BarcodeScannerWidgett extends StatefulWidget {
  const BarcodeScannerWidgett({
    super.key,
    this.width,
    this.height,
    required this.onBarcodeScanned,
  });

  final double? width;
  final double? height;
  final Future Function(String barcode) onBarcodeScanned;

  @override
  State<BarcodeScannerWidgett> createState() => _BarcodeScannerWidgettState();
}

class _BarcodeScannerWidgettState extends State<BarcodeScannerWidgett>
    with WidgetsBindingObserver {
  MobileScannerController controller = MobileScannerController();
  StreamSubscription<Object?>? _subscription;
  String? _lastScannedCode;
  DateTime? _lastScanTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _subscription = controller.barcodes.listen(_handleBarcode);
    controller.start();
  }

  void _handleBarcode(BarcodeCapture capture) async {
    final barcode = capture.barcodes.first;
    final barcodeValue = barcode.rawValue;

    if (barcodeValue != null &&
        (barcodeValue != _lastScannedCode ||
            DateTime.now()
                    .difference(_lastScanTime ?? DateTime.now())
                    .inSeconds >
                5)) {
      setState(() {
        _lastScannedCode = barcodeValue;
        _lastScanTime = DateTime.now();
      });

      // Attempt to launch the URL
      if (await canLaunchUrl(Uri.parse(barcodeValue))) {
        await launchUrl(Uri.parse(barcodeValue));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Scanned value is not a valid URL: $barcodeValue'),
            duration: const Duration(seconds: 2),
          ),
        );
      }

      // Trigger the callback for additional actions
      await widget.onBarcodeScanned(barcodeValue);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (!controller.value.isInitialized) return;
    switch (state) {
      case AppLifecycleState.resumed:
        _subscription = controller.barcodes.listen(_handleBarcode);
        controller.start();
        break;
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
        _subscription?.cancel();
        _subscription = null;
        controller.stop();
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _subscription?.cancel();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: MobileScanner(
        controller: controller,
        overlayBuilder: (context, constraints) {
          return Container(
            alignment: Alignment.center,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.red,
                  width: 3,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
