// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:crop_your_image/crop_your_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';
import 'dart:math';

class CustomImageCropper extends StatefulWidget {
  const CustomImageCropper({
    super.key,
    this.width,
    this.height,
    required this.imageUrl,
    required this.onCropComplete, // Callback to return cropped image URL
  });

  final double? width;
  final double? height;
  final String imageUrl;
  final Function(String) onCropComplete; // Callback for cropped image URL

  @override
  State<CustomImageCropper> createState() => _CustomImageCropperState();
}

class _CustomImageCropperState extends State<CustomImageCropper> {
  final CropController _controller = CropController();
  bool isLoaded = false;
  Uint8List? imageBytes;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  Future<void> _loadImage() async {
    try {
      final response = await http.get(Uri.parse(widget.imageUrl));
      if (response.statusCode == 200) {
        setState(() {
          imageBytes = response.bodyBytes;
          isLoaded = true;
        });
      } else {
        print("Failed to load image. Status Code: ${response.statusCode}");
      }
    } catch (e) {
      print("Error loading image: $e");
    }
  }

  Future<void> _uploadToFirebase(Uint8List croppedData) async {
    try {
      String fileName = "cropped_${Random().nextInt(100000)}.png";
      Reference ref =
          FirebaseStorage.instance.ref().child("cropped_images/$fileName");
      UploadTask uploadTask =
          ref.putData(croppedData, SettableMetadata(contentType: 'image/png'));

      TaskSnapshot snapshot = await uploadTask;
      String downloadURL = await snapshot.ref.getDownloadURL();

      // Send cropped image URL to parent via callback
      widget.onCropComplete(downloadURL);
    } catch (e) {
      print("Upload Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return isLoaded && imageBytes != null
        ? Container(
            width: widget.width ?? double.infinity,
            height: widget.height ?? double.infinity,
            child: Column(
              children: [
                Expanded(
                  child: Crop(
                    controller: _controller,
                    image: imageBytes!,
                    aspectRatio: 1, // Fixed 1:1 Ratio (1200x1200)
                    initialSize: 0.8,
                    interactive: true,
                    onCropped: (croppedData) {
                      _uploadToFirebase(croppedData);
                    },
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _controller.crop(),
                  child: Text("Crop & Upload"),
                ),
              ],
            ),
          )
        : Center(child: CircularProgressIndicator());
  }
}
