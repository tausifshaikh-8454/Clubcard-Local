// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';

class PhoneNumberPicker extends StatefulWidget {
  const PhoneNumberPicker({
    super.key,
    this.width,
    this.height,
    this.onPhoneNumberSaved,
  });

  final double? width;
  final double? height;
  final void Function(String phoneNumber)? onPhoneNumberSaved;

  @override
  State<PhoneNumberPicker> createState() => _PhoneNumberPickerState();
}

class _PhoneNumberPickerState extends State<PhoneNumberPicker> {
  String? _completePhoneNumber; // Store number in widget state

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width ?? double.infinity,
      height: widget.height,
      child: IntlPhoneField(
        decoration: InputDecoration(
          labelText: 'Enter Your Mobile Number',
          labelStyle: const TextStyle(
              color: Color.fromARGB(255, 189, 189, 189), fontSize: 18),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color.fromARGB(20, 0, 0, 0)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color.fromARGB(20, 0, 0, 0)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
                color: Color.fromARGB(255, 255, 119, 34), width: 1),
          ),
          filled: true,
          fillColor: Colors.white,
          prefixIcon: const Icon(Icons.phone, color: Colors.orange),
        ),
        initialCountryCode: "GB",
        languageCode: "en",
        dropdownIconPosition: IconPosition.leading,
        dropdownTextStyle: const TextStyle(fontSize: 16, color: Colors.black),
        style: const TextStyle(fontSize: 18, color: Colors.black),
        cursorColor: const Color.fromARGB(255, 255, 119, 34),
        disableLengthCheck: true,
        validator: (phone) {
          if (phone == null ||
              phone.number.isEmpty ||
              phone.number.length < 10 ||
              phone.number.length > 15) {
            return 'Enter a valid phone number (10-15 digits)';
          }
          return null;
        },
        onChanged: (PhoneNumber phone) {
          setState(() {
            _completePhoneNumber = phone.completeNumber;
          });

          // Automatically pass the number whenever the user types
          if (widget.onPhoneNumberSaved != null &&
              _completePhoneNumber != null) {
            widget.onPhoneNumberSaved!(_completePhoneNumber!);
          }
        },
        onCountryChanged: (country) {
          debugPrint('Country changed to: ${country.name}');
        },
      ),
    );
  }

  // Function to access the stored phone number from widget state
  String? getCompletePhoneNumber() {
    return _completePhoneNumber;
  }
}
