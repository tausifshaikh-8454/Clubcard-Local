// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async'; // Import necessary libraries
import 'package:url_launcher/url_launcher.dart'; // Import url_launcher
import 'package:mobile_scanner/mobile_scanner.dart';

class QRScannerWidget extends StatefulWidget {
  const QRScannerWidget({
    Key? key,
    this.width,
    this.height,
  }) : super(key: key);

  final double? width;
  final double? height;

  @override
  _QRScannerWidgetState createState() => _QRScannerWidgetState();
}

class _QRScannerWidgetState extends State<QRScannerWidget> {
  MobileScannerController controller = MobileScannerController();
  StreamSubscription<Object?>? _subscription;
  String? _lastScannedCode; // Store the scanned QR code value
  DateTime? _lastScanTime; // Store the time of the last scan

  @override
  void initState() {
    super.initState();
    _subscription = controller.barcodes.listen(_handleBarcode);
    controller.start();
  }

  // Handle barcode scanning and store value in the widget's state
  void _handleBarcode(BarcodeCapture capture) {
    final barcode = capture.barcodes.first;
    final barcodeValue = barcode.rawValue;

    // Check if the value is valid and store it if it's different from the last one
    if (barcodeValue != null &&
        (barcodeValue != _lastScannedCode ||
            DateTime.now()
                    .difference(_lastScanTime ?? DateTime.now())
                    .inSeconds >
                5)) {
      setState(() {
        _lastScannedCode = barcodeValue; // Store the scanned value
        _lastScanTime = DateTime.now(); // Update the time of the scan
      });

      // Automatically launch the URL if the scanned code is a valid URL
      _launchURL(barcodeValue);
    }
  }

  // Method to launch a URL using the url_launcher package
  Future<void> _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      // Handle error if URL can't be launched
      print('Could not launch $url');
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: widget.width,
          height: widget.height,
          child: MobileScanner(
            controller: controller,
            overlayBuilder: (context, constraints) {
              return Container(
                alignment: Alignment.center,
                child: Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.red,
                      width: 3,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        // Display the scanned QR code value if available
        _lastScannedCode != null
            ? GestureDetector(
                onTap: () {
                  // Launch URL when user taps on the displayed QR code text
                  _launchURL(_lastScannedCode!);
                },
                child: Text(
                  'Scanned Code: $_lastScannedCode',
                  style: TextStyle(
                    color: Colors.blue,
                    decoration: TextDecoration.underline,
                  ),
                ),
              )
            : Text('No QR scanned yet.'),
      ],
    );
  }
}

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
