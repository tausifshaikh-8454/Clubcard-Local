// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class DateRangePicker extends StatefulWidget {
  const DateRangePicker({
    super.key,
    this.width,
    this.height,
    required this.pickStartDate,
    required this.pickEndDate,
    this.calendarBackgroundColor = Colors.white,
    this.dateColor = Colors.black,
    this.rangeColor = Colors.blue,
    this.labelText = "Pick a Date Range",
  });

  final double? width;
  final double? height;
  final Future Function(DateTime startDate) pickStartDate;
  final Future Function(DateTime endDate) pickEndDate;
  final Color calendarBackgroundColor;
  final Color dateColor;
  final Color rangeColor;
  final String labelText;

  @override
  State<DateRangePicker> createState() => _DateRangePickerState();
}

class _DateRangePickerState extends State<DateRangePicker> {
  DateTime? _startDate;
  DateTime? _endDate;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _selectDateRange,
      child: Container(
        width: widget.width ?? 300,
        height: widget.height ?? 350,
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: widget.calendarBackgroundColor,
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              _startDate == null || _endDate == null
                  ? widget.labelText
                  : '${_startDate!.toLocal()}'.split(' ')[0] +
                      ' - ' +
                      '${_endDate!.toLocal()}'.split(' ')[0],
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: widget.dateColor,
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: GridView.builder(
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                ),
                itemCount: 31,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                    decoration: BoxDecoration(
                      color: index % 7 == 0
                          ? widget.rangeColor.withOpacity(0.2)
                          : widget.calendarBackgroundColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Center(
                      child: Text(
                        '${index + 1}',
                        style: TextStyle(color: widget.dateColor),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDateRange() async {
    final DateTime now = DateTime.now();
    final DateTime firstDayOfMonth = DateTime(now.year, now.month, 1);
    final DateTime lastDayOfMonth = DateTime(now.year, now.month + 1, 0);

    final DateTimeRange? pickedDateRange = await showDateRangePicker(
      context: context,
      initialDateRange: _startDate != null && _endDate != null
          ? DateTimeRange(start: _startDate!, end: _endDate!)
          : DateTimeRange(start: now, end: now.add(Duration(days: 7))),
      firstDate: DateTime(now.year - 1), // Allow navigation for past 5 years
      lastDate: DateTime(now.year + 1), // Allow navigation for next 5 years
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: widget.rangeColor,
            colorScheme: ColorScheme.light(
              primary: widget.rangeColor,
              onPrimary: widget.dateColor,
              surface: widget.calendarBackgroundColor,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: widget.rangeColor,
              ),
            ),
          ),
          child: Dialog(
            child: Container(
              width: 500,
              height: 500,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back, color: widget.rangeColor),
                        onPressed: () {
                          Navigator.pop(context);
                          _selectDateRange();
                        },
                      ),
                      Text(
                        "Select Date Range",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: widget.dateColor,
                        ),
                      ),
                      IconButton(
                        icon:
                            Icon(Icons.arrow_forward, color: widget.rangeColor),
                        onPressed: () {
                          Navigator.pop(context);
                          _selectDateRange();
                        },
                      ),
                    ],
                  ),
                  Expanded(child: child!),
                ],
              ),
            ),
          ),
        );
      },
    );

    if (pickedDateRange != null) {
      setState(() {
        _startDate = pickedDateRange.start;
        _endDate = pickedDateRange.end;
      });

      await widget.pickStartDate(_startDate!);
      await widget.pickEndDate(_endDate!);
    }
  }
}
