// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:typed_data';
import 'package:crop_your_image/crop_your_image.dart';
import 'package:firebase_storage/firebase_storage.dart';

class ImageCropper extends StatefulWidget {
  const ImageCropper({
    super.key,
    this.width,
    this.height,
    this.imageUrl,
    this.callBackAction,
  });

  final double? width;
  final double? height;
  final String? imageUrl;
  final Future Function(String? url)? callBackAction;

  @override
  State<ImageCropper> createState() => _ImageCropperState();
}

class _ImageCropperState extends State<ImageCropper> {
  bool loading = false;
  final _cropController = CropController();
  Uint8List? _imageBytes;

  @override
  void initState() {
    super.initState();
    _loadImageFromFirebase();
  }

  Future<void> _loadImageFromFirebase() async {
    if (widget.imageUrl != null) {
      try {
        final ref = FirebaseStorage.instance.refFromURL(widget.imageUrl!);
        final imageBytes = await ref.getData();
        setState(() {
          _imageBytes = imageBytes;
        });
      } catch (e) {
        print('Error loading image from Firebase: \$e');
      }
    }
  }

  Future<String?> uploadData(String path, Uint8List imageData) async {
    try {
      final ref = FirebaseStorage.instance.ref(path);
      final uploadTask = ref.putData(imageData);
      final snapshot = await uploadTask.whenComplete(() => null);
      final downloadUrl = await snapshot.ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      print('Error uploading image: \$e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: widget.width ?? 500,
              height: widget.height ?? 500,
              child: Center(
                child: _imageBytes == null
                    ? const CircularProgressIndicator()
                    : Crop(
                        image: _imageBytes!,
                        controller: _cropController,
                        onCropped: (image) async {
                          try {
                            final path = _getStoragePath(widget.imageUrl!);
                            final url = await uploadData(path, image);
                            if (url != null) {
                              widget.callBackAction?.call(url);
                            }
                          } catch (e) {
                            print('Error uploading image: \$e');
                          } finally {
                            setState(() {
                              loading = false;
                            });
                          }
                        },
                        aspectRatio: 1.0,
                        initialSize: 0.8,
                        interactive: true,
                        baseColor: Theme.of(context).scaffoldBackgroundColor,
                        maskColor: Theme.of(context)
                            .scaffoldBackgroundColor
                            .withAlpha(100),
                        cornerDotBuilder: (size, edgeAlignment) =>
                            const DotControl(color: Colors.white),
                      ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
              child: ElevatedButton(
                onPressed: loading
                    ? null
                    : () {
                        setState(() {
                          loading = true;
                        });
                        _cropController.crop();
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
                child: Container(
                  width: 250,
                  height: 50,
                  alignment: Alignment.center,
                  child: loading
                      ? const CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        )
                      : Text(
                          'Set',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.normal,
                                  ),
                        ),
                ),
              ),
            ),
          ],
        ),
        Positioned(
          top: 4,
          right: 4,
          child: IconButton(
            icon: const Icon(Icons.close),
            onPressed: () => Navigator.pop(context),
          ),
        ),
      ],
    );
  }

  String _getStoragePath(String filePath) {
    final timestamp = DateTime.now().microsecondsSinceEpoch;
    final prefix = 'cropped-';
    final ext = filePath.split('.').last;
    return 'uploads/\$prefix\$timestamp.\$ext';
  }
}
