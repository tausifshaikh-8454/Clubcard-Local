// Export pages
export '/customer/customersignup/customersignup_widget.dart'
    show CustomersignupWidget;
export '/vendorpages/vendorsignup/vendorsignup_widget.dart'
    show VendorsignupWidget;
export '/customer/cust_profilepage/cust_profilepage_widget.dart'
    show CustProfilepageWidget;
export '/vendorpages/offeraddingpage/offeraddingpage_widget.dart'
    show OfferaddingpageWidget;
export '/vendorpages/offer_listing_page/offer_listing_page_widget.dart'
    show OfferListingPageWidget;
export '/vendorpages/vendor_dashboard/vendor_dashboard_widget.dart'
    show VendorDashboardWidget;
export '/customer/shop_detailpage/shop_detailpage_widget.dart'
    show ShopDetailpageWidget;
export '/customer/homepage/homepage_widget.dart' show HomepageWidget;
export '/vendorpages/vendor_profilepage/vendor_profilepage_widget.dart'
    show VendorProfilepageWidget;
export '/customer/offer_detailpage/offer_detailpage_widget.dart'
    show OfferDetailpageWidget;
export '/vendorpages/vendor_followers/vendor_followers_widget.dart'
    show VendorFollowersWidget;
export '/customer/shop_review/shop_review_widget.dart' show ShopReviewWidget;
export '/vendorpages/review_forshop/review_forshop_widget.dart'
    show ReviewForshopWidget;
export '/customer/loginforall/loginforall_widget.dart' show LoginforallWidget;
export '/vendorpages/notifi_to_customer/notifi_to_customer_widget.dart'
    show NotifiToCustomerWidget;
export '/vendorpages/vendapointmencreation/vendapointmencreation_widget.dart'
    show VendapointmencreationWidget;
export '/customer/cust_booking/cust_booking_widget.dart' show CustBookingWidget;
export '/customer/cust_thankyou_booking/cust_thankyou_booking_widget.dart'
    show CustThankyouBookingWidget;
export '/vendorpages/vend_subscription/vend_subscription_widget.dart'
    show VendSubscriptionWidget;
export '/vendorpages/vendsuccess/vendsuccess_widget.dart'
    show VendsuccessWidget;
export '/vendorpages/vend_paymentfailed/vend_paymentfailed_widget.dart'
    show VendPaymentfailedWidget;
export '/customer/cust_intro/cust_intro_widget.dart' show CustIntroWidget;
export '/customer/user_select/user_select_widget.dart' show UserSelectWidget;
export '/customer/cust_registration_method/cust_registration_method_widget.dart'
    show CustRegistrationMethodWidget;
export '/customer/cust_activities/cust_activities_widget.dart'
    show CustActivitiesWidget;
export '/customer/cust_wishlist/cust_wishlist_widget.dart'
    show CustWishlistWidget;
export '/vendorpages/service_listspage/service_listspage_widget.dart'
    show ServiceListspageWidget;
export '/customer/forgotpass/forgotpass_widget.dart' show ForgotpassWidget;
export '/customer/cust_bookinglist/cust_bookinglist_widget.dart'
    show CustBookinglistWidget;
export '/vendorpages/vend_booking_l_ist/vend_booking_l_ist_widget.dart'
    show VendBookingLIstWidget;
export '/vendorpages/vend_billingdetails/vend_billingdetails_widget.dart'
    show VendBillingdetailsWidget;
export '/customer/scannerpage/scannerpage_widget.dart' show ScannerpageWidget;
export '/vendorpages/lotteryadding/lotteryadding_widget.dart'
    show LotteryaddingWidget;
export '/vendorpages/lottery_list/lottery_list_widget.dart'
    show LotteryListWidget;
export '/vendorpages/lotterydetailpage/lotterydetailpage_widget.dart'
    show LotterydetailpageWidget;
export '/vendorpages/lottrey_contestant_list/lottrey_contestant_list_widget.dart'
    show LottreyContestantListWidget;
export '/cropimg/cropimg_widget.dart' show CropimgWidget;
export '/vendorpages/vendorusersignup/vendorusersignup_widget.dart'
    show VendorusersignupWidget;
export '/customer/cust_notifica/cust_notifica_widget.dart'
    show CustNotificaWidget;
export '/vendorpages/vend_subs_test/vend_subs_test_widget.dart'
    show VendSubsTestWidget;
