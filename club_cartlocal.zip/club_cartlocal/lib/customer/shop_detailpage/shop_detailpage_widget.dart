import '/auth/base_auth_user_provider.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/login_popup_widget.dart';
import '/components/shop_edit_review_popup_widget.dart';
import '/components/shop_new_review_popup_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:badges/badges.dart' as badges;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'shop_detailpage_model.dart';
export 'shop_detailpage_model.dart';

class ShopDetailpageWidget extends StatefulWidget {
  const ShopDetailpageWidget({
    super.key,
    required this.venid,
  });

  final String? venid;

  static String routeName = 'shopDetailpage';
  static String routePath = '/shopDetailpage';

  @override
  State<ShopDetailpageWidget> createState() => _ShopDetailpageWidgetState();
}

class _ShopDetailpageWidgetState extends State<ShopDetailpageWidget> {
  late ShopDetailpageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ShopDetailpageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (loggedIn) {
        return;
      }

      await showDialog(
        barrierColor: Color(0x83F2F2F2),
        barrierDismissible: false,
        context: context,
        builder: (dialogContext) {
          return Dialog(
            elevation: 0,
            insetPadding: EdgeInsets.zero,
            backgroundColor: Colors.transparent,
            alignment: AlignmentDirectional(0.0, 0.0)
                .resolve(Directionality.of(context)),
            child: Container(
              height: 400.0,
              width: 340.0,
              child: LoginPopupWidget(
                vend: widget!.venid!,
              ),
            ),
          );
        },
      );

      safeSetState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) => StreamBuilder<List<VendorDetailsRecord>>(
        stream: queryVendorDetailsRecord(
          queryBuilder: (vendorDetailsRecord) => vendorDetailsRecord.where(
            'vendor_id',
            isEqualTo: widget!.venid != '' ? widget!.venid : null,
          ),
          singleRecord: true,
        ),
        builder: (context, snapshot) {
          // Customize what your widget looks like when it's loading.
          if (!snapshot.hasData) {
            return Scaffold(
              backgroundColor: Colors.white,
              body: Center(
                child: SizedBox(
                  width: 60.0,
                  height: 60.0,
                  child: SpinKitRipple(
                    color: Color(0xFFFF7622),
                    size: 60.0,
                  ),
                ),
              ),
            );
          }
          List<VendorDetailsRecord> shopDetailpageVendorDetailsRecordList =
              snapshot.data!;
          final shopDetailpageVendorDetailsRecord =
              shopDetailpageVendorDetailsRecordList.isNotEmpty
                  ? shopDetailpageVendorDetailsRecordList.first
                  : null;

          return Title(
              title: 'shopDetailpage',
              color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
              child: Scaffold(
                key: scaffoldKey,
                backgroundColor: Colors.white,
                floatingActionButton: Align(
                  alignment: AlignmentDirectional(-0.85, -0.9),
                  child: FloatingActionButton(
                    onPressed: () async {
                      context.safePop();
                    },
                    backgroundColor: Colors.white,
                    elevation: 8.0,
                    child: Icon(
                      Icons.arrow_back_rounded,
                      color: Colors.black,
                      size: 26.0,
                    ),
                  ),
                ),
                body: SafeArea(
                  top: true,
                  child: SingleChildScrollView(
                    primary: false,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.0, 0.0),
                          child: Container(
                            width: valueOrDefault<double>(
                              () {
                                if (MediaQuery.sizeOf(context).width <
                                    kBreakpointSmall) {
                                  return MediaQuery.sizeOf(context).width;
                                } else if (MediaQuery.sizeOf(context).width <
                                    kBreakpointMedium) {
                                  return (MediaQuery.sizeOf(context).width *
                                      0.5);
                                } else if (MediaQuery.sizeOf(context).width <
                                    kBreakpointLarge) {
                                  return (MediaQuery.sizeOf(context).width *
                                      0.7);
                                } else {
                                  return 500.0;
                                }
                              }(),
                              500.0,
                            ),
                            decoration: BoxDecoration(),
                            child: StreamBuilder<List<CustomerDetailsRecord>>(
                              stream: queryCustomerDetailsRecord(
                                queryBuilder: (customerDetailsRecord) =>
                                    customerDetailsRecord.where(
                                  'cust_email',
                                  isEqualTo: currentUserEmail,
                                ),
                                singleRecord: true,
                              ),
                              builder: (context, snapshot) {
                                // Customize what your widget looks like when it's loading.
                                if (!snapshot.hasData) {
                                  return Center(
                                    child: SizedBox(
                                      width: 60.0,
                                      height: 60.0,
                                      child: SpinKitRipple(
                                        color: Color(0xFFFF7622),
                                        size: 60.0,
                                      ),
                                    ),
                                  );
                                }
                                List<CustomerDetailsRecord>
                                    containerCustomerDetailsRecordList =
                                    snapshot.data!;
                                final containerCustomerDetailsRecord =
                                    containerCustomerDetailsRecordList
                                            .isNotEmpty
                                        ? containerCustomerDetailsRecordList
                                            .first
                                        : null;

                                return Container(
                                  width: MediaQuery.sizeOf(context).width * 1.0,
                                  decoration: BoxDecoration(),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              width: MediaQuery.sizeOf(context)
                                                      .width *
                                                  1.0,
                                              height: 380.0,
                                              decoration: BoxDecoration(
                                                color: Color(0xFFFFECD4),
                                                image: DecorationImage(
                                                  fit: BoxFit.contain,
                                                  alignment:
                                                      AlignmentDirectional(
                                                          0.0, 0.0),
                                                  image: Image.network(
                                                    valueOrDefault<String>(
                                                      shopDetailpageVendorDetailsRecord
                                                          ?.businessProfileImage,
                                                      'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                    ),
                                                  ).image,
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(16.0, 26.0,
                                                          16.0, 0.0),
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        0.9,
                                                    decoration: BoxDecoration(
                                                      color: Colors.white,
                                                    ),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Expanded(
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        24.0),
                                                            child: Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  1.0,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Color(
                                                                    0xFFF5F5F5),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10.0),
                                                              ),
                                                              child: Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        16.0,
                                                                        0.0,
                                                                        16.0),
                                                                child: Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceEvenly,
                                                                  children: [
                                                                    Expanded(
                                                                      flex: 1,
                                                                      child: FutureBuilder<
                                                                          int>(
                                                                        future:
                                                                            queryFollowedUserRecordCount(
                                                                          queryBuilder: (followedUserRecord) =>
                                                                              followedUserRecord.where(
                                                                            'Vend_ref',
                                                                            isEqualTo:
                                                                                shopDetailpageVendorDetailsRecord?.reference,
                                                                          ),
                                                                        ),
                                                                        builder:
                                                                            (context,
                                                                                snapshot) {
                                                                          // Customize what your widget looks like when it's loading.
                                                                          if (!snapshot
                                                                              .hasData) {
                                                                            return Center(
                                                                              child: SizedBox(
                                                                                width: 60.0,
                                                                                height: 60.0,
                                                                                child: SpinKitRipple(
                                                                                  color: Color(0xFFFF7622),
                                                                                  size: 60.0,
                                                                                ),
                                                                              ),
                                                                            );
                                                                          }
                                                                          int containerCount =
                                                                              snapshot.data!;

                                                                          return Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(),
                                                                            child:
                                                                                Column(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              children: [
                                                                                Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                  child: Text(
                                                                                    'Followers',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                                Text(
                                                                                  formatNumber(
                                                                                    containerCount,
                                                                                    formatType: FormatType.compact,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width:
                                                                          1.0,
                                                                      height:
                                                                          50.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Color(
                                                                            0xFFDCDCDC),
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      child: FutureBuilder<
                                                                          int>(
                                                                        future:
                                                                            queryReviewsRecordCount(
                                                                          queryBuilder: (reviewsRecord) =>
                                                                              reviewsRecord.where(
                                                                            'VendorId',
                                                                            isEqualTo:
                                                                                shopDetailpageVendorDetailsRecord?.vendorId,
                                                                          ),
                                                                        ),
                                                                        builder:
                                                                            (context,
                                                                                snapshot) {
                                                                          // Customize what your widget looks like when it's loading.
                                                                          if (!snapshot
                                                                              .hasData) {
                                                                            return Center(
                                                                              child: SizedBox(
                                                                                width: 60.0,
                                                                                height: 60.0,
                                                                                child: SpinKitRipple(
                                                                                  color: Color(0xFFFF7622),
                                                                                  size: 60.0,
                                                                                ),
                                                                              ),
                                                                            );
                                                                          }
                                                                          int containerCount =
                                                                              snapshot.data!;

                                                                          return Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(),
                                                                            child:
                                                                                Column(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              children: [
                                                                                Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                  child: Text(
                                                                                    'Reviews',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                                Text(
                                                                                  formatNumber(
                                                                                    containerCount,
                                                                                    formatType: FormatType.compact,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width:
                                                                          1.0,
                                                                      height:
                                                                          50.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Color(
                                                                            0xFFDCDCDC),
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      child: FutureBuilder<
                                                                          int>(
                                                                        future:
                                                                            queryOffersCollectionRecordCount(
                                                                          queryBuilder: (offersCollectionRecord) => offersCollectionRecord
                                                                              .where(
                                                                                'Vendor_id',
                                                                                isEqualTo: shopDetailpageVendorDetailsRecord?.vendorId,
                                                                              )
                                                                              .where(
                                                                                'offer_status',
                                                                                isEqualTo: 'Live',
                                                                              ),
                                                                        ),
                                                                        builder:
                                                                            (context,
                                                                                snapshot) {
                                                                          // Customize what your widget looks like when it's loading.
                                                                          if (!snapshot
                                                                              .hasData) {
                                                                            return Center(
                                                                              child: SizedBox(
                                                                                width: 60.0,
                                                                                height: 60.0,
                                                                                child: SpinKitRipple(
                                                                                  color: Color(0xFFFF7622),
                                                                                  size: 60.0,
                                                                                ),
                                                                              ),
                                                                            );
                                                                          }
                                                                          int containerCount =
                                                                              snapshot.data!;

                                                                          return Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 0.25,
                                                                            decoration:
                                                                                BoxDecoration(),
                                                                            child:
                                                                                Column(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              children: [
                                                                                Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                  child: Text(
                                                                                    'Offers',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                                Text(
                                                                                  formatNumber(
                                                                                    containerCount,
                                                                                    formatType: FormatType.compact,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      26.0),
                                                          child: Container(
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                1.0,
                                                            decoration:
                                                                BoxDecoration(),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                Expanded(
                                                                  child:
                                                                      Container(
                                                                    width: MediaQuery.sizeOf(context)
                                                                            .width *
                                                                        0.5,
                                                                    decoration:
                                                                        BoxDecoration(),
                                                                    child: Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              10.0,
                                                                              0.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                50.0,
                                                                            height:
                                                                                50.0,
                                                                            clipBehavior:
                                                                                Clip.antiAlias,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              shape: BoxShape.circle,
                                                                            ),
                                                                            child:
                                                                                Image.network(
                                                                              valueOrDefault<String>(
                                                                                shopDetailpageVendorDetailsRecord?.businessProfileLogo,
                                                                                'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                              ),
                                                                              fit: BoxFit.cover,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Flexible(
                                                                          child:
                                                                              Text(
                                                                            valueOrDefault<String>(
                                                                              shopDetailpageVendorDetailsRecord?.businessName,
                                                                              ' Shop Name',
                                                                            ),
                                                                            textAlign:
                                                                                TextAlign.start,
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  fontFamily: 'Poppins',
                                                                                  color: Color(0xFF464646),
                                                                                  fontSize: 20.0,
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      AlignmentDirectional(
                                                                          1.0,
                                                                          0.0),
                                                                  child: StreamBuilder<
                                                                      List<
                                                                          ReviewsRecord>>(
                                                                    stream:
                                                                        queryReviewsRecord(
                                                                      parent: shopDetailpageVendorDetailsRecord
                                                                          ?.reference,
                                                                    ),
                                                                    builder:
                                                                        (context,
                                                                            snapshot) {
                                                                      // Customize what your widget looks like when it's loading.
                                                                      if (!snapshot
                                                                          .hasData) {
                                                                        return Center(
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                60.0,
                                                                            height:
                                                                                60.0,
                                                                            child:
                                                                                SpinKitRipple(
                                                                              color: Color(0xFFFF7622),
                                                                              size: 60.0,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }
                                                                      List<ReviewsRecord>
                                                                          containerReviewsRecordList =
                                                                          snapshot
                                                                              .data!;

                                                                      return Container(
                                                                        decoration:
                                                                            BoxDecoration(),
                                                                        child:
                                                                            Container(
                                                                          decoration:
                                                                              BoxDecoration(),
                                                                          child:
                                                                              Column(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            children: [
                                                                              RatingBarIndicator(
                                                                                itemBuilder: (context, index) => Icon(
                                                                                  Icons.star_rounded,
                                                                                  color: Color(0xFFFF7622),
                                                                                ),
                                                                                direction: Axis.horizontal,
                                                                                rating: valueOrDefault<double>(
                                                                                  functions.sumOfNum(containerReviewsRecordList.map((e) => e.reviewRating).toList()),
                                                                                  0.0,
                                                                                ),
                                                                                unratedColor: Color(0xFFDCDCDC),
                                                                                itemCount: 5,
                                                                                itemSize: 20.0,
                                                                              ),
                                                                              Container(
                                                                                decoration: BoxDecoration(),
                                                                                child: Visibility(
                                                                                  visible: !(containerReviewsRecordList.where((e) => e.custId == containerCustomerDetailsRecord?.custUserid).toList().isNotEmpty) && (valueOrDefault(currentUserDocument?.userType, '') == 'Customer') ? true : false,
                                                                                  child: Builder(
                                                                                    builder: (context) => AuthUserStreamWidget(
                                                                                      builder: (context) => InkWell(
                                                                                        splashColor: Colors.transparent,
                                                                                        focusColor: Colors.transparent,
                                                                                        hoverColor: Colors.transparent,
                                                                                        highlightColor: Colors.transparent,
                                                                                        onTap: () async {
                                                                                          await showDialog(
                                                                                            barrierColor: Color(0xC4F2F2F2),
                                                                                            context: context,
                                                                                            builder: (dialogContext) {
                                                                                              return Dialog(
                                                                                                elevation: 0,
                                                                                                insetPadding: EdgeInsets.zero,
                                                                                                backgroundColor: Colors.transparent,
                                                                                                alignment: AlignmentDirectional(0.0, 0.0).resolve(Directionality.of(context)),
                                                                                                child: Container(
                                                                                                  height: 400.0,
                                                                                                  width: MediaQuery.sizeOf(context).width * 0.9,
                                                                                                  child: ShopNewReviewPopupWidget(
                                                                                                    venddoc: shopDetailpageVendorDetailsRecord!,
                                                                                                    custDoc: containerCustomerDetailsRecord!,
                                                                                                  ),
                                                                                                ),
                                                                                              );
                                                                                            },
                                                                                          );
                                                                                        },
                                                                                        child: Text(
                                                                                          'Write a review',
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Sen',
                                                                                                color: Color(0xFF7C7C7C),
                                                                                                letterSpacing: 0.0,
                                                                                                decoration: TextDecoration.underline,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      16.0),
                                                          child: Container(
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                0.9,
                                                            decoration:
                                                                BoxDecoration(),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .min,
                                                              children: [
                                                                Flexible(
                                                                  child:
                                                                      Padding(
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            10.0,
                                                                            0.0),
                                                                    child:
                                                                        ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              8.0),
                                                                      child: SvgPicture
                                                                          .asset(
                                                                        'assets/images/Isolation_Mode.svg',
                                                                        width:
                                                                            25.0,
                                                                        height:
                                                                            25.0,
                                                                        fit: BoxFit
                                                                            .contain,
                                                                        alignment: Alignment(
                                                                            0.0,
                                                                            0.0),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Flexible(
                                                                  child: Text(
                                                                    valueOrDefault<
                                                                        String>(
                                                                      shopDetailpageVendorDetailsRecord
                                                                          ?.businessAddress,
                                                                      'Shop Address',
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF7C7C7C),
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      16.0),
                                                          child: Container(
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                1.0,
                                                            decoration:
                                                                BoxDecoration(),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          10.0,
                                                                          0.0),
                                                                  child: Icon(
                                                                    FFIcons
                                                                        .kphoneHandset,
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    size: 24.0,
                                                                  ),
                                                                ),
                                                                InkWell(
                                                                  splashColor:
                                                                      Colors
                                                                          .transparent,
                                                                  focusColor: Colors
                                                                      .transparent,
                                                                  hoverColor: Colors
                                                                      .transparent,
                                                                  highlightColor:
                                                                      Colors
                                                                          .transparent,
                                                                  onTap:
                                                                      () async {
                                                                    await launchUrl(
                                                                        Uri(
                                                                      scheme:
                                                                          'tel',
                                                                      path: shopDetailpageVendorDetailsRecord!
                                                                          .vendorPhone,
                                                                    ));
                                                                  },
                                                                  child: Text(
                                                                    valueOrDefault<
                                                                        String>(
                                                                      shopDetailpageVendorDetailsRecord
                                                                          ?.businessMob,
                                                                      'Shop Phone',
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF7C7C7C),
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          width:
                                                              MediaQuery.sizeOf(
                                                                          context)
                                                                      .width *
                                                                  1.0,
                                                          decoration:
                                                              BoxDecoration(),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            10.0,
                                                                            0.0),
                                                                child: Icon(
                                                                  Icons
                                                                      .mail_outlined,
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  size: 24.0,
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            5.0,
                                                                            0.0,
                                                                            0.0),
                                                                child: InkWell(
                                                                  splashColor:
                                                                      Colors
                                                                          .transparent,
                                                                  focusColor: Colors
                                                                      .transparent,
                                                                  hoverColor: Colors
                                                                      .transparent,
                                                                  highlightColor:
                                                                      Colors
                                                                          .transparent,
                                                                  onTap:
                                                                      () async {
                                                                    await launchUrl(
                                                                        Uri(
                                                                      scheme:
                                                                          'mailto',
                                                                      path: shopDetailpageVendorDetailsRecord!
                                                                          .vendorEmail,
                                                                    ));
                                                                  },
                                                                  child: Text(
                                                                    valueOrDefault<
                                                                        String>(
                                                                      shopDetailpageVendorDetailsRecord
                                                                          ?.businessEmail,
                                                                      ' Shop Email',
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF7C7C7C),
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      16.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                1.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          10.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    'Share this shop via: ',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF464646),
                                                                          fontSize:
                                                                              16.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          10.0,
                                                                          0.0),
                                                                  child:
                                                                      InkWell(
                                                                    splashColor:
                                                                        Colors
                                                                            .transparent,
                                                                    focusColor:
                                                                        Colors
                                                                            .transparent,
                                                                    hoverColor:
                                                                        Colors
                                                                            .transparent,
                                                                    highlightColor:
                                                                        Colors
                                                                            .transparent,
                                                                    onTap:
                                                                        () async {
                                                                      await launchURL(
                                                                          'https://api.whatsapp.com/send?text=https://app.clubcardlocal.com/shopDetailpage?venid=${widget!.venid}');
                                                                    },
                                                                    child:
                                                                        FaIcon(
                                                                      FontAwesomeIcons
                                                                          .whatsapp,
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      size:
                                                                          30.0,
                                                                    ),
                                                                  ),
                                                                ),
                                                                InkWell(
                                                                  splashColor:
                                                                      Colors
                                                                          .transparent,
                                                                  focusColor: Colors
                                                                      .transparent,
                                                                  hoverColor: Colors
                                                                      .transparent,
                                                                  highlightColor:
                                                                      Colors
                                                                          .transparent,
                                                                  onTap:
                                                                      () async {
                                                                    await launchURL(
                                                                        'https://www.facebook.com/sharer/sharer.php?u=https://app.clubcardlocal.com/shopDetailpage?venid=${widget!.venid}');
                                                                  },
                                                                  child: Icon(
                                                                    FFIcons
                                                                        .kfacebookCircled,
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    size: 30.0,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 26.0, 0.0, 26.0),
                                              child: Container(
                                                width:
                                                    MediaQuery.sizeOf(context)
                                                            .width *
                                                        1.0,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              -1.0, 0.0),
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    16.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        child:
                                                            FlutterFlowChoiceChips(
                                                          options:
                                                              shopDetailpageVendorDetailsRecord!
                                                                  .shopTags
                                                                  .map((label) =>
                                                                      ChipData(
                                                                          label))
                                                                  .toList(),
                                                          onChanged: (val) =>
                                                              safeSetState(() =>
                                                                  _model.choiceChipsValue =
                                                                      val?.firstOrNull),
                                                          selectedChipStyle:
                                                              ChipStyle(
                                                            backgroundColor:
                                                                Color(
                                                                    0xFF989898),
                                                            textStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Readex Pro',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .info,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                            iconColor:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .info,
                                                            iconSize: 17.0,
                                                            elevation: 0.0,
                                                            borderColor: Color(
                                                                0xFF989898),
                                                            borderWidth: 1.0,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20.0),
                                                          ),
                                                          unselectedChipStyle:
                                                              ChipStyle(
                                                            backgroundColor:
                                                                Color(
                                                                    0x00000000),
                                                            textStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF989898),
                                                                      fontSize:
                                                                          10.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                            iconColor: Color(
                                                                0x00000000),
                                                            iconSize: 17.0,
                                                            elevation: 0.0,
                                                            borderColor: Color(
                                                                0xFF989898),
                                                            borderWidth: 1.0,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20.0),
                                                          ),
                                                          chipSpacing: 8.0,
                                                          rowSpacing: 8.0,
                                                          multiselect: false,
                                                          alignment:
                                                              WrapAlignment
                                                                  .start,
                                                          controller: _model
                                                                  .choiceChipsValueController ??=
                                                              FormFieldController<
                                                                  List<String>>(
                                                            [],
                                                          ),
                                                          wrapped: true,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 26.0),
                                              child: Container(
                                                width:
                                                    MediaQuery.sizeOf(context)
                                                            .width *
                                                        0.9,
                                                height: 1.0,
                                                decoration: BoxDecoration(
                                                  color: Color(0xFFDCDCDC),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 0.0, 10.0, 20.0),
                                        child: Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  1.0,
                                          decoration: BoxDecoration(),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 15.0, 0.0, 0.0),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: Colors.white,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Stack(
                                                        children: [
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0.0, 0.0),
                                                            child: Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  0.9,
                                                              decoration:
                                                                  BoxDecoration(),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                children: [
                                                                  Align(
                                                                    alignment:
                                                                        AlignmentDirectional(
                                                                            0.0,
                                                                            0.0),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          20.0),
                                                                      child: FutureBuilder<
                                                                          int>(
                                                                        future:
                                                                            queryOffersCollectionRecordCount(
                                                                          queryBuilder: (offersCollectionRecord) => offersCollectionRecord
                                                                              .where(
                                                                                'Vendor_id',
                                                                                isEqualTo: shopDetailpageVendorDetailsRecord?.vendorId != '' ? shopDetailpageVendorDetailsRecord?.vendorId : null,
                                                                              )
                                                                              .where(
                                                                                'offer_status',
                                                                                isEqualTo: 'Live',
                                                                              )
                                                                              .where(
                                                                                'offerType',
                                                                                isEqualTo: 'Products',
                                                                              ),
                                                                        ),
                                                                        builder:
                                                                            (context,
                                                                                snapshot) {
                                                                          // Customize what your widget looks like when it's loading.
                                                                          if (!snapshot
                                                                              .hasData) {
                                                                            return Center(
                                                                              child: SizedBox(
                                                                                width: 60.0,
                                                                                height: 60.0,
                                                                                child: SpinKitRipple(
                                                                                  color: Color(0xFFFF7622),
                                                                                  size: 60.0,
                                                                                ),
                                                                              ),
                                                                            );
                                                                          }
                                                                          int productOffersCount =
                                                                              snapshot.data!;

                                                                          return Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 1.0,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Colors.white,
                                                                            ),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
                                                                                    child: Text(
                                                                                      'Offers',
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Poppins',
                                                                                            color: Color(0xFF464646),
                                                                                            fontSize: 18.0,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.w500,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                    child: Container(
                                                                                      width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                      child: Stack(
                                                                                        alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                        children: [
                                                                                          StreamBuilder<List<OffersCollectionRecord>>(
                                                                                            stream: queryOffersCollectionRecord(
                                                                                              queryBuilder: (offersCollectionRecord) => offersCollectionRecord
                                                                                                  .where(
                                                                                                    'Vendor_id',
                                                                                                    isEqualTo: shopDetailpageVendorDetailsRecord?.vendorId != '' ? shopDetailpageVendorDetailsRecord?.vendorId : null,
                                                                                                  )
                                                                                                  .where(
                                                                                                    'offer_status',
                                                                                                    isEqualTo: 'Live',
                                                                                                  )
                                                                                                  .where(
                                                                                                    'offerType',
                                                                                                    isEqualTo: 'Products',
                                                                                                  )
                                                                                                  .orderBy('Offer_expiry_date'),
                                                                                            ),
                                                                                            builder: (context, snapshot) {
                                                                                              // Customize what your widget looks like when it's loading.
                                                                                              if (!snapshot.hasData) {
                                                                                                return Center(
                                                                                                  child: SizedBox(
                                                                                                    width: 60.0,
                                                                                                    height: 60.0,
                                                                                                    child: SpinKitRipple(
                                                                                                      color: Color(0xFFFF7622),
                                                                                                      size: 60.0,
                                                                                                    ),
                                                                                                  ),
                                                                                                );
                                                                                              }
                                                                                              List<OffersCollectionRecord> rowOffersCollectionRecordList = snapshot.data!;

                                                                                              return SingleChildScrollView(
                                                                                                scrollDirection: Axis.horizontal,
                                                                                                child: Row(
                                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                  children: List.generate(rowOffersCollectionRecordList.length, (rowIndex) {
                                                                                                    final rowOffersCollectionRecord = rowOffersCollectionRecordList[rowIndex];
                                                                                                    return Flexible(
                                                                                                      child: Container(
                                                                                                        width: 170.0,
                                                                                                        child: Stack(
                                                                                                          children: [
                                                                                                            Padding(
                                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 16.0),
                                                                                                              child: InkWell(
                                                                                                                splashColor: Colors.transparent,
                                                                                                                focusColor: Colors.transparent,
                                                                                                                hoverColor: Colors.transparent,
                                                                                                                highlightColor: Colors.transparent,
                                                                                                                onTap: () async {
                                                                                                                  if (valueOrDefault(currentUserDocument?.userType, '') == 'Customer') {
                                                                                                                    context.pushNamed(
                                                                                                                      OfferDetailpageWidget.routeName,
                                                                                                                      queryParameters: {
                                                                                                                        'offerdoc': serializeParam(
                                                                                                                          rowOffersCollectionRecord,
                                                                                                                          ParamType.Document,
                                                                                                                        ),
                                                                                                                        'custref': serializeParam(
                                                                                                                          containerCustomerDetailsRecord?.reference,
                                                                                                                          ParamType.DocumentReference,
                                                                                                                        ),
                                                                                                                      }.withoutNulls,
                                                                                                                      extra: <String, dynamic>{
                                                                                                                        'offerdoc': rowOffersCollectionRecord,
                                                                                                                      },
                                                                                                                    );
                                                                                                                  } else {
                                                                                                                    return;
                                                                                                                  }
                                                                                                                },
                                                                                                                child: Container(
                                                                                                                  width: 170.0,
                                                                                                                  height: 230.0,
                                                                                                                  decoration: BoxDecoration(
                                                                                                                    color: Colors.white,
                                                                                                                    boxShadow: [
                                                                                                                      BoxShadow(
                                                                                                                        blurRadius: 16.0,
                                                                                                                        color: Color(0x19000000),
                                                                                                                        offset: Offset(
                                                                                                                          0.0,
                                                                                                                          0.0,
                                                                                                                        ),
                                                                                                                      )
                                                                                                                    ],
                                                                                                                    borderRadius: BorderRadius.circular(16.0),
                                                                                                                    border: Border.all(
                                                                                                                      color: Colors.white,
                                                                                                                      width: 1.0,
                                                                                                                    ),
                                                                                                                  ),
                                                                                                                  child: Column(
                                                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                                                    children: [
                                                                                                                      Flexible(
                                                                                                                        child: Container(
                                                                                                                          width: 180.0,
                                                                                                                          height: 140.0,
                                                                                                                          decoration: BoxDecoration(
                                                                                                                            color: Color(0xFFFFECD4),
                                                                                                                            image: DecorationImage(
                                                                                                                              fit: BoxFit.contain,
                                                                                                                              alignment: AlignmentDirectional(0.0, 0.0),
                                                                                                                              image: Image.network(
                                                                                                                                valueOrDefault<String>(
                                                                                                                                  rowOffersCollectionRecord.offrImage,
                                                                                                                                  'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                                                                ),
                                                                                                                              ).image,
                                                                                                                            ),
                                                                                                                            borderRadius: BorderRadius.only(
                                                                                                                              bottomLeft: Radius.circular(0.0),
                                                                                                                              bottomRight: Radius.circular(0.0),
                                                                                                                              topLeft: Radius.circular(16.0),
                                                                                                                              topRight: Radius.circular(16.0),
                                                                                                                            ),
                                                                                                                          ),
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                      Padding(
                                                                                                                        padding: EdgeInsetsDirectional.fromSTEB(10.0, 10.0, 10.0, 16.0),
                                                                                                                        child: Container(
                                                                                                                          width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                                                          decoration: BoxDecoration(),
                                                                                                                          child: Row(
                                                                                                                            mainAxisSize: MainAxisSize.min,
                                                                                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                                            children: [
                                                                                                                              Flexible(
                                                                                                                                child: Column(
                                                                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                                                  children: [
                                                                                                                                    Container(
                                                                                                                                      width: MediaQuery.sizeOf(context).width * 0.3,
                                                                                                                                      decoration: BoxDecoration(),
                                                                                                                                      child: Padding(
                                                                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 7.0),
                                                                                                                                        child: Text(
                                                                                                                                          rowOffersCollectionRecord.offerTitle.maybeHandleOverflow(
                                                                                                                                            maxChars: 20,
                                                                                                                                            replacement: '…',
                                                                                                                                          ),
                                                                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                                                                fontFamily: 'Poppins',
                                                                                                                                                color: Color(0xFF464646),
                                                                                                                                                fontSize: 14.0,
                                                                                                                                                letterSpacing: 0.0,
                                                                                                                                                fontWeight: FontWeight.w500,
                                                                                                                                              ),
                                                                                                                                        ),
                                                                                                                                      ),
                                                                                                                                    ),
                                                                                                                                    Align(
                                                                                                                                      alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                                                                      child: Container(
                                                                                                                                        width: MediaQuery.sizeOf(context).width * 0.3,
                                                                                                                                        decoration: BoxDecoration(),
                                                                                                                                        child: Row(
                                                                                                                                          mainAxisSize: MainAxisSize.max,
                                                                                                                                          children: [
                                                                                                                                            Padding(
                                                                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                                                                                                                                              child: Icon(
                                                                                                                                                FFIcons.kclock,
                                                                                                                                                color: Color(0xFFFF7622),
                                                                                                                                                size: 14.0,
                                                                                                                                              ),
                                                                                                                                            ),
                                                                                                                                            Text(
                                                                                                                                              dateTimeFormat("yMMMd", rowOffersCollectionRecord.offerExpiryDate!),
                                                                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                                                                    fontFamily: 'Readex Pro',
                                                                                                                                                    color: Color(0xFF7C7C7C),
                                                                                                                                                    fontSize: 12.0,
                                                                                                                                                    letterSpacing: 0.0,
                                                                                                                                                  ),
                                                                                                                                            ),
                                                                                                                                          ],
                                                                                                                                        ),
                                                                                                                                      ),
                                                                                                                                    ),
                                                                                                                                  ],
                                                                                                                                ),
                                                                                                                              ),
                                                                                                                              Icon(
                                                                                                                                Icons.arrow_forward_ios_outlined,
                                                                                                                                color: Color(0xFFFF7622),
                                                                                                                                size: 24.0,
                                                                                                                              ),
                                                                                                                            ],
                                                                                                                          ),
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                ),
                                                                                                              ),
                                                                                                            ),
                                                                                                            Align(
                                                                                                              alignment: AlignmentDirectional(1.0, -1.0),
                                                                                                              child: badges.Badge(
                                                                                                                badgeContent: Text(
                                                                                                                  '${formatNumber(
                                                                                                                    ((rowOffersCollectionRecord.regularPrice - rowOffersCollectionRecord.offerPrice) / rowOffersCollectionRecord.regularPrice) * 100,
                                                                                                                    formatType: FormatType.custom,
                                                                                                                    format: '##',
                                                                                                                    locale: '',
                                                                                                                  )}%',
                                                                                                                  style: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                                                        fontFamily: 'Sen',
                                                                                                                        color: Colors.white,
                                                                                                                        fontSize: 14.0,
                                                                                                                        letterSpacing: 0.0,
                                                                                                                        fontWeight: FontWeight.normal,
                                                                                                                      ),
                                                                                                                ),
                                                                                                                showBadge: true,
                                                                                                                shape: badges.BadgeShape.circle,
                                                                                                                badgeColor: Color(0xFFFF7622),
                                                                                                                elevation: 5.0,
                                                                                                                padding: EdgeInsets.all(10.0),
                                                                                                                position: badges.BadgePosition.topEnd(),
                                                                                                                animationType: badges.BadgeAnimationType.scale,
                                                                                                                toAnimate: true,
                                                                                                              ),
                                                                                                            ),
                                                                                                          ],
                                                                                                        ),
                                                                                                      ),
                                                                                                    );
                                                                                                  }).divide(SizedBox(width: 10.0)),
                                                                                                ),
                                                                                              );
                                                                                            },
                                                                                          ),
                                                                                          if (productOffersCount == 0)
                                                                                            Align(
                                                                                              alignment: AlignmentDirectional(0.0, 0.0),
                                                                                              child: Padding(
                                                                                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 20.0),
                                                                                                child: Text(
                                                                                                  'Exciting Offers Coming Soon',
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        fontFamily: 'Poppins',
                                                                                                        color: Color(0xFF464646),
                                                                                                        fontSize: 16.0,
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                      ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          );
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  FutureBuilder<
                                                                      int>(
                                                                    future:
                                                                        queryOffersCollectionRecordCount(
                                                                      queryBuilder: (offersCollectionRecord) => offersCollectionRecord
                                                                          .where(
                                                                            'Vendor_id',
                                                                            isEqualTo:
                                                                                shopDetailpageVendorDetailsRecord?.vendorId,
                                                                          )
                                                                          .where(
                                                                            'offer_status',
                                                                            isEqualTo:
                                                                                'Live',
                                                                          )
                                                                          .where(
                                                                            'offerType',
                                                                            isEqualTo:
                                                                                'Services',
                                                                          ),
                                                                    ),
                                                                    builder:
                                                                        (context,
                                                                            snapshot) {
                                                                      // Customize what your widget looks like when it's loading.
                                                                      if (!snapshot
                                                                          .hasData) {
                                                                        return Center(
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                60.0,
                                                                            height:
                                                                                60.0,
                                                                            child:
                                                                                SpinKitRipple(
                                                                              color: Color(0xFFFF7622),
                                                                              size: 60.0,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }
                                                                      int newOfferEventsCount =
                                                                          snapshot
                                                                              .data!;

                                                                      return Container(
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        decoration:
                                                                            BoxDecoration(),
                                                                        child:
                                                                            Column(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          children: [
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
                                                                              child: Text(
                                                                                'Services',
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Poppins',
                                                                                      color: Color(0xFF464646),
                                                                                      fontSize: 18.0,
                                                                                      letterSpacing: 0.0,
                                                                                      fontWeight: FontWeight.w500,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                            Align(
                                                                              alignment: AlignmentDirectional(-1.0, 0.0),
                                                                              child: Stack(
                                                                                alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                children: [
                                                                                  StreamBuilder<List<OffersCollectionRecord>>(
                                                                                    stream: queryOffersCollectionRecord(
                                                                                      queryBuilder: (offersCollectionRecord) => offersCollectionRecord
                                                                                          .where(
                                                                                            'Vendor_id',
                                                                                            isEqualTo: shopDetailpageVendorDetailsRecord?.vendorId,
                                                                                          )
                                                                                          .where(
                                                                                            'offer_status',
                                                                                            isEqualTo: 'Live',
                                                                                          )
                                                                                          .where(
                                                                                            'offerType',
                                                                                            isEqualTo: 'Services',
                                                                                          )
                                                                                          .orderBy('Offer_expiry_date'),
                                                                                    ),
                                                                                    builder: (context, snapshot) {
                                                                                      // Customize what your widget looks like when it's loading.
                                                                                      if (!snapshot.hasData) {
                                                                                        return Center(
                                                                                          child: SizedBox(
                                                                                            width: 60.0,
                                                                                            height: 60.0,
                                                                                            child: SpinKitRipple(
                                                                                              color: Color(0xFFFF7622),
                                                                                              size: 60.0,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      }
                                                                                      List<OffersCollectionRecord> rowOffersCollectionRecordList = snapshot.data!;

                                                                                      return SingleChildScrollView(
                                                                                        scrollDirection: Axis.horizontal,
                                                                                        child: Row(
                                                                                          mainAxisSize: MainAxisSize.max,
                                                                                          children: List.generate(rowOffersCollectionRecordList.length, (rowIndex) {
                                                                                            final rowOffersCollectionRecord = rowOffersCollectionRecordList[rowIndex];
                                                                                            return Padding(
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 16.0),
                                                                                              child: InkWell(
                                                                                                splashColor: Colors.transparent,
                                                                                                focusColor: Colors.transparent,
                                                                                                hoverColor: Colors.transparent,
                                                                                                highlightColor: Colors.transparent,
                                                                                                onTap: () async {
                                                                                                  context.pushNamed(
                                                                                                    CustBookingWidget.routeName,
                                                                                                    queryParameters: {
                                                                                                      'vendref': serializeParam(
                                                                                                        rowOffersCollectionRecord.vendRef,
                                                                                                        ParamType.DocumentReference,
                                                                                                      ),
                                                                                                      'offerrefSer': serializeParam(
                                                                                                        rowOffersCollectionRecord,
                                                                                                        ParamType.Document,
                                                                                                      ),
                                                                                                    }.withoutNulls,
                                                                                                    extra: <String, dynamic>{
                                                                                                      'offerrefSer': rowOffersCollectionRecord,
                                                                                                    },
                                                                                                  );
                                                                                                },
                                                                                                child: Container(
                                                                                                  width: 170.0,
                                                                                                  height: 230.0,
                                                                                                  decoration: BoxDecoration(
                                                                                                    color: Colors.white,
                                                                                                    boxShadow: [
                                                                                                      BoxShadow(
                                                                                                        blurRadius: 16.0,
                                                                                                        color: Color(0x19000000),
                                                                                                        offset: Offset(
                                                                                                          0.0,
                                                                                                          0.0,
                                                                                                        ),
                                                                                                      )
                                                                                                    ],
                                                                                                    borderRadius: BorderRadius.circular(16.0),
                                                                                                    border: Border.all(
                                                                                                      color: Colors.white,
                                                                                                      width: 1.0,
                                                                                                    ),
                                                                                                  ),
                                                                                                  child: Column(
                                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                                    children: [
                                                                                                      Flexible(
                                                                                                        child: Container(
                                                                                                          width: 180.0,
                                                                                                          height: 140.0,
                                                                                                          decoration: BoxDecoration(
                                                                                                            color: Color(0xFFFFECD4),
                                                                                                            image: DecorationImage(
                                                                                                              fit: BoxFit.contain,
                                                                                                              alignment: AlignmentDirectional(0.0, 0.0),
                                                                                                              image: Image.network(
                                                                                                                valueOrDefault<String>(
                                                                                                                  rowOffersCollectionRecord.offrImage,
                                                                                                                  'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                                                ),
                                                                                                              ).image,
                                                                                                            ),
                                                                                                            borderRadius: BorderRadius.only(
                                                                                                              bottomLeft: Radius.circular(0.0),
                                                                                                              bottomRight: Radius.circular(0.0),
                                                                                                              topLeft: Radius.circular(16.0),
                                                                                                              topRight: Radius.circular(16.0),
                                                                                                            ),
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                      Padding(
                                                                                                        padding: EdgeInsetsDirectional.fromSTEB(10.0, 10.0, 10.0, 16.0),
                                                                                                        child: Container(
                                                                                                          width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                                          decoration: BoxDecoration(),
                                                                                                          child: Row(
                                                                                                            mainAxisSize: MainAxisSize.min,
                                                                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                            children: [
                                                                                                              Flexible(
                                                                                                                child: Column(
                                                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                                  children: [
                                                                                                                    Container(
                                                                                                                      width: MediaQuery.sizeOf(context).width * 0.3,
                                                                                                                      decoration: BoxDecoration(),
                                                                                                                      child: Padding(
                                                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 8.0),
                                                                                                                        child: Text(
                                                                                                                          rowOffersCollectionRecord.offerTitle.maybeHandleOverflow(
                                                                                                                            maxChars: 20,
                                                                                                                            replacement: '…',
                                                                                                                          ),
                                                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                                                fontFamily: 'Poppins',
                                                                                                                                color: Color(0xFF464646),
                                                                                                                                fontSize: 14.0,
                                                                                                                                letterSpacing: 0.0,
                                                                                                                                fontWeight: FontWeight.w500,
                                                                                                                              ),
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ),
                                                                                                                    Align(
                                                                                                                      alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                                                      child: Container(
                                                                                                                        decoration: BoxDecoration(),
                                                                                                                        child: Row(
                                                                                                                          mainAxisSize: MainAxisSize.min,
                                                                                                                          children: [
                                                                                                                            Padding(
                                                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                                                                                                                              child: Icon(
                                                                                                                                FFIcons.kclock,
                                                                                                                                color: Color(0xFFFF7622),
                                                                                                                                size: 14.0,
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                            Text(
                                                                                                                              dateTimeFormat("yMMMd", rowOffersCollectionRecord.offerExpiryDate!),
                                                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                                                    fontFamily: 'Readex Pro',
                                                                                                                                    color: Color(0xFF7C7C7C),
                                                                                                                                    fontSize: 12.0,
                                                                                                                                    letterSpacing: 0.0,
                                                                                                                                  ),
                                                                                                                            ),
                                                                                                                          ],
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ),
                                                                                                                  ],
                                                                                                                ),
                                                                                                              ),
                                                                                                              Icon(
                                                                                                                Icons.arrow_forward_ios_outlined,
                                                                                                                color: Color(0xFFFF7622),
                                                                                                                size: 24.0,
                                                                                                              ),
                                                                                                            ],
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ],
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            );
                                                                                          }).divide(SizedBox(width: 10.0)),
                                                                                        ),
                                                                                      );
                                                                                    },
                                                                                  ),
                                                                                  if (newOfferEventsCount.toString() == '0')
                                                                                    Align(
                                                                                      alignment: AlignmentDirectional(0.0, 0.0),
                                                                                      child: Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 20.0),
                                                                                        child: Text(
                                                                                          'Exciting Offers Coming Soon',
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                color: Color(0xFF464646),
                                                                                                fontSize: 16.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w500,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      );
                                                                    },
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          if (!(currentUserDocument
                                                                              ?.follwedshoplist
                                                                              ?.toList() ??
                                                                          [])
                                                                      .contains(
                                                                          shopDetailpageVendorDetailsRecord
                                                                              ?.reference) &&
                                                                  (valueOrDefault(
                                                                          currentUserDocument
                                                                              ?.userType,
                                                                          '') ==
                                                                      'Customer')
                                                              ? true
                                                              : false)
                                                            Align(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      0.0, 0.0),
                                                              child: Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            20.0),
                                                                child:
                                                                    AuthUserStreamWidget(
                                                                  builder:
                                                                      (context) =>
                                                                          Container(
                                                                    width: MediaQuery.sizeOf(context)
                                                                            .width *
                                                                        1.0,
                                                                    height: MediaQuery.sizeOf(context)
                                                                            .height *
                                                                        0.95,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Color(
                                                                          0xBB989898),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10.0),
                                                                    ),
                                                                    child:
                                                                        Align(
                                                                      alignment:
                                                                          AlignmentDirectional(
                                                                              0.0,
                                                                              0.0),
                                                                      child:
                                                                          Text(
                                                                        'Click access to see offers',
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Color(0xFF333333),
                                                                              fontSize: 20.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.w600,
                                                                            ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                        ],
                                                      ),
                                                      if (valueOrDefault(
                                                              currentUserDocument
                                                                  ?.userType,
                                                              '') ==
                                                          'Customer')
                                                        Align(
                                                          alignment:
                                                              AlignmentDirectional(
                                                                  0.0, 0.0),
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        30.0),
                                                            child:
                                                                AuthUserStreamWidget(
                                                              builder:
                                                                  (context) =>
                                                                      Container(
                                                                width: 500.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    if ((currentUserDocument?.follwedshoplist?.toList() ??
                                                                                [])
                                                                            .contains(shopDetailpageVendorDetailsRecord?.reference) ==
                                                                        false)
                                                                      FFButtonWidget(
                                                                        onPressed:
                                                                            () async {
                                                                          await Future
                                                                              .wait([
                                                                            Future(() async {
                                                                              await FollowedshopRecord.createDoc(containerCustomerDetailsRecord!.reference).set(createFollowedshopRecordData(
                                                                                followedDate: getCurrentTimestamp,
                                                                                user: containerCustomerDetailsRecord?.reference,
                                                                                followedshop: shopDetailpageVendorDetailsRecord?.reference,
                                                                                userId: containerCustomerDetailsRecord?.custUserid,
                                                                                follwedShopId: widget!.venid,
                                                                              ));

                                                                              await FollowedUserRecord.createDoc(shopDetailpageVendorDetailsRecord!.reference).set(createFollowedUserRecordData(
                                                                                custFollwed: containerCustomerDetailsRecord?.reference,
                                                                                vendRef: shopDetailpageVendorDetailsRecord?.reference,
                                                                                follwedDate: getCurrentTimestamp,
                                                                              ));
                                                                            }),
                                                                            Future(() async {
                                                                              await currentUserReference!.update({
                                                                                ...mapToFirestore(
                                                                                  {
                                                                                    'follwedshoplist': FieldValue.arrayUnion([
                                                                                      shopDetailpageVendorDetailsRecord?.reference
                                                                                    ]),
                                                                                  },
                                                                                ),
                                                                              });
                                                                            }),
                                                                          ]);

                                                                          safeSetState(
                                                                              () {});
                                                                        },
                                                                        text:
                                                                            'Access',
                                                                        options:
                                                                            FFButtonOptions(
                                                                          width:
                                                                              MediaQuery.sizeOf(context).width * 0.901,
                                                                          height:
                                                                              50.0,
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              24.0,
                                                                              0.0,
                                                                              24.0,
                                                                              0.0),
                                                                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              0.0),
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.white,
                                                                                fontSize: 18.0,
                                                                                letterSpacing: 0.0,
                                                                              ),
                                                                          elevation:
                                                                              3.0,
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.transparent,
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(8.0),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              if (valueOrDefault(
                                                      currentUserDocument
                                                          ?.userType,
                                                      '') ==
                                                  'Customer')
                                                Expanded(
                                                  child: AuthUserStreamWidget(
                                                    builder: (context) =>
                                                        Container(
                                                      width: MediaQuery.sizeOf(
                                                                  context)
                                                              .width *
                                                          0.9,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        10.0),
                                                            child: Text(
                                                              'Customer Reviews',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Poppins',
                                                                    color: Color(
                                                                        0xFF3D3D3D),
                                                                    fontSize:
                                                                        18.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: Stack(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      0.0, 0.0),
                                                              children: [
                                                                Container(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      0.9,
                                                                  height: 350.0,
                                                                  decoration:
                                                                      BoxDecoration(),
                                                                  child: StreamBuilder<
                                                                      List<
                                                                          ReviewsRecord>>(
                                                                    stream:
                                                                        queryReviewsRecord(
                                                                      parent: shopDetailpageVendorDetailsRecord
                                                                          ?.reference,
                                                                    ),
                                                                    builder:
                                                                        (context,
                                                                            snapshot) {
                                                                      // Customize what your widget looks like when it's loading.
                                                                      if (!snapshot
                                                                          .hasData) {
                                                                        return Center(
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                60.0,
                                                                            height:
                                                                                60.0,
                                                                            child:
                                                                                SpinKitRipple(
                                                                              color: Color(0xFFFF7622),
                                                                              size: 60.0,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }
                                                                      List<ReviewsRecord>
                                                                          listViewReviewsRecordList =
                                                                          snapshot
                                                                              .data!;

                                                                      return ListView
                                                                          .separated(
                                                                        padding:
                                                                            EdgeInsets.zero,
                                                                        scrollDirection:
                                                                            Axis.vertical,
                                                                        itemCount:
                                                                            listViewReviewsRecordList.length,
                                                                        separatorBuilder:
                                                                            (_, __) =>
                                                                                SizedBox(height: 10.0),
                                                                        itemBuilder:
                                                                            (context,
                                                                                listViewIndex) {
                                                                          final listViewReviewsRecord =
                                                                              listViewReviewsRecordList[listViewIndex];
                                                                          return Align(
                                                                            alignment:
                                                                                AlignmentDirectional(-1.0, 0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                children: [
                                                                                  Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    children: [
                                                                                      Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 13.0),
                                                                                        child: Row(
                                                                                          mainAxisSize: MainAxisSize.max,
                                                                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                          children: [
                                                                                            Container(
                                                                                              decoration: BoxDecoration(),
                                                                                              child: Row(
                                                                                                mainAxisSize: MainAxisSize.max,
                                                                                                children: [
                                                                                                  Padding(
                                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 16.0, 0.0),
                                                                                                    child: ClipRRect(
                                                                                                      borderRadius: BorderRadius.circular(20.0),
                                                                                                      child: Image.network(
                                                                                                        valueOrDefault<String>(
                                                                                                          listViewReviewsRecord.custProfile,
                                                                                                          'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                                        ),
                                                                                                        width: 26.0,
                                                                                                        height: 26.0,
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                  Text(
                                                                                                    listViewReviewsRecord.customerName,
                                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                          fontFamily: 'Poppins',
                                                                                                          color: Color(0xFF464646),
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w500,
                                                                                                        ),
                                                                                                  ),
                                                                                                ],
                                                                                              ),
                                                                                            ),
                                                                                            if (listViewReviewsRecord.custId == containerCustomerDetailsRecord?.custUserid)
                                                                                              Builder(
                                                                                                builder: (context) => InkWell(
                                                                                                  splashColor: Colors.transparent,
                                                                                                  focusColor: Colors.transparent,
                                                                                                  hoverColor: Colors.transparent,
                                                                                                  highlightColor: Colors.transparent,
                                                                                                  onTap: () async {
                                                                                                    await showDialog(
                                                                                                      barrierColor: Color(0xC4F2F2F2),
                                                                                                      context: context,
                                                                                                      builder: (dialogContext) {
                                                                                                        return Dialog(
                                                                                                          elevation: 0,
                                                                                                          insetPadding: EdgeInsets.zero,
                                                                                                          backgroundColor: Colors.transparent,
                                                                                                          alignment: AlignmentDirectional(0.0, 0.0).resolve(Directionality.of(context)),
                                                                                                          child: Container(
                                                                                                            height: 400.0,
                                                                                                            width: MediaQuery.sizeOf(context).width * 0.9,
                                                                                                            child: ShopEditReviewPopupWidget(
                                                                                                              vendref: shopDetailpageVendorDetailsRecord!.reference,
                                                                                                              custdoc: containerCustomerDetailsRecord!,
                                                                                                              venddoc: shopDetailpageVendorDetailsRecord!,
                                                                                                            ),
                                                                                                          ),
                                                                                                        );
                                                                                                      },
                                                                                                    );

                                                                                                    safeSetState(() {});
                                                                                                  },
                                                                                                  child: Icon(
                                                                                                    Icons.edit_outlined,
                                                                                                    color: Color(0xFF989898),
                                                                                                    size: 24.0,
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                      Align(
                                                                                        alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                        child: Container(
                                                                                          width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                          decoration: BoxDecoration(),
                                                                                          alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                          child: Column(
                                                                                            mainAxisSize: MainAxisSize.max,
                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                            children: [
                                                                                              RatingBarIndicator(
                                                                                                itemBuilder: (context, index) => Icon(
                                                                                                  Icons.star_rounded,
                                                                                                  color: Color(0xFFFF7622),
                                                                                                ),
                                                                                                direction: Axis.horizontal,
                                                                                                rating: listViewReviewsRecord.reviewRating.toDouble(),
                                                                                                unratedColor: Color(0xFFDCDCDC),
                                                                                                itemCount: 5,
                                                                                                itemSize: 16.0,
                                                                                              ),
                                                                                              Padding(
                                                                                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 7.0),
                                                                                                child: Text(
                                                                                                  valueOrDefault<String>(
                                                                                                    listViewReviewsRecord.reviewtitle,
                                                                                                    'Review title',
                                                                                                  ),
                                                                                                  textAlign: TextAlign.start,
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        fontFamily: 'Sen',
                                                                                                        color: Color(0xFF8C8C8C),
                                                                                                        fontSize: 16.0,
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                      ),
                                                                                                ),
                                                                                              ),
                                                                                              Text(
                                                                                                listViewReviewsRecord.reviewComments,
                                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                      fontFamily: 'Sen',
                                                                                                      color: Color(0xFF7C7C7C),
                                                                                                      letterSpacing: 0.0,
                                                                                                    ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 23.0, 0.0, 23.0),
                                                                                    child: Container(
                                                                                      width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                      height: 1.0,
                                                                                      decoration: BoxDecoration(
                                                                                        color: Color(0xFFDCDCDC),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          );
                                                                        },
                                                                      );
                                                                    },
                                                                  ),
                                                                ),
                                                                Align(
                                                                  alignment:
                                                                      AlignmentDirectional(
                                                                          0.0,
                                                                          0.0),
                                                                  child:
                                                                      FutureBuilder<
                                                                          int>(
                                                                    future:
                                                                        queryReviewsRecordCount(
                                                                      queryBuilder:
                                                                          (reviewsRecord) =>
                                                                              reviewsRecord.where(
                                                                        'VendorId',
                                                                        isEqualTo:
                                                                            shopDetailpageVendorDetailsRecord?.vendorId,
                                                                      ),
                                                                    ),
                                                                    builder:
                                                                        (context,
                                                                            snapshot) {
                                                                      // Customize what your widget looks like when it's loading.
                                                                      if (!snapshot
                                                                          .hasData) {
                                                                        return Center(
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                60.0,
                                                                            height:
                                                                                60.0,
                                                                            child:
                                                                                SpinKitRipple(
                                                                              color: Color(0xFFFF7622),
                                                                              size: 60.0,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }
                                                                      int containerCount =
                                                                          snapshot
                                                                              .data!;

                                                                      return Container(
                                                                        decoration:
                                                                            BoxDecoration(),
                                                                        child:
                                                                            Visibility(
                                                                          visible:
                                                                              containerCount.toString() == '0',
                                                                          child:
                                                                              Text(
                                                                            'No Reviews',
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  fontFamily: 'Poppins',
                                                                                  color: Colors.black,
                                                                                  fontSize: 18.0,
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ));
        },
      ),
    );
  }
}
