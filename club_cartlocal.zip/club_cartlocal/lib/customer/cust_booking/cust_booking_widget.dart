import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'cust_booking_model.dart';
export 'cust_booking_model.dart';

class CustBookingWidget extends StatefulWidget {
  const CustBookingWidget({
    super.key,
    required this.vendref,
    required this.offerrefSer,
  });

  final DocumentReference? vendref;
  final OffersCollectionRecord? offerrefSer;

  static String routeName = 'Cust_booking';
  static String routePath = '/custBooking';

  @override
  State<CustBookingWidget> createState() => _CustBookingWidgetState();
}

class _CustBookingWidgetState extends State<CustBookingWidget> {
  late CustBookingModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CustBookingModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Title(
        title: 'Cust_booking',
        color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: Colors.white,
            floatingActionButton: Align(
              alignment: AlignmentDirectional(-0.87, -0.9),
              child: FloatingActionButton(
                onPressed: () async {
                  context.pop();
                },
                backgroundColor: Colors.white,
                elevation: 8.0,
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                  size: 27.0,
                ),
              ),
            ),
            body: SafeArea(
              top: true,
              child: Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 20.0, 0.0, 12.0),
                        child: Container(
                          width: () {
                            if (MediaQuery.sizeOf(context).width <
                                kBreakpointSmall) {
                              return MediaQuery.sizeOf(context).width;
                            } else if (MediaQuery.sizeOf(context).width <
                                kBreakpointMedium) {
                              return (MediaQuery.sizeOf(context).width * 0.5);
                            } else if (MediaQuery.sizeOf(context).width <
                                kBreakpointLarge) {
                              return 500.0;
                            } else {
                              return 500.0;
                            }
                          }(),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(0.0),
                          ),
                          child: SingleChildScrollView(
                            primary: false,
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  width: MediaQuery.sizeOf(context).width * 1.0,
                                  height: 380.0,
                                  decoration: BoxDecoration(
                                    color: Color(0x83F2F2F2),
                                    image: DecorationImage(
                                      fit: BoxFit.contain,
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      image: Image.network(
                                        valueOrDefault<String>(
                                          widget!.offerrefSer?.offrImage,
                                          'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                        ),
                                      ).image,
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.9,
                                    decoration: BoxDecoration(),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 26.0, 0.0, 0.0),
                                          child: Container(
                                            width: MediaQuery.sizeOf(context)
                                                    .width *
                                                1.0,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(0.0),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Flexible(
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        0.7,
                                                    decoration: BoxDecoration(),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          valueOrDefault<
                                                              String>(
                                                            widget!.offerrefSer
                                                                ?.offerTitle,
                                                            'Offer Name',
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .headlineMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Poppins',
                                                                color: Color(
                                                                    0xFF464646),
                                                                fontSize: 20.0,
                                                                letterSpacing:
                                                                    0.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      6.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: RichText(
                                                            textScaler:
                                                                MediaQuery.of(
                                                                        context)
                                                                    .textScaler,
                                                            text: TextSpan(
                                                              children: [
                                                                TextSpan(
                                                                  text: 'From ',
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFF7C7C7C),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                ),
                                                                TextSpan(
                                                                  text: valueOrDefault<
                                                                      String>(
                                                                    widget!
                                                                        .offerrefSer
                                                                        ?.vendorName,
                                                                    'Business Name',
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFF7C7C7C),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                )
                                                              ],
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Sen',
                                                                    color: Color(
                                                                        0xFF7C7C7C),
                                                                    letterSpacing:
                                                                        0.0,
                                                                  ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Flexible(
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        0.3,
                                                    decoration: BoxDecoration(),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        Icon(
                                                          Icons
                                                              .currency_pound_sharp,
                                                          color:
                                                              Color(0xFF333333),
                                                          size: 25.0,
                                                        ),
                                                        Text(
                                                          valueOrDefault<
                                                              String>(
                                                            formatNumber(
                                                              widget!
                                                                  .offerrefSer
                                                                  ?.offerPrice,
                                                              formatType:
                                                                  FormatType
                                                                      .decimal,
                                                              decimalType:
                                                                  DecimalType
                                                                      .automatic,
                                                            ),
                                                            ' 321534',
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Poppins',
                                                                color: Color(
                                                                    0xFFFF7622),
                                                                fontSize: 26.0,
                                                                letterSpacing:
                                                                    0.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                              ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  1.0,
                                          decoration: BoxDecoration(),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 26.0, 0.0, 26.0),
                                                child: FlutterFlowChoiceChips(
                                                  options: widget!
                                                      .offerrefSer!.tags
                                                      .map((label) =>
                                                          ChipData(label))
                                                      .toList(),
                                                  onChanged: (val) =>
                                                      safeSetState(() => _model
                                                              .choiceChipsValue1 =
                                                          val?.firstOrNull),
                                                  selectedChipStyle: ChipStyle(
                                                    backgroundColor:
                                                        Color(0x00000000),
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Sen',
                                                          color:
                                                              Color(0xFF989898),
                                                          fontSize: 10.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                    iconColor:
                                                        Color(0x00000000),
                                                    iconSize: 16.0,
                                                    elevation: 0.0,
                                                    borderColor:
                                                        Color(0xFF989898),
                                                    borderWidth: 1.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30.0),
                                                  ),
                                                  unselectedChipStyle:
                                                      ChipStyle(
                                                    backgroundColor:
                                                        Color(0x00000000),
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Sen',
                                                          color:
                                                              Color(0xFF989898),
                                                          fontSize: 10.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                    iconColor:
                                                        Color(0x00000000),
                                                    iconSize: 16.0,
                                                    elevation: 0.0,
                                                    borderColor:
                                                        Color(0xFF989898),
                                                    borderWidth: 1.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30.0),
                                                  ),
                                                  chipSpacing: 8.0,
                                                  rowSpacing: 8.0,
                                                  multiselect: false,
                                                  alignment:
                                                      WrapAlignment.start,
                                                  controller: _model
                                                          .choiceChipsValueController1 ??=
                                                      FormFieldController<
                                                          List<String>>(
                                                    [],
                                                  ),
                                                  wrapped: true,
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 0.0, 26.0),
                                                child: Text(
                                                  valueOrDefault<String>(
                                                    widget!.offerrefSer
                                                        ?.offferShortDescription,
                                                    ' Description',
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelMedium
                                                      .override(
                                                        fontFamily: 'Sen',
                                                        color:
                                                            Color(0xFF7C7C7C),
                                                        fontSize: 14.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  1.0,
                                          height: 1.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFE1E1E1),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                StreamBuilder<List<ServiceSlotsRecord>>(
                                  stream: queryServiceSlotsRecord(
                                    queryBuilder: (serviceSlotsRecord) =>
                                        serviceSlotsRecord
                                            .where(
                                              'ServiceDate',
                                              isEqualTo: widget!
                                                  .offerrefSer?.offerExpiryDate,
                                            )
                                            .where(
                                              'offerref',
                                              isEqualTo: widget!
                                                  .offerrefSer?.reference,
                                            )
                                            .where(
                                              'vend_ref',
                                              isEqualTo: widget!.vendref,
                                            )
                                            .where(
                                              'isslotbooked',
                                              isEqualTo: false,
                                            )
                                            .where(
                                              'timeSlots',
                                              isEqualTo:
                                                  _model.choiceChipsValue2,
                                            ),
                                    singleRecord: true,
                                  ),
                                  builder: (context, snapshot) {
                                    // Customize what your widget looks like when it's loading.
                                    if (!snapshot.hasData) {
                                      return Center(
                                        child: SizedBox(
                                          width: 60.0,
                                          height: 60.0,
                                          child: SpinKitRipple(
                                            color: Color(0xFFFF7622),
                                            size: 60.0,
                                          ),
                                        ),
                                      );
                                    }
                                    List<ServiceSlotsRecord>
                                        containerServiceSlotsRecordList =
                                        snapshot.data!;
                                    final containerServiceSlotsRecord =
                                        containerServiceSlotsRecordList
                                                .isNotEmpty
                                            ? containerServiceSlotsRecordList
                                                .first
                                            : null;

                                    return Container(
                                      decoration: BoxDecoration(),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Container(
                                            width: MediaQuery.sizeOf(context)
                                                    .width *
                                                0.9,
                                            decoration: BoxDecoration(),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 0.0, 20.0),
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    decoration: BoxDecoration(
                                                      color: Colors.white,
                                                    ),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      10.0,
                                                                      0.0,
                                                                      20.0),
                                                          child: RichText(
                                                            textScaler:
                                                                MediaQuery.of(
                                                                        context)
                                                                    .textScaler,
                                                            text: TextSpan(
                                                              children: [
                                                                TextSpan(
                                                                  text:
                                                                      'Booking Date: ',
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Color(
                                                                            0xFF9C9C9C),
                                                                        fontSize:
                                                                            24.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                ),
                                                                TextSpan(
                                                                  text: dateTimeFormat(
                                                                      "yMMMd",
                                                                      widget!
                                                                          .offerrefSer!
                                                                          .offerExpiryDate!),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Color(
                                                                            0xFFFF7622),
                                                                        fontSize:
                                                                            24.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                )
                                                              ],
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Readex Pro',
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    fontSize:
                                                                        24.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                  ),
                                                            ),
                                                          ),
                                                        ),
                                                        StreamBuilder<
                                                            List<
                                                                ServiceSlotsRecord>>(
                                                          stream:
                                                              queryServiceSlotsRecord(
                                                            queryBuilder:
                                                                (serviceSlotsRecord) =>
                                                                    serviceSlotsRecord
                                                                        .where(
                                                                          'ServiceDate',
                                                                          isEqualTo: widget!
                                                                              .offerrefSer
                                                                              ?.offerExpiryDate,
                                                                        )
                                                                        .where(
                                                                          'offerref',
                                                                          isEqualTo: widget!
                                                                              .offerrefSer
                                                                              ?.reference,
                                                                        )
                                                                        .where(
                                                                          'vend_ref',
                                                                          isEqualTo:
                                                                              widget!.vendref,
                                                                        )
                                                                        .where(
                                                                          'isslotbooked',
                                                                          isEqualTo:
                                                                              false,
                                                                        ),
                                                          ),
                                                          builder: (context,
                                                              snapshot) {
                                                            // Customize what your widget looks like when it's loading.
                                                            if (!snapshot
                                                                .hasData) {
                                                              return Center(
                                                                child: SizedBox(
                                                                  width: 60.0,
                                                                  height: 60.0,
                                                                  child:
                                                                      SpinKitRipple(
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    size: 60.0,
                                                                  ),
                                                                ),
                                                              );
                                                            }
                                                            List<ServiceSlotsRecord>
                                                                containerServiceSlotsRecordList =
                                                                snapshot.data!;

                                                            return Container(
                                                              decoration:
                                                                  BoxDecoration(),
                                                              child:
                                                                  FlutterFlowChoiceChips(
                                                                options: containerServiceSlotsRecordList
                                                                    .map((e) => e
                                                                        .timeSlots)
                                                                    .toList()
                                                                    .sortedList(
                                                                        keyOf:
                                                                            (e) =>
                                                                                e,
                                                                        desc:
                                                                            false)
                                                                    .map((label) =>
                                                                        ChipData(
                                                                            label))
                                                                    .toList(),
                                                                onChanged: (val) =>
                                                                    safeSetState(() =>
                                                                        _model.choiceChipsValue2 =
                                                                            val?.firstOrNull),
                                                                selectedChipStyle:
                                                                    ChipStyle(
                                                                  backgroundColor:
                                                                      Color(
                                                                          0xFFFF7622),
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            12.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                  iconColor: Color(
                                                                      0x00000000),
                                                                  iconSize:
                                                                      18.0,
                                                                  elevation:
                                                                      0.0,
                                                                  borderColor:
                                                                      Color(
                                                                          0xFF989898),
                                                                  borderWidth:
                                                                      1.0,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10.0),
                                                                ),
                                                                unselectedChipStyle:
                                                                    ChipStyle(
                                                                  backgroundColor:
                                                                      Color(
                                                                          0x00000000),
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Color(
                                                                            0xFF989898),
                                                                        fontSize:
                                                                            12.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                  iconColor: Color(
                                                                      0x00000000),
                                                                  iconSize:
                                                                      16.0,
                                                                  elevation:
                                                                      0.0,
                                                                  borderColor:
                                                                      Color(
                                                                          0xFFAEA3A3),
                                                                  borderWidth:
                                                                      1.0,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              8.0),
                                                                ),
                                                                chipSpacing:
                                                                    8.0,
                                                                rowSpacing: 8.0,
                                                                multiselect:
                                                                    false,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                controller: _model
                                                                        .choiceChipsValueController2 ??=
                                                                    FormFieldController<
                                                                        List<
                                                                            String>>(
                                                                  [],
                                                                ),
                                                                wrapped: true,
                                                              ),
                                                            );
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                AlignmentDirectional(0.0, 0.0),
                                            child: Container(
                                              width: MediaQuery.sizeOf(context)
                                                      .width *
                                                  0.9,
                                              decoration: BoxDecoration(),
                                              child: FFButtonWidget(
                                                onPressed:
                                                    (_model.choiceChipsValue2 ==
                                                                null ||
                                                            _model.choiceChipsValue2 ==
                                                                '')
                                                        ? null
                                                        : () async {
                                                            var bookingsRecordReference =
                                                                BookingsRecord
                                                                    .collection
                                                                    .doc();
                                                            await bookingsRecordReference
                                                                .set(
                                                                    createBookingsRecordData(
                                                              appointmentOwnerref:
                                                                  widget!
                                                                      .offerrefSer
                                                                      ?.vendRef,
                                                              bookingdate:
                                                                  getCurrentTimestamp,
                                                              bookingID:
                                                                  'B-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
                                                                random_data
                                                                    .randomInteger(
                                                                        0,
                                                                        1000),
                                                                formatType:
                                                                    FormatType
                                                                        .custom,
                                                                format: '-',
                                                                locale: '',
                                                              )}',
                                                              opointmentName: widget!
                                                                  .offerrefSer
                                                                  ?.offerTitle,
                                                              opointeeuser:
                                                                  currentUserReference,
                                                              apointeeID:
                                                                  currentUserUid,
                                                              bookingStatus:
                                                                  'Schedule',
                                                              appointeeName:
                                                                  currentUserDisplayName,
                                                              evntImage: widget!
                                                                  .offerrefSer
                                                                  ?.offrImage,
                                                              appointrefOffer:
                                                                  widget!
                                                                      .offerrefSer
                                                                      ?.reference,
                                                              bookTimeSlot: _model
                                                                  .choiceChipsValue2,
                                                              bookingSlotDateStr:
                                                                  dateTimeFormat(
                                                                      "d/M/y",
                                                                      containerServiceSlotsRecord
                                                                          ?.serviceDate),
                                                              appointmentShopName:
                                                                  widget!
                                                                      .offerrefSer
                                                                      ?.vendorName,
                                                            ));
                                                            _model.bookingoutput =
                                                                BookingsRecord
                                                                    .getDocumentFromData(
                                                                        createBookingsRecordData(
                                                                          appointmentOwnerref: widget!
                                                                              .offerrefSer
                                                                              ?.vendRef,
                                                                          bookingdate:
                                                                              getCurrentTimestamp,
                                                                          bookingID:
                                                                              'B-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
                                                                            random_data.randomInteger(0,
                                                                                1000),
                                                                            formatType:
                                                                                FormatType.custom,
                                                                            format:
                                                                                '-',
                                                                            locale:
                                                                                '',
                                                                          )}',
                                                                          opointmentName: widget!
                                                                              .offerrefSer
                                                                              ?.offerTitle,
                                                                          opointeeuser:
                                                                              currentUserReference,
                                                                          apointeeID:
                                                                              currentUserUid,
                                                                          bookingStatus:
                                                                              'Schedule',
                                                                          appointeeName:
                                                                              currentUserDisplayName,
                                                                          evntImage: widget!
                                                                              .offerrefSer
                                                                              ?.offrImage,
                                                                          appointrefOffer: widget!
                                                                              .offerrefSer
                                                                              ?.reference,
                                                                          bookTimeSlot:
                                                                              _model.choiceChipsValue2,
                                                                          bookingSlotDateStr: dateTimeFormat(
                                                                              "d/M/y",
                                                                              containerServiceSlotsRecord?.serviceDate),
                                                                          appointmentShopName: widget!
                                                                              .offerrefSer
                                                                              ?.vendorName,
                                                                        ),
                                                                        bookingsRecordReference);

                                                            await containerServiceSlotsRecord!
                                                                .reference
                                                                .update(
                                                                    createServiceSlotsRecordData(
                                                              isslotbooked:
                                                                  true,
                                                              bookedBy:
                                                                  currentUserReference,
                                                            ));
                                                            await SendEmailApiGroup
                                                                .sendEmailInGroupCall
                                                                .call(
                                                              toemail:
                                                                  currentUserEmail,
                                                              subject:
                                                                  'Your appointment has been successfully booked',
                                                              body:
                                                                  'We are pleased to confirm that your appointment has been successfully booked.Details of your appointment:Date: ${dateTimeFormat("yMMMd", widget!.offerrefSer?.offerExpiryDate)}Time:${containerServiceSlotsRecord?.timeSlots}Opted Service ${widget!.offerrefSer?.offerTitle}If you have any questions or need to reschedule, please don\'t hesitate to contact us at contact@clubcardlocal.com.',
                                                            );

                                                            context.pushNamed(
                                                                CustThankyouBookingWidget
                                                                    .routeName);

                                                            safeSetState(() {});
                                                          },
                                                text: 'Book Slot',
                                                options: FFButtonOptions(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          0.9,
                                                  height: 50.0,
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          16.0, 0.0, 16.0, 0.0),
                                                  iconPadding:
                                                      EdgeInsetsDirectional
                                                          .fromSTEB(0.0, 0.0,
                                                              0.0, 0.0),
                                                  color: Color(0xFFFF7622),
                                                  textStyle: FlutterFlowTheme
                                                          .of(context)
                                                      .titleSmall
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: Colors.white,
                                                        fontSize: 18.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                                  elevation: 0.0,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  disabledColor:
                                                      Color(0xFF878787),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 20.0, 0.0, 26.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.9,
                                    decoration: BoxDecoration(),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  10.0, 0.0, 0.0, 10.0),
                                          child: Text(
                                            'Other Services',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Poppins',
                                                  color: Color(0xFF333333),
                                                  fontSize: 18.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                          ),
                                        ),
                                        Expanded(
                                          child: StreamBuilder<
                                              List<OffersCollectionRecord>>(
                                            stream: queryOffersCollectionRecord(
                                              queryBuilder:
                                                  (offersCollectionRecord) =>
                                                      offersCollectionRecord
                                                          .where(
                                                            'Vendor_id',
                                                            isEqualTo: widget!
                                                                .offerrefSer
                                                                ?.vendorId,
                                                          )
                                                          .where(
                                                            'offerType',
                                                            isEqualTo:
                                                                'Services',
                                                          )
                                                          .where(
                                                            'offer_status',
                                                            isEqualTo: 'Live',
                                                          )
                                                          .where(
                                                            'Offer_number',
                                                            isNotEqualTo: widget!
                                                                .offerrefSer
                                                                ?.offerNumber,
                                                          ),
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return Center(
                                                  child: SizedBox(
                                                    width: 60.0,
                                                    height: 60.0,
                                                    child: SpinKitRipple(
                                                      color: Color(0xFFFF7622),
                                                      size: 60.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<OffersCollectionRecord>
                                                  gridViewOffersCollectionRecordList =
                                                  snapshot.data!;

                                              return GridView.builder(
                                                padding: EdgeInsets.zero,
                                                gridDelegate:
                                                    SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: 2,
                                                  crossAxisSpacing: 10.0,
                                                  mainAxisSpacing: 10.0,
                                                  childAspectRatio: 0.7,
                                                ),
                                                shrinkWrap: true,
                                                scrollDirection: Axis.vertical,
                                                itemCount:
                                                    gridViewOffersCollectionRecordList
                                                        .length,
                                                itemBuilder:
                                                    (context, gridViewIndex) {
                                                  final gridViewOffersCollectionRecord =
                                                      gridViewOffersCollectionRecordList[
                                                          gridViewIndex];
                                                  return InkWell(
                                                    splashColor:
                                                        Colors.transparent,
                                                    focusColor:
                                                        Colors.transparent,
                                                    hoverColor:
                                                        Colors.transparent,
                                                    highlightColor:
                                                        Colors.transparent,
                                                    onTap: () async {
                                                      context.pushNamed(
                                                        CustBookingWidget
                                                            .routeName,
                                                        queryParameters: {
                                                          'vendref':
                                                              serializeParam(
                                                            widget!.vendref,
                                                            ParamType
                                                                .DocumentReference,
                                                          ),
                                                          'offerrefSer':
                                                              serializeParam(
                                                            gridViewOffersCollectionRecord,
                                                            ParamType.Document,
                                                          ),
                                                        }.withoutNulls,
                                                        extra: <String,
                                                            dynamic>{
                                                          'offerrefSer':
                                                              gridViewOffersCollectionRecord,
                                                        },
                                                      );
                                                    },
                                                    child: Container(
                                                      width: 180.0,
                                                      decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        boxShadow: [
                                                          BoxShadow(
                                                            blurRadius: 16.0,
                                                            color: Color(
                                                                0x1A000000),
                                                            offset: Offset(
                                                              0.0,
                                                              0.0,
                                                            ),
                                                          )
                                                        ],
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(16.0),
                                                      ),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10.0),
                                                            child:
                                                                Image.network(
                                                              gridViewOffersCollectionRecord
                                                                  .offrImage,
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  1.0,
                                                              height: 140.0,
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        10.0,
                                                                        10.0,
                                                                        10.0,
                                                                        0.0),
                                                            child: Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  9.0,
                                                              decoration:
                                                                  BoxDecoration(),
                                                              child: Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  Flexible(
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              26.0),
                                                                          child:
                                                                              Text(
                                                                            gridViewOffersCollectionRecord.offerTitle,
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  fontFamily: 'Poppins',
                                                                                  color: Color(0xFF333333),
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                        Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.min,
                                                                          children: [
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 6.0, 0.0),
                                                                              child: Icon(
                                                                                FFIcons.kclock,
                                                                                color: Color(0xFFFF7622),
                                                                                size: 24.0,
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              dateTimeFormat("d/M/y", gridViewOffersCollectionRecord.offerPublisheDate!),
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Sen',
                                                                                    color: Color(0xFF7C7C7C),
                                                                                    fontSize: 12.0,
                                                                                    letterSpacing: 0.0,
                                                                                    fontWeight: FontWeight.w600,
                                                                                  ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Icon(
                                                                    Icons
                                                                        .arrow_forward_ios_rounded,
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    size: 16.0,
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                                },
                                              );
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ].divide(SizedBox(height: 5.0)),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
