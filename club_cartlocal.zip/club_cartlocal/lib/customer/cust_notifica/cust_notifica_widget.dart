import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'cust_notifica_model.dart';
export 'cust_notifica_model.dart';

class CustNotificaWidget extends StatefulWidget {
  const CustNotificaWidget({super.key});

  static String routeName = 'cust_notifica';
  static String routePath = '/cust_notifica';

  @override
  State<CustNotificaWidget> createState() => _CustNotificaWidgetState();
}

class _CustNotificaWidgetState extends State<CustNotificaWidget> {
  late CustNotificaModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CustNotificaModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<CustomerDetailsRecord>>(
      stream: queryCustomerDetailsRecord(
        queryBuilder: (customerDetailsRecord) => customerDetailsRecord.where(
          'cust_email',
          isEqualTo: currentUserEmail,
        ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Colors.white,
            body: Center(
              child: SizedBox(
                width: 60.0,
                height: 60.0,
                child: SpinKitRipple(
                  color: Color(0xFFFF7622),
                  size: 60.0,
                ),
              ),
            ),
          );
        }
        List<CustomerDetailsRecord> custNotificaCustomerDetailsRecordList =
            snapshot.data!;
        final custNotificaCustomerDetailsRecord =
            custNotificaCustomerDetailsRecordList.isNotEmpty
                ? custNotificaCustomerDetailsRecordList.first
                : null;

        return Title(
            title: 'cust_notifica',
            color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
            child: GestureDetector(
              onTap: () {
                FocusScope.of(context).unfocus();
                FocusManager.instance.primaryFocus?.unfocus();
              },
              child: Scaffold(
                key: scaffoldKey,
                backgroundColor: Colors.white,
                appBar: AppBar(
                  backgroundColor: Colors.white,
                  automaticallyImplyLeading: false,
                  leading: FlutterFlowIconButton(
                    borderColor: Colors.transparent,
                    borderRadius: 30.0,
                    borderWidth: 1.0,
                    buttonSize: 60.0,
                    icon: Icon(
                      Icons.arrow_back_rounded,
                      color: Color(0xFF333333),
                      size: 30.0,
                    ),
                    onPressed: () async {
                      context.pop();
                    },
                  ),
                  title: Text(
                    'Notifications',
                    style: FlutterFlowTheme.of(context).headlineMedium.override(
                          fontFamily: 'Poppins',
                          color: Color(0xFF333333),
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                  actions: [],
                  centerTitle: false,
                  elevation: 0.0,
                ),
                body: SafeArea(
                  top: true,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        height: 1.0,
                        decoration: BoxDecoration(
                          color: Color(0xFFE1E1E1),
                        ),
                      ),
                      Expanded(
                        child: StreamBuilder<List<ReleaseNotificationRecord>>(
                          stream: queryReleaseNotificationRecord(),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 60.0,
                                  height: 60.0,
                                  child: SpinKitRipple(
                                    color: Color(0xFFFF7622),
                                    size: 60.0,
                                  ),
                                ),
                              );
                            }
                            List<ReleaseNotificationRecord>
                                containerReleaseNotificationRecordList =
                                snapshot.data!;

                            return Container(
                              width: MediaQuery.sizeOf(context).width * 1.0,
                              decoration: BoxDecoration(),
                              child: Stack(
                                children: [
                                  AuthUserStreamWidget(
                                    builder: (context) => Builder(
                                      builder: (context) {
                                        final containerVar =
                                            containerReleaseNotificationRecordList
                                                .map((e) => e)
                                                .toList()
                                                .where((e) =>
                                                    (currentUserDocument
                                                                ?.follwedshoplist
                                                                ?.toList() ??
                                                            [])
                                                        .contains(e.createdBy))
                                                .toList();

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          scrollDirection: Axis.vertical,
                                          itemCount: containerVar.length,
                                          itemBuilder:
                                              (context, containerVarIndex) {
                                            final containerVarItem =
                                                containerVar[containerVarIndex];
                                            return Visibility(
                                              visible: !containerVarItem
                                                  .offerReadBy
                                                  .contains(
                                                      currentUserReference),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 26.0, 0.0, 0.0),
                                                child: StreamBuilder<
                                                    OffersCollectionRecord>(
                                                  stream: OffersCollectionRecord
                                                      .getDocument(
                                                          containerVarItem
                                                              .offerRef!),
                                                  builder: (context, snapshot) {
                                                    // Customize what your widget looks like when it's loading.
                                                    if (!snapshot.hasData) {
                                                      return Center(
                                                        child: SizedBox(
                                                          width: 60.0,
                                                          height: 60.0,
                                                          child: SpinKitRipple(
                                                            color: Color(
                                                                0xFFFF7622),
                                                            size: 60.0,
                                                          ),
                                                        ),
                                                      );
                                                    }

                                                    final containerOffersCollectionRecord =
                                                        snapshot.data!;

                                                    return Container(
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          InkWell(
                                                            splashColor: Colors
                                                                .transparent,
                                                            focusColor: Colors
                                                                .transparent,
                                                            hoverColor: Colors
                                                                .transparent,
                                                            highlightColor:
                                                                Colors
                                                                    .transparent,
                                                            onTap: () async {
                                                              if (containerOffersCollectionRecord
                                                                      .offerType ==
                                                                  'Products') {
                                                                context
                                                                    .pushNamed(
                                                                  OfferDetailpageWidget
                                                                      .routeName,
                                                                  queryParameters:
                                                                      {
                                                                    'offerdoc':
                                                                        serializeParam(
                                                                      containerOffersCollectionRecord,
                                                                      ParamType
                                                                          .Document,
                                                                    ),
                                                                    'custref':
                                                                        serializeParam(
                                                                      custNotificaCustomerDetailsRecord
                                                                          ?.reference,
                                                                      ParamType
                                                                          .DocumentReference,
                                                                    ),
                                                                  }.withoutNulls,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    'offerdoc':
                                                                        containerOffersCollectionRecord,
                                                                  },
                                                                );

                                                                await containerVarItem
                                                                    .reference
                                                                    .update({
                                                                  ...mapToFirestore(
                                                                    {
                                                                      'offer_read_by':
                                                                          FieldValue
                                                                              .arrayUnion([
                                                                        currentUserReference
                                                                      ]),
                                                                    },
                                                                  ),
                                                                });
                                                              } else {
                                                                context
                                                                    .pushNamed(
                                                                  CustBookingWidget
                                                                      .routeName,
                                                                  queryParameters:
                                                                      {
                                                                    'vendref':
                                                                        serializeParam(
                                                                      containerOffersCollectionRecord
                                                                          .vendRef,
                                                                      ParamType
                                                                          .DocumentReference,
                                                                    ),
                                                                    'offerrefSer':
                                                                        serializeParam(
                                                                      containerOffersCollectionRecord,
                                                                      ParamType
                                                                          .Document,
                                                                    ),
                                                                  }.withoutNulls,
                                                                  extra: <String,
                                                                      dynamic>{
                                                                    'offerrefSer':
                                                                        containerOffersCollectionRecord,
                                                                  },
                                                                );

                                                                await containerVarItem
                                                                    .reference
                                                                    .update({
                                                                  ...mapToFirestore(
                                                                    {
                                                                      'offer_read_by':
                                                                          FieldValue
                                                                              .arrayUnion([
                                                                        currentUserReference
                                                                      ]),
                                                                    },
                                                                  ),
                                                                });
                                                              }
                                                            },
                                                            child: Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  1.0,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .white,
                                                              ),
                                                              child: Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        20.0,
                                                                        20.0,
                                                                        20.0,
                                                                        20.0),
                                                                child: Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          15.0,
                                                                          0.0),
                                                                      child:
                                                                          Container(
                                                                        width:
                                                                            80.0,
                                                                        height:
                                                                            80.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Color(0x83F2F2F2),
                                                                          image:
                                                                              DecorationImage(
                                                                            fit:
                                                                                BoxFit.contain,
                                                                            alignment:
                                                                                AlignmentDirectional(0.0, 0.0),
                                                                            image:
                                                                                Image.network(
                                                                              containerVarItem.offerImage,
                                                                            ).image,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(10.0),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width: MediaQuery.sizeOf(context)
                                                                              .width *
                                                                          0.7,
                                                                      decoration:
                                                                          BoxDecoration(),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                0.0,
                                                                                0.0,
                                                                                5.0),
                                                                            child:
                                                                                Text(
                                                                              'New Offer Added',
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: Color(0xFF464646),
                                                                                    fontSize: 22.0,
                                                                                    letterSpacing: 0.0,
                                                                                    fontWeight: FontWeight.w500,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                0.0,
                                                                                0.0,
                                                                                5.0),
                                                                            child:
                                                                                Text(
                                                                              containerVarItem.offerName,
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: Color(0xFF464646),
                                                                                    letterSpacing: 0.0,
                                                                                    fontWeight: FontWeight.w500,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                          RichText(
                                                                            textScaler:
                                                                                MediaQuery.of(context).textScaler,
                                                                            text:
                                                                                TextSpan(
                                                                              children: [
                                                                                TextSpan(
                                                                                  text: 'From ',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Readex Pro',
                                                                                        color: Color(0xFF7C7C7C),
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: containerVarItem.vendName,
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Sen',
                                                                                    color: Color(0xFF464646),
                                                                                    fontSize: 14.0,
                                                                                  ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: ' on ',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Poppins',
                                                                                    color: Color(0xFFFF7622),
                                                                                    fontWeight: FontWeight.w500,
                                                                                    fontSize: 12.0,
                                                                                  ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: valueOrDefault<String>(
                                                                                    dateTimeFormat("d/M/y", containerVarItem.offerStartDate),
                                                                                    'D/M/Y',
                                                                                  ),
                                                                                  style: TextStyle(
                                                                                    color: Color(0xFF464646),
                                                                                    fontSize: 14.0,
                                                                                  ),
                                                                                )
                                                                              ],
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Readex Pro',
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    if (!containerVarItem
                                                                        .offerReadBy
                                                                        .contains(
                                                                            currentUserReference))
                                                                      Container(
                                                                        width:
                                                                            10.0,
                                                                        height:
                                                                            10.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).tertiary,
                                                                          borderRadius:
                                                                              BorderRadius.circular(20.0),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            width: MediaQuery
                                                                        .sizeOf(
                                                                            context)
                                                                    .width *
                                                                1.0,
                                                            height: 1.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: Color(
                                                                  0xFFE1E1E1),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  ),
                                  if (() {
                                    if (containerReleaseNotificationRecordList
                                        .isNotEmpty) {
                                      return false;
                                    } else if (containerReleaseNotificationRecordList
                                        .where((e) => !e.offerReadBy
                                            .contains(currentUserReference))
                                        .toList()
                                        .isNotEmpty) {
                                      return false;
                                    } else {
                                      return true;
                                    }
                                  }())
                                    Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Container(
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        height: 50.0,
                                        decoration: BoxDecoration(),
                                        child: Align(
                                          alignment:
                                              AlignmentDirectional(0.0, 0.0),
                                          child: Text(
                                            'There no new notifiactions',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Poppins',
                                                  color: Colors.black,
                                                  fontSize: 18.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ));
      },
    );
  }
}
