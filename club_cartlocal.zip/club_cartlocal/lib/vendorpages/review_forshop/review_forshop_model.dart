import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/vend_drawer_widget.dart';
import '/components/vendreportpopup_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'review_forshop_widget.dart' show ReviewForshopWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ReviewForshopModel extends FlutterFlowModel<ReviewForshopWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel1.dispose();
    vendDrawerModel2.dispose();
  }
}
