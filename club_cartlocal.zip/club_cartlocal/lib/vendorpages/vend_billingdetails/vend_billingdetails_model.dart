import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'vend_billingdetails_widget.dart' show VendBillingdetailsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendBillingdetailsModel
    extends FlutterFlowModel<VendBillingdetailsWidget> {
  ///  Local state fields for this page.

  String? subrurlparam;

  ///  State fields for stateful widgets in this page.

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  // Stores action output result for [Backend Call - API (UpdateSubscription)] action in Button widget.
  ApiCallResponse? freeUpgrd;
  // Stores action output result for [Backend Call - API (UpdateSubscription)] action in Button widget.
  ApiCallResponse? strterUpgrd;
  // Stores action output result for [Backend Call - API (UpdateSubscription)] action in Button widget.
  ApiCallResponse? grwthUpgrd;
  // Stores action output result for [Backend Call - API (UpdateSubscription)] action in Button widget.
  ApiCallResponse? premiumUpgrd;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel1.dispose();
    vendDrawerModel2.dispose();
  }
}
