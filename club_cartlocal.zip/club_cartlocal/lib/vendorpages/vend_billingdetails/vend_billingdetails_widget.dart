import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'vend_billingdetails_model.dart';
export 'vend_billingdetails_model.dart';

class VendBillingdetailsWidget extends StatefulWidget {
  const VendBillingdetailsWidget({
    super.key,
    required this.vendref,
  });

  final DocumentReference? vendref;

  static String routeName = 'VendBillingdetails';
  static String routePath = '/VendBillingdetails';

  @override
  State<VendBillingdetailsWidget> createState() =>
      _VendBillingdetailsWidgetState();
}

class _VendBillingdetailsWidgetState extends State<VendBillingdetailsWidget> {
  late VendBillingdetailsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VendBillingdetailsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<VendorDetailsRecord>>(
      stream: queryVendorDetailsRecord(
        queryBuilder: (vendorDetailsRecord) => vendorDetailsRecord.where(
          'vendor_email',
          isEqualTo: currentUserEmail,
        ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Color(0xFFF5F7FB),
            body: Center(
              child: SizedBox(
                width: 60.0,
                height: 60.0,
                child: SpinKitRipple(
                  color: Color(0xFFFF7622),
                  size: 60.0,
                ),
              ),
            ),
          );
        }
        List<VendorDetailsRecord> vendBillingdetailsVendorDetailsRecordList =
            snapshot.data!;
        final vendBillingdetailsVendorDetailsRecord =
            vendBillingdetailsVendorDetailsRecordList.isNotEmpty
                ? vendBillingdetailsVendorDetailsRecordList.first
                : null;

        return Title(
            title: 'VendBillingdetails',
            color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
            child: GestureDetector(
              onTap: () {
                FocusScope.of(context).unfocus();
                FocusManager.instance.primaryFocus?.unfocus();
              },
              child: Scaffold(
                key: scaffoldKey,
                backgroundColor: Color(0xFFF5F7FB),
                drawer: Container(
                  width: MediaQuery.sizeOf(context).width * 0.9,
                  child: Drawer(
                    elevation: 16.0,
                    child: wrapWithModel(
                      model: _model.vendDrawerModel2,
                      updateCallback: () => safeSetState(() {}),
                      child: VendDrawerWidget(
                        parameter1: vendBillingdetailsVendorDetailsRecord
                            ?.businessProfileLogo,
                        parameter2: vendBillingdetailsVendorDetailsRecord
                            ?.vendorUsername,
                        parameter3:
                            vendBillingdetailsVendorDetailsRecord?.vendorId,
                        parameter4:
                            vendBillingdetailsVendorDetailsRecord?.reference,
                      ),
                    ),
                  ),
                ),
                body: SafeArea(
                  top: true,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (responsiveVisibility(
                        context: context,
                        phone: false,
                        tablet: false,
                        tabletLandscape: false,
                      ))
                        Container(
                          width: MediaQuery.sizeOf(context).width * 0.2,
                          decoration: BoxDecoration(),
                          child: wrapWithModel(
                            model: _model.vendDrawerModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: VendDrawerWidget(
                              parameter1: vendBillingdetailsVendorDetailsRecord
                                  ?.businessProfileLogo,
                              parameter2: vendBillingdetailsVendorDetailsRecord
                                  ?.vendorUsername,
                              parameter3: vendBillingdetailsVendorDetailsRecord
                                  ?.vendorId,
                              parameter4: vendBillingdetailsVendorDetailsRecord
                                  ?.reference,
                            ),
                          ),
                        ),
                      Expanded(
                        flex: 1,
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 16.0, 16.0, 16.0),
                          child: Container(
                            width: MediaQuery.sizeOf(context).width * 0.775,
                            height: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 4.0,
                                  color: Color(0x33000000),
                                  offset: Offset(
                                    0.0,
                                    2.0,
                                  ),
                                )
                              ],
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                            child: SingleChildScrollView(
                              primary: false,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 20.0),
                                      child: Container(
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.0,
                                        height: 80.0,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          boxShadow: [
                                            BoxShadow(
                                              blurRadius: 4.0,
                                              color: Color(0x33000000),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                            )
                                          ],
                                          borderRadius: BorderRadius.only(
                                            bottomLeft: Radius.circular(0.0),
                                            bottomRight: Radius.circular(0.0),
                                            topLeft: Radius.circular(10.0),
                                            topRight: Radius.circular(10.0),
                                          ),
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Align(
                                                  alignment:
                                                      AlignmentDirectional(
                                                          -1.0, 0.0),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(20.0, 0.0,
                                                                0.0, 0.0),
                                                    child: Text(
                                                      'Billing Details',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily:
                                                                'Poppins',
                                                            color: Color(
                                                                0xFF656565),
                                                            fontSize: 26.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                    ),
                                                  ),
                                                ),
                                                if (responsiveVisibility(
                                                  context: context,
                                                  desktop: false,
                                                ))
                                                  Align(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            1.0, 0.0),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  20.0,
                                                                  0.0),
                                                      child: InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          scaffoldKey
                                                              .currentState!
                                                              .openDrawer();
                                                        },
                                                        child: Icon(
                                                          Icons.menu_rounded,
                                                          color:
                                                              Color(0xFFFF7622),
                                                          size: 30.0,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: StreamBuilder<
                                        List<SubscriptionsRecord>>(
                                      stream: querySubscriptionsRecord(
                                        queryBuilder: (subscriptionsRecord) =>
                                            subscriptionsRecord.where(
                                          'subscrib_user',
                                          isEqualTo: currentUserEmail,
                                        ),
                                        singleRecord: true,
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 60.0,
                                              height: 60.0,
                                              child: SpinKitRipple(
                                                color: Color(0xFFFF7622),
                                                size: 60.0,
                                              ),
                                            ),
                                          );
                                        }
                                        List<SubscriptionsRecord>
                                            containerSubscriptionsRecordList =
                                            snapshot.data!;
                                        final containerSubscriptionsRecord =
                                            containerSubscriptionsRecordList
                                                    .isNotEmpty
                                                ? containerSubscriptionsRecordList
                                                    .first
                                                : null;

                                        return Container(
                                          decoration: BoxDecoration(),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 0.0, 30.0),
                                                child: FutureBuilder<
                                                    ApiCallResponse>(
                                                  future: StripeGroup
                                                      .retriveSubscriptionCall
                                                      .call(
                                                    customer:
                                                        containerSubscriptionsRecord
                                                            ?.subsCustId,
                                                  ),
                                                  builder: (context, snapshot) {
                                                    // Customize what your widget looks like when it's loading.
                                                    if (!snapshot.hasData) {
                                                      return Center(
                                                        child: SizedBox(
                                                          width: 40.0,
                                                          height: 40.0,
                                                          child:
                                                              CircularProgressIndicator(
                                                            valueColor:
                                                                AlwaysStoppedAnimation<
                                                                    Color>(
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .primary,
                                                            ),
                                                          ),
                                                        ),
                                                      );
                                                    }
                                                    final containerRetriveSubscriptionResponse =
                                                        snapshot.data!;

                                                    return Container(
                                                      width: MediaQuery.sizeOf(
                                                                  context)
                                                              .width *
                                                          0.9,
                                                      decoration: BoxDecoration(
                                                        color: Colors.white,
                                                      ),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        20.0,
                                                                        26.0,
                                                                        16.0,
                                                                        26.0),
                                                                child: Wrap(
                                                                  spacing: 30.0,
                                                                  runSpacing:
                                                                      20.0,
                                                                  alignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      WrapCrossAlignment
                                                                          .start,
                                                                  direction: Axis
                                                                      .horizontal,
                                                                  runAlignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  verticalDirection:
                                                                      VerticalDirection
                                                                          .down,
                                                                  clipBehavior:
                                                                      Clip.none,
                                                                  children: [
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          40.0,
                                                                          0.0),
                                                                      child:
                                                                          Container(
                                                                        decoration:
                                                                            BoxDecoration(),
                                                                        child:
                                                                            Column(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          children: [
                                                                            RichText(
                                                                              textScaler: MediaQuery.of(context).textScaler,
                                                                              text: TextSpan(
                                                                                children: [
                                                                                  TextSpan(
                                                                                    text: 'Stripe Customer Id: ',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF9C9C9C),
                                                                                          fontSize: 16.0,
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                  TextSpan(
                                                                                    text: StripeGroup.retriveSubscriptionCall.custid(
                                                                                      containerRetriveSubscriptionResponse.jsonBody,
                                                                                    )!,
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFF3D3D3D),
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          decoration: TextDecoration.underline,
                                                                                        ),
                                                                                  )
                                                                                ],
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Readex Pro',
                                                                                      fontSize: 16.0,
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                            RichText(
                                                                              textScaler: MediaQuery.of(context).textScaler,
                                                                              text: TextSpan(
                                                                                children: [
                                                                                  TextSpan(
                                                                                    text: 'Package Name: ',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF9C9C9C),
                                                                                          fontSize: 16.0,
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                  TextSpan(
                                                                                    text: valueOrDefault<String>(
                                                                                      containerSubscriptionsRecord?.subsPackName,
                                                                                      ' Package Name',
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFF3D3D3D),
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          decoration: TextDecoration.underline,
                                                                                        ),
                                                                                  )
                                                                                ],
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Readex Pro',
                                                                                      fontSize: 18.0,
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                            RichText(
                                                                              textScaler: MediaQuery.of(context).textScaler,
                                                                              text: TextSpan(
                                                                                children: [
                                                                                  TextSpan(
                                                                                    text: 'Amount: ',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF9C9C9C),
                                                                                          fontSize: 16.0,
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                  TextSpan(
                                                                                    text: valueOrDefault<String>(
                                                                                      StripeGroup.retriveSubscriptionCall.planamount(
                                                                                        containerRetriveSubscriptionResponse.jsonBody,
                                                                                      ),
                                                                                      ' Plan Amount',
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFF3D3D3D),
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          decoration: TextDecoration.underline,
                                                                                        ),
                                                                                  )
                                                                                ],
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Readex Pro',
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                            RichText(
                                                                              textScaler: MediaQuery.of(context).textScaler,
                                                                              text: TextSpan(
                                                                                children: [
                                                                                  TextSpan(
                                                                                    text: 'Subscription Status: ',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Color(0xFF9C9C9C),
                                                                                          fontSize: 16.0,
                                                                                          letterSpacing: 0.0,
                                                                                        ),
                                                                                  ),
                                                                                  TextSpan(
                                                                                    text: valueOrDefault<String>(
                                                                                      StripeGroup.retriveSubscriptionCall.subsstatus(
                                                                                        containerRetriveSubscriptionResponse.jsonBody,
                                                                                      ),
                                                                                      ' Subscription Status',
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFF3D3D3D),
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          decoration: TextDecoration.underline,
                                                                                        ),
                                                                                  )
                                                                                ],
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Readex Pro',
                                                                                      fontSize: 18.0,
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      decoration:
                                                                          BoxDecoration(),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          RichText(
                                                                            textScaler:
                                                                                MediaQuery.of(context).textScaler,
                                                                            text:
                                                                                TextSpan(
                                                                              children: [
                                                                                TextSpan(
                                                                                  text: 'Subscription Id: ',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF9C9C9C),
                                                                                        fontSize: 16.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: valueOrDefault<String>(
                                                                                    StripeGroup.retriveSubscriptionCall.subsid(
                                                                                      containerRetriveSubscriptionResponse.jsonBody,
                                                                                    ),
                                                                                    ' Subscription ID',
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Readex Pro',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        fontSize: 14.0,
                                                                                        letterSpacing: 0.0,
                                                                                        decoration: TextDecoration.underline,
                                                                                      ),
                                                                                )
                                                                              ],
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Readex Pro',
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                          RichText(
                                                                            textScaler:
                                                                                MediaQuery.of(context).textScaler,
                                                                            text:
                                                                                TextSpan(
                                                                              children: [
                                                                                TextSpan(
                                                                                  text: 'Payment Method: ',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF9C9C9C),
                                                                                        fontSize: 16.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: valueOrDefault<String>(
                                                                                    StripeGroup.retriveSubscriptionCall.defaultpaymentmethod(
                                                                                      containerRetriveSubscriptionResponse.jsonBody,
                                                                                    ),
                                                                                    ' Payment Method',
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Readex Pro',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        fontSize: 14.0,
                                                                                        letterSpacing: 0.0,
                                                                                        decoration: TextDecoration.underline,
                                                                                      ),
                                                                                )
                                                                              ],
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Readex Pro',
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                          RichText(
                                                                            textScaler:
                                                                                MediaQuery.of(context).textScaler,
                                                                            text:
                                                                                TextSpan(
                                                                              children: [
                                                                                TextSpan(
                                                                                  text: 'Item Id: ',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF9C9C9C),
                                                                                        fontSize: 16.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: valueOrDefault<String>(
                                                                                    StripeGroup.retriveSubscriptionCall.itemid(
                                                                                      containerRetriveSubscriptionResponse.jsonBody,
                                                                                    ),
                                                                                    ' ItEm ID',
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Readex Pro',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        fontSize: 14.0,
                                                                                        letterSpacing: 0.0,
                                                                                        decoration: TextDecoration.underline,
                                                                                      ),
                                                                                )
                                                                              ],
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Readex Pro',
                                                                                    fontSize: 18.0,
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                          RichText(
                                                                            textScaler:
                                                                                MediaQuery.of(context).textScaler,
                                                                            text:
                                                                                TextSpan(
                                                                              children: [
                                                                                TextSpan(
                                                                                  text: 'Price Id: ',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Color(0xFF9C9C9C),
                                                                                        fontSize: 16.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                TextSpan(
                                                                                  text: valueOrDefault<String>(
                                                                                    StripeGroup.retriveSubscriptionCall.priceid(
                                                                                      containerRetriveSubscriptionResponse.jsonBody,
                                                                                    ),
                                                                                    ' Price Id',
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Readex Pro',
                                                                                        color: Color(0xFF3D3D3D),
                                                                                        fontSize: 14.0,
                                                                                        letterSpacing: 0.0,
                                                                                        decoration: TextDecoration.underline,
                                                                                      ),
                                                                                )
                                                                              ],
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Readex Pro',
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0.0, 0.0),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          50.0,
                                                                          0.0,
                                                                          0.0),
                                                              child: Container(
                                                                width: MediaQuery.sizeOf(
                                                                            context)
                                                                        .width *
                                                                    1.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                                child: Wrap(
                                                                  spacing: 20.0,
                                                                  runSpacing:
                                                                      20.0,
                                                                  alignment:
                                                                      WrapAlignment
                                                                          .center,
                                                                  crossAxisAlignment:
                                                                      WrapCrossAlignment
                                                                          .start,
                                                                  direction: Axis
                                                                      .horizontal,
                                                                  runAlignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  verticalDirection:
                                                                      VerticalDirection
                                                                          .down,
                                                                  clipBehavior:
                                                                      Clip.none,
                                                                  children: [
                                                                    Container(
                                                                      width:
                                                                          250.0,
                                                                      height:
                                                                          420.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        boxShadow: [
                                                                          BoxShadow(
                                                                            blurRadius:
                                                                                16.0,
                                                                            color:
                                                                                Color(0x10000000),
                                                                            offset:
                                                                                Offset(
                                                                              4.0,
                                                                              4.0,
                                                                            ),
                                                                          )
                                                                        ],
                                                                        borderRadius:
                                                                            BorderRadius.circular(14.0),
                                                                        border:
                                                                            Border.all(
                                                                          color:
                                                                              Color(0xFFDBDBDB),
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 1.0,
                                                                            height:
                                                                                60.0,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Color(0xFFFF7622),
                                                                              borderRadius: BorderRadius.only(
                                                                                bottomLeft: Radius.circular(0.0),
                                                                                bottomRight: Radius.circular(0.0),
                                                                                topLeft: Radius.circular(12.0),
                                                                                topRight: Radius.circular(12.0),
                                                                              ),
                                                                            ),
                                                                            alignment:
                                                                                AlignmentDirectional(0.0, 0.0),
                                                                            child:
                                                                                Text(
                                                                              'Free Trial',
                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: Colors.white,
                                                                                    fontSize: 24.0,
                                                                                    letterSpacing: 0.0,
                                                                                    fontWeight: FontWeight.normal,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                15.0,
                                                                                0.0,
                                                                                15.0),
                                                                            child:
                                                                                Container(
                                                                              decoration: BoxDecoration(
                                                                                color: Colors.white,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: AlignmentDirectional(0.0, -1.0),
                                                                                    child: Icon(
                                                                                      Icons.currency_pound_sharp,
                                                                                      color: Color(0xFFFF7622),
                                                                                      size: 30.0,
                                                                                    ),
                                                                                  ),
                                                                                  RichText(
                                                                                    textScaler: MediaQuery.of(context).textScaler,
                                                                                    text: TextSpan(
                                                                                      children: [
                                                                                        TextSpan(
                                                                                          text: '0',
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                color: Color(0xFFFF7622),
                                                                                                fontSize: 44.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                        TextSpan(
                                                                                          text: 'per month',
                                                                                          style: TextStyle(
                                                                                            fontSize: 16.0,
                                                                                          ),
                                                                                        )
                                                                                      ],
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Poppins',
                                                                                            color: Color(0xFFFF7622),
                                                                                            fontSize: 44.0,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.w600,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                                                                                    child: Text(
                                                                                      'Features: ',
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Sen',
                                                                                            color: Color(0xFF7C7C7C),
                                                                                            fontSize: 18.0,
                                                                                            letterSpacing: 0.0,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                  Text(
                                                                                    'Free Package: Promote your first product at no cost.\n\n A great way to experience our platform without any commitment.\n\n',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Sen',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          fontSize: 12.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.normal,
                                                                                        ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                14.0,
                                                                                0.0,
                                                                                14.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 1.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFDBDBDB),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                children: [
                                                                                  Text(
                                                                                    '1 product for unlimited days',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFFFF7622),
                                                                                          fontSize: 15.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.w500,
                                                                                        ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 14.0, 0.0, 14.0),
                                                                                    child: FFButtonWidget(
                                                                                      onPressed: () async {
                                                                                        var _shouldSetState = false;
                                                                                        var confirmDialogResponse = await showDialog<bool>(
                                                                                              context: context,
                                                                                              builder: (alertDialogContext) {
                                                                                                return AlertDialog(
                                                                                                  title: Text('Do you want to upgrade?'),
                                                                                                  actions: [
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                                      child: Text('No'),
                                                                                                    ),
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                                      child: Text('Yes'),
                                                                                                    ),
                                                                                                  ],
                                                                                                );
                                                                                              },
                                                                                            ) ??
                                                                                            false;
                                                                                        if (confirmDialogResponse) {
                                                                                          await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                            subsAmount: 0.00,
                                                                                            paymentMethod: StripeGroup.retriveSubscriptionCall.defaultpaymentmethod(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsId: StripeGroup.retriveSubscriptionCall.subsid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsItemId: StripeGroup.retriveSubscriptionCall.itemid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsPriceId: StripeGroup.retriveSubscriptionCall.priceid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            orderId: StripeGroup.retriveSubscriptionCall
                                                                                                .orderid(
                                                                                                  containerRetriveSubscriptionResponse.jsonBody,
                                                                                                )
                                                                                                .toString(),
                                                                                            subsPackName: 'Vendor Free Plan',
                                                                                            productId: StripeGroup.retriveSubscriptionCall.productId(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                          ));
                                                                                          _model.freeUpgrd = await StripeGroup.updateSubscriptionCall.call(
                                                                                            itemID: containerSubscriptionsRecord?.subsItemId,
                                                                                            priceID: 'price_1QQMYgL3aBEbReILFcntUECp',
                                                                                            upDwnSub: containerSubscriptionsRecord?.subsId,
                                                                                          );

                                                                                          _shouldSetState = true;
                                                                                          if ((_model.freeUpgrd?.succeeded ?? true)) {
                                                                                            await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                              subsPriceId: StripeGroup.updateSubscriptionCall.priceid(
                                                                                                (_model.strterUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                              productId: StripeGroup.updateSubscriptionCall.productId(
                                                                                                (_model.strterUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                            ));
                                                                                          } else {
                                                                                            if (_shouldSetState) safeSetState(() {});
                                                                                            return;
                                                                                          }

                                                                                          await widget!.vendref!.update(createVendorDetailsRecordData(
                                                                                            offerLimit: '1',
                                                                                            subsPackname: 'Vendor Free Plan',
                                                                                          ));
                                                                                        } else {
                                                                                          if (_shouldSetState) safeSetState(() {});
                                                                                          return;
                                                                                        }

                                                                                        if (_shouldSetState) safeSetState(() {});
                                                                                      },
                                                                                      text: (containerSubscriptionsRecord?.subsPackName == 'Vendor Starter Plan') || (containerSubscriptionsRecord?.subsPackName == 'Vendor Growth Plan') || (containerSubscriptionsRecord?.subsPackName == 'Vendor Premium Plan') ? 'Downgrade' : 'Current Plan',
                                                                                      options: FFButtonOptions(
                                                                                        width: MediaQuery.sizeOf(context).width * 0.9,
                                                                                        height: 40.0,
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                        color: Color(0xFFFF7622),
                                                                                        textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                              fontFamily: 'Poppins',
                                                                                              color: Colors.white,
                                                                                              fontSize: 20.0,
                                                                                              letterSpacing: 0.0,
                                                                                            ),
                                                                                        elevation: 0.0,
                                                                                        borderRadius: BorderRadius.circular(20.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width:
                                                                          250.0,
                                                                      height:
                                                                          420.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        boxShadow: [
                                                                          BoxShadow(
                                                                            blurRadius:
                                                                                16.0,
                                                                            color:
                                                                                Color(0x10000000),
                                                                            offset:
                                                                                Offset(
                                                                              6.0,
                                                                              6.0,
                                                                            ),
                                                                          )
                                                                        ],
                                                                        borderRadius:
                                                                            BorderRadius.circular(12.0),
                                                                        border:
                                                                            Border.all(
                                                                          color:
                                                                              Color(0xFFDBDBDB),
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          Align(
                                                                            alignment:
                                                                                AlignmentDirectional(0.0, 0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 60.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFFF7622),
                                                                                borderRadius: BorderRadius.only(
                                                                                  bottomLeft: Radius.circular(0.0),
                                                                                  bottomRight: Radius.circular(0.0),
                                                                                  topLeft: Radius.circular(12.0),
                                                                                  topRight: Radius.circular(12.0),
                                                                                ),
                                                                              ),
                                                                              child: Align(
                                                                                alignment: AlignmentDirectional(0.0, 0.0),
                                                                                child: Text(
                                                                                  'Starter',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.white,
                                                                                        fontSize: 24.0,
                                                                                        letterSpacing: 0.0,
                                                                                        fontWeight: FontWeight.normal,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                15.0,
                                                                                0.0,
                                                                                15.0),
                                                                            child:
                                                                                Container(
                                                                              decoration: BoxDecoration(
                                                                                color: Colors.white,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Icon(
                                                                                    Icons.currency_pound_sharp,
                                                                                    color: Color(0xFFFF7622),
                                                                                    size: 30.0,
                                                                                  ),
                                                                                  Flexible(
                                                                                    child: RichText(
                                                                                      textScaler: MediaQuery.of(context).textScaler,
                                                                                      text: TextSpan(
                                                                                        children: [
                                                                                          TextSpan(
                                                                                            text: '9',
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Poppins',
                                                                                                  color: Color(0xFFFF7622),
                                                                                                  fontSize: 44.0,
                                                                                                  letterSpacing: 0.0,
                                                                                                  fontWeight: FontWeight.w600,
                                                                                                ),
                                                                                          ),
                                                                                          TextSpan(
                                                                                            text: '.99 per month',
                                                                                            style: TextStyle(
                                                                                              fontSize: 16.0,
                                                                                            ),
                                                                                          )
                                                                                        ],
                                                                                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                              fontFamily: 'Poppins',
                                                                                              color: Color(0xFFFF7622),
                                                                                              fontSize: 44.0,
                                                                                              letterSpacing: 0.0,
                                                                                              fontWeight: FontWeight.w600,
                                                                                            ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                                                                                    child: Text(
                                                                                      'Features: ',
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Sen',
                                                                                            color: Color(0xFF7C7C7C),
                                                                                            fontSize: 18.0,
                                                                                            letterSpacing: 0.0,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                  Text(
                                                                                    'You can promote up to three products.\n\nThis package includes essential features to help increase your visibility.\n\n\n',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Sen',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          fontSize: 12.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.normal,
                                                                                        ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                14.0,
                                                                                0.0,
                                                                                14.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 1.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFDBDBDB),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                children: [
                                                                                  Text(
                                                                                    '3 products for unlimited days',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFFFF7622),
                                                                                          fontSize: 15.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.w500,
                                                                                        ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 14.0, 0.0, 14.0),
                                                                                    child: FFButtonWidget(
                                                                                      onPressed: () async {
                                                                                        var _shouldSetState = false;
                                                                                        var confirmDialogResponse = await showDialog<bool>(
                                                                                              context: context,
                                                                                              builder: (alertDialogContext) {
                                                                                                return AlertDialog(
                                                                                                  title: Text('Do you want to upgrade?'),
                                                                                                  content: Text('By clicking Yes you will get charged of £9.99'),
                                                                                                  actions: [
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                                      child: Text('No'),
                                                                                                    ),
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                                      child: Text('Yes'),
                                                                                                    ),
                                                                                                  ],
                                                                                                );
                                                                                              },
                                                                                            ) ??
                                                                                            false;
                                                                                        if (confirmDialogResponse) {
                                                                                          await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                            subsAmount: 9.99,
                                                                                            paymentMethod: StripeGroup.retriveSubscriptionCall.defaultpaymentmethod(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsId: StripeGroup.retriveSubscriptionCall.subsid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsItemId: StripeGroup.retriveSubscriptionCall.itemid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsPriceId: StripeGroup.retriveSubscriptionCall.priceid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            orderId: StripeGroup.retriveSubscriptionCall
                                                                                                .orderid(
                                                                                                  containerRetriveSubscriptionResponse.jsonBody,
                                                                                                )
                                                                                                .toString(),
                                                                                            subsPackName: 'Vendor Starter Plan',
                                                                                            productId: StripeGroup.retriveSubscriptionCall.productId(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                          ));
                                                                                          _model.strterUpgrd = await StripeGroup.updateSubscriptionCall.call(
                                                                                            itemID: containerSubscriptionsRecord?.subsItemId,
                                                                                            priceID: 'price_1QQMYlL3aBEbReILX0X7iCdR',
                                                                                            upDwnSub: containerSubscriptionsRecord?.subsId,
                                                                                          );

                                                                                          _shouldSetState = true;
                                                                                          if ((_model.strterUpgrd?.succeeded ?? true)) {
                                                                                            await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                              subsPriceId: StripeGroup.updateSubscriptionCall.priceid(
                                                                                                (_model.strterUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                              productId: StripeGroup.updateSubscriptionCall.productId(
                                                                                                (_model.strterUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                            ));
                                                                                          } else {
                                                                                            if (_shouldSetState) safeSetState(() {});
                                                                                            return;
                                                                                          }

                                                                                          await widget!.vendref!.update(createVendorDetailsRecordData(
                                                                                            offerLimit: '3',
                                                                                            subsPackname: 'Vendor Starter Plan',
                                                                                          ));
                                                                                        } else {
                                                                                          if (_shouldSetState) safeSetState(() {});
                                                                                          return;
                                                                                        }

                                                                                        if (_shouldSetState) safeSetState(() {});
                                                                                      },
                                                                                      text: () {
                                                                                        if ((containerSubscriptionsRecord?.subsPackName == 'Vendor Growth Plan') || (containerSubscriptionsRecord?.subsPackName == 'Vendor Premium Plan')) {
                                                                                          return 'Downgrade';
                                                                                        } else if (containerSubscriptionsRecord?.subsPackName == 'Vendor Free Plan') {
                                                                                          return 'Upgrade';
                                                                                        } else {
                                                                                          return 'Current Plan';
                                                                                        }
                                                                                      }(),
                                                                                      options: FFButtonOptions(
                                                                                        width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                        height: 40.0,
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                        color: Color(0xFFFF7622),
                                                                                        textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                              fontFamily: 'Poppins',
                                                                                              color: Colors.white,
                                                                                              fontSize: 20.0,
                                                                                              letterSpacing: 0.0,
                                                                                            ),
                                                                                        elevation: 0.0,
                                                                                        borderRadius: BorderRadius.circular(20.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width:
                                                                          250.0,
                                                                      height:
                                                                          420.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        boxShadow: [
                                                                          BoxShadow(
                                                                            blurRadius:
                                                                                16.0,
                                                                            color:
                                                                                Color(0x10000000),
                                                                            offset:
                                                                                Offset(
                                                                              6.0,
                                                                              6.0,
                                                                            ),
                                                                          )
                                                                        ],
                                                                        borderRadius:
                                                                            BorderRadius.circular(12.0),
                                                                        border:
                                                                            Border.all(
                                                                          color:
                                                                              Color(0xFFDBDBDB),
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          Align(
                                                                            alignment:
                                                                                AlignmentDirectional(0.0, 0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 60.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFFF7622),
                                                                                borderRadius: BorderRadius.only(
                                                                                  bottomLeft: Radius.circular(0.0),
                                                                                  bottomRight: Radius.circular(0.0),
                                                                                  topLeft: Radius.circular(12.0),
                                                                                  topRight: Radius.circular(12.0),
                                                                                ),
                                                                              ),
                                                                              child: Align(
                                                                                alignment: AlignmentDirectional(0.0, 0.0),
                                                                                child: Text(
                                                                                  'Growth',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.white,
                                                                                        fontSize: 24.0,
                                                                                        letterSpacing: 0.0,
                                                                                        fontWeight: FontWeight.normal,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                15.0,
                                                                                0.0,
                                                                                15.0),
                                                                            child:
                                                                                Container(
                                                                              decoration: BoxDecoration(
                                                                                color: Colors.white,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Icon(
                                                                                    Icons.currency_pound_sharp,
                                                                                    color: Color(0xFFFF7622),
                                                                                    size: 30.0,
                                                                                  ),
                                                                                  RichText(
                                                                                    textScaler: MediaQuery.of(context).textScaler,
                                                                                    text: TextSpan(
                                                                                      children: [
                                                                                        TextSpan(
                                                                                          text: '19',
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                color: Color(0xFFFF7622),
                                                                                                fontSize: 44.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                        TextSpan(
                                                                                          text: '.99 per month',
                                                                                          style: TextStyle(
                                                                                            fontSize: 16.0,
                                                                                          ),
                                                                                        )
                                                                                      ],
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Poppins',
                                                                                            color: Color(0xFFFF7622),
                                                                                            fontSize: 44.0,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.w600,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                                                                                    child: Text(
                                                                                      'Features: ',
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Sen',
                                                                                            color: Color(0xFF7C7C7C),
                                                                                            fontSize: 18.0,
                                                                                            letterSpacing: 0.0,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                  Text(
                                                                                    'Promote up to eight products.\n\nIncludes all features from the Starter Package.\n\nplus access to additional promotional options at preferential rates.',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Sen',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          fontSize: 12.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.normal,
                                                                                        ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                14.0,
                                                                                0.0,
                                                                                14.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 1.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFDBDBDB),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                children: [
                                                                                  Text(
                                                                                    '8 products for unlimited days',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFFFF7622),
                                                                                          fontSize: 15.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.w500,
                                                                                        ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 14.0, 0.0, 14.0),
                                                                                    child: FFButtonWidget(
                                                                                      onPressed: () async {
                                                                                        var _shouldSetState = false;
                                                                                        var confirmDialogResponse = await showDialog<bool>(
                                                                                              context: context,
                                                                                              builder: (alertDialogContext) {
                                                                                                return AlertDialog(
                                                                                                  title: Text('Do you want to upgrade?'),
                                                                                                  content: Text('By clicking Yes you will get charged of £19.99'),
                                                                                                  actions: [
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                                      child: Text('No'),
                                                                                                    ),
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                                      child: Text('Yes'),
                                                                                                    ),
                                                                                                  ],
                                                                                                );
                                                                                              },
                                                                                            ) ??
                                                                                            false;
                                                                                        if (confirmDialogResponse) {
                                                                                          await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                            subsAmount: 19.99,
                                                                                            paymentMethod: StripeGroup.retriveSubscriptionCall.defaultpaymentmethod(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsId: StripeGroup.retriveSubscriptionCall.subsid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsItemId: StripeGroup.retriveSubscriptionCall.itemid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsPriceId: StripeGroup.retriveSubscriptionCall.priceid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            orderId: StripeGroup.retriveSubscriptionCall
                                                                                                .orderid(
                                                                                                  containerRetriveSubscriptionResponse.jsonBody,
                                                                                                )
                                                                                                .toString(),
                                                                                            subsPackName: 'Vendor Growth Plan',
                                                                                            productId: StripeGroup.retriveSubscriptionCall.productId(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                          ));
                                                                                          _model.grwthUpgrd = await StripeGroup.updateSubscriptionCall.call(
                                                                                            itemID: containerSubscriptionsRecord?.subsItemId,
                                                                                            priceID: 'price_1QQMYiL3aBEbReILV2fEPPI9',
                                                                                            upDwnSub: containerSubscriptionsRecord?.subsId,
                                                                                          );

                                                                                          _shouldSetState = true;
                                                                                          if ((_model.grwthUpgrd?.succeeded ?? true)) {
                                                                                            await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                              subsPriceId: StripeGroup.updateSubscriptionCall.priceid(
                                                                                                (_model.grwthUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                              productId: StripeGroup.updateSubscriptionCall.productId(
                                                                                                (_model.grwthUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                            ));
                                                                                          } else {
                                                                                            if (_shouldSetState) safeSetState(() {});
                                                                                            return;
                                                                                          }

                                                                                          await widget!.vendref!.update(createVendorDetailsRecordData(
                                                                                            offerLimit: '8',
                                                                                            subsPackname: 'Vendor Growth Plan',
                                                                                          ));
                                                                                        } else {
                                                                                          if (_shouldSetState) safeSetState(() {});
                                                                                          return;
                                                                                        }

                                                                                        if (_shouldSetState) safeSetState(() {});
                                                                                      },
                                                                                      text: () {
                                                                                        if ((containerSubscriptionsRecord?.subsPackName == 'Vendor Starter Plan') || (containerSubscriptionsRecord?.subsPackName == 'Vendor Free Plan')) {
                                                                                          return 'Upgrade';
                                                                                        } else if (containerSubscriptionsRecord?.subsPackName == 'Vendor Premium Plan') {
                                                                                          return 'Downgrade';
                                                                                        } else {
                                                                                          return 'Current Plan';
                                                                                        }
                                                                                      }(),
                                                                                      options: FFButtonOptions(
                                                                                        width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                        height: 40.0,
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                        color: Color(0xFFFF7622),
                                                                                        textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                              fontFamily: 'Poppins',
                                                                                              color: Colors.white,
                                                                                              fontSize: 20.0,
                                                                                              letterSpacing: 0.0,
                                                                                            ),
                                                                                        elevation: 0.0,
                                                                                        borderRadius: BorderRadius.circular(20.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width:
                                                                          250.0,
                                                                      height:
                                                                          420.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                        borderRadius:
                                                                            BorderRadius.circular(12.0),
                                                                        border:
                                                                            Border.all(
                                                                          color:
                                                                              Color(0xFFDBDBDB),
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                      ),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          Align(
                                                                            alignment:
                                                                                AlignmentDirectional(0.0, 0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 60.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFFF7622),
                                                                                borderRadius: BorderRadius.only(
                                                                                  bottomLeft: Radius.circular(0.0),
                                                                                  bottomRight: Radius.circular(0.0),
                                                                                  topLeft: Radius.circular(12.0),
                                                                                  topRight: Radius.circular(12.0),
                                                                                ),
                                                                              ),
                                                                              child: Align(
                                                                                alignment: AlignmentDirectional(0.0, 0.0),
                                                                                child: Text(
                                                                                  'Premium',
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.white,
                                                                                        fontSize: 24.0,
                                                                                        letterSpacing: 0.0,
                                                                                        fontWeight: FontWeight.normal,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                14.0,
                                                                                0.0,
                                                                                14.0),
                                                                            child:
                                                                                Container(
                                                                              decoration: BoxDecoration(
                                                                                color: Colors.white,
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Icon(
                                                                                    Icons.currency_pound_sharp,
                                                                                    color: Color(0xFFFF7622),
                                                                                    size: 30.0,
                                                                                  ),
                                                                                  RichText(
                                                                                    textScaler: MediaQuery.of(context).textScaler,
                                                                                    text: TextSpan(
                                                                                      children: [
                                                                                        TextSpan(
                                                                                          text: '34',
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                color: Color(0xFFFF7622),
                                                                                                fontSize: 44.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                        TextSpan(
                                                                                          text: '.99 per month',
                                                                                          style: TextStyle(
                                                                                            fontSize: 16.0,
                                                                                          ),
                                                                                        )
                                                                                      ],
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Poppins',
                                                                                            color: Color(0xFFFF7622),
                                                                                            fontSize: 44.0,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.w600,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                                                                                    child: Text(
                                                                                      'Features: ',
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Sen',
                                                                                            color: Color(0xFF7C7C7C),
                                                                                            fontSize: 18.0,
                                                                                            letterSpacing: 0.0,
                                                                                          ),
                                                                                    ),
                                                                                  ),
                                                                                  Text(
                                                                                    'You can promote up to fifteen products.\n\nIncludes all features from the Growth Package.\n\nMaking it ideal for vendors looking to maximize their presence.',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Sen',
                                                                                          color: Color(0xFF7C7C7C),
                                                                                          fontSize: 12.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.normal,
                                                                                        ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                14.0,
                                                                                0.0,
                                                                                14.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              height: 1.0,
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFFDBDBDB),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              decoration: BoxDecoration(),
                                                                              child: Column(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                children: [
                                                                                  Text(
                                                                                    '15 products for unlimited days',
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Readex Pro',
                                                                                          color: Color(0xFFFF7622),
                                                                                          fontSize: 15.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.w500,
                                                                                        ),
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 14.0, 0.0, 14.0),
                                                                                    child: FFButtonWidget(
                                                                                      onPressed: () async {
                                                                                        var _shouldSetState = false;
                                                                                        var confirmDialogResponse = await showDialog<bool>(
                                                                                              context: context,
                                                                                              builder: (alertDialogContext) {
                                                                                                return AlertDialog(
                                                                                                  title: Text('Do you want to upgrade?'),
                                                                                                  content: Text('By clicking Yes you will get charged of £34.99'),
                                                                                                  actions: [
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                                      child: Text('No'),
                                                                                                    ),
                                                                                                    TextButton(
                                                                                                      onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                                      child: Text('Yes'),
                                                                                                    ),
                                                                                                  ],
                                                                                                );
                                                                                              },
                                                                                            ) ??
                                                                                            false;
                                                                                        if (confirmDialogResponse) {
                                                                                          await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                            subsAmount: 34.99,
                                                                                            paymentMethod: StripeGroup.retriveSubscriptionCall.defaultpaymentmethod(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsId: StripeGroup.retriveSubscriptionCall.subsid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsItemId: StripeGroup.retriveSubscriptionCall.itemid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            subsPriceId: StripeGroup.retriveSubscriptionCall.priceid(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                            orderId: StripeGroup.retriveSubscriptionCall
                                                                                                .orderid(
                                                                                                  containerRetriveSubscriptionResponse.jsonBody,
                                                                                                )
                                                                                                .toString(),
                                                                                            subsPackName: 'Vendor Premium Plan',
                                                                                            productId: StripeGroup.retriveSubscriptionCall.productId(
                                                                                              containerRetriveSubscriptionResponse.jsonBody,
                                                                                            ),
                                                                                          ));
                                                                                          _model.premiumUpgrd = await StripeGroup.updateSubscriptionCall.call(
                                                                                            itemID: containerSubscriptionsRecord?.subsItemId,
                                                                                            priceID: 'price_1QQMYdL3aBEbReILBWnsED1b',
                                                                                            upDwnSub: containerSubscriptionsRecord?.subsId,
                                                                                          );

                                                                                          _shouldSetState = true;
                                                                                          if ((_model.premiumUpgrd?.succeeded ?? true)) {
                                                                                            await containerSubscriptionsRecord!.reference.update(createSubscriptionsRecordData(
                                                                                              subsPriceId: StripeGroup.updateSubscriptionCall.priceid(
                                                                                                (_model.premiumUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                              productId: StripeGroup.updateSubscriptionCall.productId(
                                                                                                (_model.premiumUpgrd?.jsonBody ?? ''),
                                                                                              ),
                                                                                            ));
                                                                                          } else {
                                                                                            if (_shouldSetState) safeSetState(() {});
                                                                                            return;
                                                                                          }

                                                                                          await widget!.vendref!.update(createVendorDetailsRecordData(
                                                                                            offerLimit: '15',
                                                                                            subsPackname: 'Vendor Premium Plan',
                                                                                          ));
                                                                                        } else {
                                                                                          if (_shouldSetState) safeSetState(() {});
                                                                                          return;
                                                                                        }

                                                                                        if (_shouldSetState) safeSetState(() {});
                                                                                      },
                                                                                      text: (containerSubscriptionsRecord?.subsPackName == 'Vendor Starter Plan') || (containerSubscriptionsRecord?.subsPackName == 'Vendor Growth Plan') || (containerSubscriptionsRecord?.subsPackName == 'Vendor Free Plan') ? 'Upgrade' : 'Current Plan',
                                                                                      options: FFButtonOptions(
                                                                                        width: MediaQuery.sizeOf(context).width * 1.0,
                                                                                        height: 40.0,
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                        color: Color(0xFFFF7622),
                                                                                        textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                              fontFamily: 'Poppins',
                                                                                              color: Colors.white,
                                                                                              fontSize: 20.0,
                                                                                              letterSpacing: 0.0,
                                                                                            ),
                                                                                        elevation: 0.0,
                                                                                        borderRadius: BorderRadius.circular(20.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ));
      },
    );
  }
}
