import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/admin_drawer_widget.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'lottery_list_model.dart';
export 'lottery_list_model.dart';

class LotteryListWidget extends StatefulWidget {
  const LotteryListWidget({super.key});

  static String routeName = 'LotteryList';
  static String routePath = '/LotteryList';

  @override
  State<LotteryListWidget> createState() => _LotteryListWidgetState();
}

class _LotteryListWidgetState extends State<LotteryListWidget>
    with TickerProviderStateMixin {
  late LotteryListModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LotteryListModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.instantTimer = InstantTimer.periodic(
        duration: Duration(milliseconds: 1000),
        callback: (timer) async {
          await actions.updateOfferStatus(
            'luckyDraw_Offer',
            'lukcyDraw_Offer_active_period',
            'luckyDraw_offer_end_period',
            'lukcyDraw_Offer_status',
          );
        },
        startImmediately: true,
      );
    });

    _model.tabBarController = TabController(
      vsync: this,
      length: 3,
      initialIndex: 0,
    )..addListener(() => safeSetState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<VendorDetailsRecord>>(
      stream: queryVendorDetailsRecord(
        queryBuilder: (vendorDetailsRecord) => vendorDetailsRecord.where(
          'vendor_email',
          isEqualTo: currentUserEmail,
        ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Color(0xFFF5F7FB),
            body: Center(
              child: SizedBox(
                width: 60.0,
                height: 60.0,
                child: SpinKitRipple(
                  color: Color(0xFFFF7622),
                  size: 60.0,
                ),
              ),
            ),
          );
        }
        List<VendorDetailsRecord> lotteryListVendorDetailsRecordList =
            snapshot.data!;
        final lotteryListVendorDetailsRecord =
            lotteryListVendorDetailsRecordList.isNotEmpty
                ? lotteryListVendorDetailsRecordList.first
                : null;

        return Title(
            title: 'LotteryList',
            color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
            child: GestureDetector(
              onTap: () {
                FocusScope.of(context).unfocus();
                FocusManager.instance.primaryFocus?.unfocus();
              },
              child: Scaffold(
                key: scaffoldKey,
                backgroundColor: Color(0xFFF5F7FB),
                drawer: Container(
                  width: MediaQuery.sizeOf(context).width * 0.9,
                  child: Drawer(
                    elevation: 16.0,
                    child: Visibility(
                      visible: responsiveVisibility(
                        context: context,
                        desktop: false,
                      ),
                      child: Container(
                        width: MediaQuery.sizeOf(context).width * 0.2,
                        decoration: BoxDecoration(
                          color: Colors.white,
                        ),
                        child: Stack(
                          children: [
                            if (valueOrDefault(
                                    currentUserDocument?.userType, '') ==
                                'Vendor')
                              AuthUserStreamWidget(
                                builder: (context) => wrapWithModel(
                                  model: _model.vendDrawerModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: VendDrawerWidget(
                                    parameter1: lotteryListVendorDetailsRecord
                                        ?.businessProfileLogo,
                                    parameter2: lotteryListVendorDetailsRecord
                                        ?.vendorUsername,
                                    parameter3: lotteryListVendorDetailsRecord
                                        ?.vendorId,
                                    parameter4: lotteryListVendorDetailsRecord
                                        ?.reference,
                                  ),
                                ),
                              ),
                            if (valueOrDefault(
                                    currentUserDocument?.userType, '') ==
                                'Admin')
                              AuthUserStreamWidget(
                                builder: (context) => wrapWithModel(
                                  model: _model.adminDrawerModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: AdminDrawerWidget(),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                body: SafeArea(
                  top: true,
                  child: Container(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    decoration: BoxDecoration(),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        if (responsiveVisibility(
                          context: context,
                          phone: false,
                          tablet: false,
                          tabletLandscape: false,
                        ))
                          Container(
                            width: MediaQuery.sizeOf(context).width * 0.2,
                            decoration: BoxDecoration(
                              color: Colors.white,
                            ),
                            child: Stack(
                              children: [
                                if (valueOrDefault(
                                        currentUserDocument?.userType, '') ==
                                    'Vendor')
                                  AuthUserStreamWidget(
                                    builder: (context) => wrapWithModel(
                                      model: _model.vendDrawerModel1,
                                      updateCallback: () => safeSetState(() {}),
                                      child: VendDrawerWidget(
                                        parameter1:
                                            lotteryListVendorDetailsRecord
                                                ?.businessProfileLogo,
                                        parameter2:
                                            lotteryListVendorDetailsRecord
                                                ?.vendorUsername,
                                        parameter3:
                                            lotteryListVendorDetailsRecord
                                                ?.vendorId,
                                        parameter4:
                                            lotteryListVendorDetailsRecord
                                                ?.reference,
                                      ),
                                    ),
                                  ),
                                if (valueOrDefault(
                                        currentUserDocument?.userType, '') ==
                                    'Admin')
                                  AuthUserStreamWidget(
                                    builder: (context) => wrapWithModel(
                                      model: _model.adminDrawerModel1,
                                      updateCallback: () => safeSetState(() {}),
                                      child: AdminDrawerWidget(),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                16.0, 16.0, 16.0, 16.0),
                            child: Container(
                              width: MediaQuery.sizeOf(context).width > 480.0
                                  ? MediaQuery.sizeOf(context).width
                                  : MediaQuery.sizeOf(context).width,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    blurRadius: 16.0,
                                    color: Color(0x0E000000),
                                    offset: Offset(
                                      4.0,
                                      4.0,
                                    ),
                                  )
                                ],
                                borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(10.0),
                                  bottomRight: Radius.circular(10.0),
                                  topLeft: Radius.circular(10.0),
                                  topRight: Radius.circular(10.0),
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 1.0,
                                    height: 80.0,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      boxShadow: [
                                        BoxShadow(
                                          blurRadius: 4.0,
                                          color: Color(0x33000000),
                                          offset: Offset(
                                            0.0,
                                            2.0,
                                          ),
                                        )
                                      ],
                                      borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(0.0),
                                        bottomRight: Radius.circular(0.0),
                                        topLeft: Radius.circular(10.0),
                                        topRight: Radius.circular(10.0),
                                      ),
                                      border: Border.all(
                                        color: Color(0xFFDCDCDC),
                                        width: 1.0,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(-1.0, 0.0),
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    34.0, 0.0, 0.0, 0.0),
                                            child: Text(
                                              'Lucky Draw',
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily: 'Poppins',
                                                    color: Color(0xFF656565),
                                                    fontSize: 26.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                            ),
                                          ),
                                        ),
                                        if (responsiveVisibility(
                                          context: context,
                                          desktop: false,
                                        ))
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 20.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                scaffoldKey.currentState!
                                                    .openDrawer();
                                              },
                                              child: Icon(
                                                Icons.menu_rounded,
                                                color: Color(0xFFFF7622),
                                                size: 30.0,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 30.0, 0.0, 0.0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                            bottomLeft: Radius.circular(10.0),
                                            bottomRight: Radius.circular(10.0),
                                            topLeft: Radius.circular(0.0),
                                            topRight: Radius.circular(0.0),
                                          ),
                                        ),
                                        child: Stack(
                                          children: [
                                            Column(
                                              children: [
                                                Align(
                                                  alignment: Alignment(0.0, 0),
                                                  child: TabBar(
                                                    labelColor:
                                                        Color(0xFFFF7622),
                                                    unselectedLabelColor:
                                                        Color(0xFF7C7C7C),
                                                    labelStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .titleMedium
                                                            .override(
                                                              fontFamily:
                                                                  'Poppins',
                                                              fontSize: () {
                                                                if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <
                                                                    kBreakpointSmall) {
                                                                  return 16.0;
                                                                } else if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <
                                                                    kBreakpointMedium) {
                                                                  return 16.0;
                                                                } else if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <
                                                                    kBreakpointLarge) {
                                                                  return 17.0;
                                                                } else {
                                                                  return 18.0;
                                                                }
                                                              }(),
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                            ),
                                                    unselectedLabelStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .titleMedium
                                                            .override(
                                                              fontFamily:
                                                                  'Poppins',
                                                              fontSize: () {
                                                                if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <
                                                                    kBreakpointSmall) {
                                                                  return 16.0;
                                                                } else if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <
                                                                    kBreakpointMedium) {
                                                                  return 16.0;
                                                                } else if (MediaQuery.sizeOf(
                                                                            context)
                                                                        .width <
                                                                    kBreakpointLarge) {
                                                                  return 17.0;
                                                                } else {
                                                                  return 18.0;
                                                                }
                                                              }(),
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                            ),
                                                    indicatorColor:
                                                        Color(0xFFFF7622),
                                                    tabs: [
                                                      Tab(
                                                        text: () {
                                                          if (MediaQuery.sizeOf(
                                                                      context)
                                                                  .width <
                                                              kBreakpointSmall) {
                                                            return true;
                                                          } else if (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .width <
                                                              kBreakpointMedium) {
                                                            return true;
                                                          } else if (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .width <
                                                              kBreakpointLarge) {
                                                            return true;
                                                          } else {
                                                            return false;
                                                          }
                                                        }()
                                                            ? 'Live'
                                                            : 'Live Competition',
                                                      ),
                                                      Tab(
                                                        text: () {
                                                          if (MediaQuery.sizeOf(
                                                                      context)
                                                                  .width <
                                                              kBreakpointSmall) {
                                                            return true;
                                                          } else if (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .width <
                                                              kBreakpointMedium) {
                                                            return true;
                                                          } else if (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .width <
                                                              kBreakpointLarge) {
                                                            return true;
                                                          } else {
                                                            return false;
                                                          }
                                                        }()
                                                            ? 'Expired'
                                                            : 'Expired Competition',
                                                      ),
                                                      Tab(
                                                        text: () {
                                                          if (MediaQuery.sizeOf(
                                                                      context)
                                                                  .width <
                                                              kBreakpointSmall) {
                                                            return true;
                                                          } else if (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .width <
                                                              kBreakpointMedium) {
                                                            return true;
                                                          } else if (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .width <
                                                              kBreakpointLarge) {
                                                            return true;
                                                          } else {
                                                            return false;
                                                          }
                                                        }()
                                                            ? 'Upcoming'
                                                            : 'Upcoming Competition',
                                                      ),
                                                    ],
                                                    controller:
                                                        _model.tabBarController,
                                                    onTap: (i) async {
                                                      [
                                                        () async {},
                                                        () async {},
                                                        () async {}
                                                      ][i]();
                                                    },
                                                  ),
                                                ),
                                                Expanded(
                                                  child: TabBarView(
                                                    controller:
                                                        _model.tabBarController,
                                                    children: [
                                                      StreamBuilder<
                                                          List<
                                                              LuckyDrawOfferRecord>>(
                                                        stream:
                                                            queryLuckyDrawOfferRecord(
                                                          queryBuilder:
                                                              (luckyDrawOfferRecord) =>
                                                                  luckyDrawOfferRecord
                                                                      .where(
                                                            'lukcyDraw_Offer_status',
                                                            isEqualTo: 'Live',
                                                          ),
                                                        ),
                                                        builder: (context,
                                                            snapshot) {
                                                          // Customize what your widget looks like when it's loading.
                                                          if (!snapshot
                                                              .hasData) {
                                                            return Center(
                                                              child: SizedBox(
                                                                width: 60.0,
                                                                height: 60.0,
                                                                child:
                                                                    SpinKitRipple(
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  size: 60.0,
                                                                ),
                                                              ),
                                                            );
                                                          }
                                                          List<LuckyDrawOfferRecord>
                                                              listViewLuckyDrawOfferRecordList =
                                                              snapshot.data!;

                                                          return ListView
                                                              .builder(
                                                            padding:
                                                                EdgeInsets.zero,
                                                            scrollDirection:
                                                                Axis.vertical,
                                                            itemCount:
                                                                listViewLuckyDrawOfferRecordList
                                                                    .length,
                                                            itemBuilder: (context,
                                                                listViewIndex) {
                                                              final listViewLuckyDrawOfferRecord =
                                                                  listViewLuckyDrawOfferRecordList[
                                                                      listViewIndex];
                                                              return Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        20.0,
                                                                        0.0,
                                                                        20.0,
                                                                        0.0),
                                                                child: InkWell(
                                                                  splashColor:
                                                                      Colors
                                                                          .transparent,
                                                                  focusColor: Colors
                                                                      .transparent,
                                                                  hoverColor: Colors
                                                                      .transparent,
                                                                  highlightColor:
                                                                      Colors
                                                                          .transparent,
                                                                  onTap:
                                                                      () async {
                                                                    context
                                                                        .pushNamed(
                                                                      LotterydetailpageWidget
                                                                          .routeName,
                                                                      queryParameters:
                                                                          {
                                                                        'loterdoc':
                                                                            serializeParam(
                                                                          listViewLuckyDrawOfferRecord,
                                                                          ParamType
                                                                              .Document,
                                                                        ),
                                                                      }.withoutNulls,
                                                                      extra: <String,
                                                                          dynamic>{
                                                                        'loterdoc':
                                                                            listViewLuckyDrawOfferRecord,
                                                                      },
                                                                    );
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    width: MediaQuery.sizeOf(context)
                                                                            .width *
                                                                        1.0,
                                                                    decoration:
                                                                        BoxDecoration(),
                                                                    child:
                                                                        Align(
                                                                      alignment:
                                                                          AlignmentDirectional(
                                                                              0.0,
                                                                              0.0),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.min,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children:
                                                                            [
                                                                          Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 0.9,
                                                                            decoration:
                                                                                BoxDecoration(),
                                                                            child:
                                                                                Row(
                                                                              mainAxisSize: MainAxisSize.min,
                                                                              children: [
                                                                                Wrap(
                                                                                  spacing: 20.0,
                                                                                  runSpacing: 20.0,
                                                                                  alignment: WrapAlignment.start,
                                                                                  crossAxisAlignment: WrapCrossAlignment.start,
                                                                                  direction: Axis.horizontal,
                                                                                  runAlignment: WrapAlignment.start,
                                                                                  verticalDirection: VerticalDirection.down,
                                                                                  clipBehavior: Clip.none,
                                                                                  children: [
                                                                                    Container(
                                                                                      width: 100.0,
                                                                                      height: 100.0,
                                                                                      decoration: BoxDecoration(
                                                                                        color: Color(0xFFFFECD4),
                                                                                        image: DecorationImage(
                                                                                          fit: BoxFit.contain,
                                                                                          alignment: AlignmentDirectional(0.0, 0.0),
                                                                                          image: Image.network(
                                                                                            valueOrDefault<String>(
                                                                                              listViewLuckyDrawOfferRecord.lukcyDrawOfferImage,
                                                                                              'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                            ),
                                                                                          ).image,
                                                                                        ),
                                                                                        borderRadius: BorderRadius.circular(10.0),
                                                                                      ),
                                                                                    ),
                                                                                    Container(
                                                                                      width: 500.0,
                                                                                      decoration: BoxDecoration(),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.max,
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        children: [
                                                                                          Padding(
                                                                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                            child: Text(
                                                                                              listViewLuckyDrawOfferRecord.luckyDrawOffrName,
                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                    fontFamily: 'Poppins',
                                                                                                    color: Color(0xFF464646),
                                                                                                    fontSize: () {
                                                                                                      if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                        return 20.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                        return 22.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                        return 23.0;
                                                                                                      } else {
                                                                                                        return 24.0;
                                                                                                      }
                                                                                                    }(),
                                                                                                    letterSpacing: 0.0,
                                                                                                    fontWeight: FontWeight.w500,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                          Padding(
                                                                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                            child: RichText(
                                                                                              textScaler: MediaQuery.of(context).textScaler,
                                                                                              text: TextSpan(
                                                                                                children: [
                                                                                                  TextSpan(
                                                                                                    text: 'Started on: ',
                                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                          fontFamily: 'Poppins',
                                                                                                          color: Color(0xFF7C7C7C),
                                                                                                          fontSize: () {
                                                                                                            if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                              return 14.0;
                                                                                                            } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                              return 14.0;
                                                                                                            } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                              return 15.0;
                                                                                                            } else {
                                                                                                              return 16.0;
                                                                                                            }
                                                                                                          }(),
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w500,
                                                                                                        ),
                                                                                                  ),
                                                                                                  TextSpan(
                                                                                                    text: dateTimeFormat("d/M/y", listViewLuckyDrawOfferRecord.lukcyDrawOfferActivePeriod!),
                                                                                                    style: GoogleFonts.getFont(
                                                                                                      'Poppins',
                                                                                                      color: Color(0xFFFF7622),
                                                                                                      fontWeight: FontWeight.w500,
                                                                                                      fontSize: () {
                                                                                                        if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                          return 14.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                          return 14.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                          return 15.0;
                                                                                                        } else {
                                                                                                          return 16.0;
                                                                                                        }
                                                                                                      }(),
                                                                                                    ),
                                                                                                  )
                                                                                                ],
                                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                      fontFamily: 'Readex Pro',
                                                                                                      letterSpacing: 0.0,
                                                                                                    ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          RichText(
                                                                                            textScaler: MediaQuery.of(context).textScaler,
                                                                                            text: TextSpan(
                                                                                              children: [
                                                                                                TextSpan(
                                                                                                  text: 'Deal Ends: ',
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        fontFamily: 'Poppins',
                                                                                                        color: Color(0xFF7C7C7C),
                                                                                                        fontSize: () {
                                                                                                          if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                            return 15.0;
                                                                                                          } else {
                                                                                                            return 16.0;
                                                                                                          }
                                                                                                        }(),
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                      ),
                                                                                                ),
                                                                                                TextSpan(
                                                                                                  text: dateTimeFormat("d/M/y", listViewLuckyDrawOfferRecord.luckyDrawOfferEndPeriod!),
                                                                                                  style: GoogleFonts.getFont(
                                                                                                    'Poppins',
                                                                                                    color: Color(0xFFFF7622),
                                                                                                    fontWeight: FontWeight.w500,
                                                                                                    fontSize: () {
                                                                                                      if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                        return 15.0;
                                                                                                      } else {
                                                                                                        return 16.0;
                                                                                                      }
                                                                                                    }(),
                                                                                                  ),
                                                                                                )
                                                                                              ],
                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                    fontFamily: 'Readex Pro',
                                                                                                    letterSpacing: 0.0,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                    Container(
                                                                                      decoration: BoxDecoration(),
                                                                                      child: Visibility(
                                                                                        visible: valueOrDefault(currentUserDocument?.userType, '') == 'Vendor',
                                                                                        child: AuthUserStreamWidget(
                                                                                          builder: (context) => FFButtonWidget(
                                                                                            onPressed: listViewLuckyDrawOfferRecord.luckyDrawOfferParticipantId.contains(lotteryListVendorDetailsRecord?.vendorId)
                                                                                                ? null
                                                                                                : () async {
                                                                                                    await listViewLuckyDrawOfferRecord.reference.update({
                                                                                                      ...mapToFirestore(
                                                                                                        {
                                                                                                          'luckyDraw_offer_participant_id': FieldValue.arrayUnion([
                                                                                                            lotteryListVendorDetailsRecord?.vendorId
                                                                                                          ]),
                                                                                                        },
                                                                                                      ),
                                                                                                    });

                                                                                                    await lotteryListVendorDetailsRecord!.reference.update({
                                                                                                      ...mapToFirestore(
                                                                                                        {
                                                                                                          'lot_partip_list': FieldValue.arrayUnion([
                                                                                                            listViewLuckyDrawOfferRecord.reference
                                                                                                          ]),
                                                                                                        },
                                                                                                      ),
                                                                                                    });

                                                                                                    await LuckyDrawParticipantsRecord.collection.doc().set(createLuckyDrawParticipantsRecordData(
                                                                                                          lukcyDrawParticipantRef: lotteryListVendorDetailsRecord?.reference,
                                                                                                          lukcyDrawParticipantName: lotteryListVendorDetailsRecord?.businessName,
                                                                                                          lukcyDrawParticipantId: lotteryListVendorDetailsRecord?.vendorId,
                                                                                                          lukcyDrawPaticipatedDate: getCurrentTimestamp,
                                                                                                          lukcyDrawOfferName: listViewLuckyDrawOfferRecord.luckyDrawOffrName,
                                                                                                          lukcyDrawOfferId: listViewLuckyDrawOfferRecord.lukcyDrawOfferId,
                                                                                                          lukcyDrawOfferRef: listViewLuckyDrawOfferRecord.reference,
                                                                                                        ));

                                                                                                    safeSetState(() {});
                                                                                                  },
                                                                                            text: listViewLuckyDrawOfferRecord.luckyDrawOfferParticipantId.contains(lotteryListVendorDetailsRecord?.vendorId) ? 'Entered' : 'Enter Competition',
                                                                                            options: FFButtonOptions(
                                                                                              width: 250.0,
                                                                                              height: 40.0,
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                              iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                              color: Color(0xFFFF7622),
                                                                                              textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                                    fontFamily: 'Readex Pro',
                                                                                                    color: Colors.white,
                                                                                                    fontSize: () {
                                                                                                      if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                        return 15.0;
                                                                                                      } else {
                                                                                                        return 16.0;
                                                                                                      }
                                                                                                    }(),
                                                                                                    letterSpacing: 0.0,
                                                                                                  ),
                                                                                              elevation: 0.0,
                                                                                              borderRadius: BorderRadius.circular(8.0),
                                                                                              disabledColor: Color(0xFF9F9999),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            width:
                                                                                MediaQuery.sizeOf(context).width * 1.0,
                                                                            height:
                                                                                1.0,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Color(0xFFDCDCDC),
                                                                            ),
                                                                          ),
                                                                        ].divide(SizedBox(height: 26.0)).around(SizedBox(height: 26.0)),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          );
                                                        },
                                                      ),
                                                      StreamBuilder<
                                                          List<
                                                              LuckyDrawOfferRecord>>(
                                                        stream:
                                                            queryLuckyDrawOfferRecord(
                                                          queryBuilder:
                                                              (luckyDrawOfferRecord) =>
                                                                  luckyDrawOfferRecord
                                                                      .where(
                                                            'lukcyDraw_Offer_status',
                                                            isEqualTo:
                                                                'Expired',
                                                          ),
                                                        ),
                                                        builder: (context,
                                                            snapshot) {
                                                          // Customize what your widget looks like when it's loading.
                                                          if (!snapshot
                                                              .hasData) {
                                                            return Center(
                                                              child: SizedBox(
                                                                width: 60.0,
                                                                height: 60.0,
                                                                child:
                                                                    SpinKitRipple(
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  size: 60.0,
                                                                ),
                                                              ),
                                                            );
                                                          }
                                                          List<LuckyDrawOfferRecord>
                                                              listViewLuckyDrawOfferRecordList =
                                                              snapshot.data!;

                                                          return ListView
                                                              .builder(
                                                            padding:
                                                                EdgeInsets.zero,
                                                            scrollDirection:
                                                                Axis.vertical,
                                                            itemCount:
                                                                listViewLuckyDrawOfferRecordList
                                                                    .length,
                                                            itemBuilder: (context,
                                                                listViewIndex) {
                                                              final listViewLuckyDrawOfferRecord =
                                                                  listViewLuckyDrawOfferRecordList[
                                                                      listViewIndex];
                                                              return Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        20.0,
                                                                        0.0,
                                                                        20.0,
                                                                        0.0),
                                                                child:
                                                                    Container(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      1.0,
                                                                  decoration:
                                                                      BoxDecoration(),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .max,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceBetween,
                                                                        children: [
                                                                          Flexible(
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                                                              decoration: BoxDecoration(),
                                                                              child: Wrap(
                                                                                spacing: 20.0,
                                                                                runSpacing: 20.0,
                                                                                alignment: WrapAlignment.start,
                                                                                crossAxisAlignment: WrapCrossAlignment.start,
                                                                                direction: Axis.horizontal,
                                                                                runAlignment: WrapAlignment.start,
                                                                                verticalDirection: VerticalDirection.down,
                                                                                clipBehavior: Clip.none,
                                                                                children: [
                                                                                  Container(
                                                                                    width: 100.0,
                                                                                    height: 100.0,
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFFFFECD4),
                                                                                      image: DecorationImage(
                                                                                        fit: BoxFit.contain,
                                                                                        alignment: AlignmentDirectional(0.0, 0.0),
                                                                                        image: Image.network(
                                                                                          valueOrDefault<String>(
                                                                                            listViewLuckyDrawOfferRecord.lukcyDrawOfferImage,
                                                                                            'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                          ),
                                                                                        ).image,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(10.0),
                                                                                    ),
                                                                                  ),
                                                                                  Container(
                                                                                    width: 500.0,
                                                                                    decoration: BoxDecoration(),
                                                                                    child: Column(
                                                                                      mainAxisSize: MainAxisSize.max,
                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                      children: [
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                          child: Text(
                                                                                            listViewLuckyDrawOfferRecord.luckyDrawOffrName,
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Poppins',
                                                                                                  color: Color(0xFF464646),
                                                                                                  fontSize: () {
                                                                                                    if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                      return 20.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                      return 22.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                      return 23.0;
                                                                                                    } else {
                                                                                                      return 24.0;
                                                                                                    }
                                                                                                  }(),
                                                                                                  letterSpacing: 0.0,
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                        RichText(
                                                                                          textScaler: MediaQuery.of(context).textScaler,
                                                                                          text: TextSpan(
                                                                                            children: [
                                                                                              TextSpan(
                                                                                                text: 'Started on: ',
                                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                      fontFamily: 'Poppins',
                                                                                                      color: Color(0xFF7C7C7C),
                                                                                                      fontSize: () {
                                                                                                        if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                          return 14.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                          return 14.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                          return 15.0;
                                                                                                        } else {
                                                                                                          return 16.0;
                                                                                                        }
                                                                                                      }(),
                                                                                                      letterSpacing: 0.0,
                                                                                                      fontWeight: FontWeight.w500,
                                                                                                    ),
                                                                                              ),
                                                                                              TextSpan(
                                                                                                text: dateTimeFormat("d/M/y", listViewLuckyDrawOfferRecord.lukcyDrawOfferActivePeriod!),
                                                                                                style: GoogleFonts.getFont(
                                                                                                  'Poppins',
                                                                                                  color: Color(0xFFFF7622),
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                  fontSize: () {
                                                                                                    if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                      return 14.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                      return 14.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                      return 15.0;
                                                                                                    } else {
                                                                                                      return 16.0;
                                                                                                    }
                                                                                                  }(),
                                                                                                ),
                                                                                              )
                                                                                            ],
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Readex Pro',
                                                                                                  letterSpacing: 0.0,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                                                                                          child: RichText(
                                                                                            textScaler: MediaQuery.of(context).textScaler,
                                                                                            text: TextSpan(
                                                                                              children: [
                                                                                                TextSpan(
                                                                                                  text: 'Deal Ends: ',
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        fontFamily: 'Poppins',
                                                                                                        color: Color(0xFF7C7C7C),
                                                                                                        fontSize: () {
                                                                                                          if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                            return 15.0;
                                                                                                          } else {
                                                                                                            return 16.0;
                                                                                                          }
                                                                                                        }(),
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                      ),
                                                                                                ),
                                                                                                TextSpan(
                                                                                                  text: dateTimeFormat("d/M/y", listViewLuckyDrawOfferRecord.luckyDrawOfferEndPeriod!),
                                                                                                  style: GoogleFonts.getFont(
                                                                                                    'Poppins',
                                                                                                    color: Color(0xFFFF7622),
                                                                                                    fontWeight: FontWeight.w500,
                                                                                                    fontSize: () {
                                                                                                      if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                        return 15.0;
                                                                                                      } else {
                                                                                                        return 16.0;
                                                                                                      }
                                                                                                    }(),
                                                                                                  ),
                                                                                                )
                                                                                              ],
                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                    fontFamily: 'Readex Pro',
                                                                                                    letterSpacing: 0.0,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: AlignmentDirectional(1.0, 0.0),
                                                                                    child: Container(
                                                                                      decoration: BoxDecoration(),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                      Container(
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        height:
                                                                            1.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Color(0xFFDCDCDC),
                                                                        ),
                                                                      ),
                                                                    ]
                                                                        .divide(SizedBox(
                                                                            height:
                                                                                26.0))
                                                                        .around(SizedBox(
                                                                            height:
                                                                                26.0)),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          );
                                                        },
                                                      ),
                                                      StreamBuilder<
                                                          List<
                                                              LuckyDrawOfferRecord>>(
                                                        stream:
                                                            queryLuckyDrawOfferRecord(
                                                          queryBuilder:
                                                              (luckyDrawOfferRecord) =>
                                                                  luckyDrawOfferRecord
                                                                      .where(
                                                            'lukcyDraw_Offer_status',
                                                            isEqualTo: 'Draft',
                                                          ),
                                                        )..listen((snapshot) {
                                                                List<LuckyDrawOfferRecord>
                                                                    listViewLuckyDrawOfferRecordList =
                                                                    snapshot;
                                                                if (_model.listViewPreviousSnapshot !=
                                                                        null &&
                                                                    !const ListEquality(
                                                                            LuckyDrawOfferRecordDocumentEquality())
                                                                        .equals(
                                                                            listViewLuckyDrawOfferRecordList,
                                                                            _model.listViewPreviousSnapshot)) {
                                                                  () async {}();
                                                                }
                                                                _model.listViewPreviousSnapshot =
                                                                    snapshot;
                                                              }),
                                                        builder: (context,
                                                            snapshot) {
                                                          // Customize what your widget looks like when it's loading.
                                                          if (!snapshot
                                                              .hasData) {
                                                            return Center(
                                                              child: SizedBox(
                                                                width: 60.0,
                                                                height: 60.0,
                                                                child:
                                                                    SpinKitRipple(
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  size: 60.0,
                                                                ),
                                                              ),
                                                            );
                                                          }
                                                          List<LuckyDrawOfferRecord>
                                                              listViewLuckyDrawOfferRecordList =
                                                              snapshot.data!;

                                                          return ListView
                                                              .builder(
                                                            padding:
                                                                EdgeInsets.zero,
                                                            scrollDirection:
                                                                Axis.vertical,
                                                            itemCount:
                                                                listViewLuckyDrawOfferRecordList
                                                                    .length,
                                                            itemBuilder: (context,
                                                                listViewIndex) {
                                                              final listViewLuckyDrawOfferRecord =
                                                                  listViewLuckyDrawOfferRecordList[
                                                                      listViewIndex];
                                                              return Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        20.0,
                                                                        0.0,
                                                                        20.0,
                                                                        0.0),
                                                                child:
                                                                    Container(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      1.0,
                                                                  decoration:
                                                                      BoxDecoration(),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .max,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceBetween,
                                                                        children: [
                                                                          Flexible(
                                                                            child:
                                                                                Container(
                                                                              width: MediaQuery.sizeOf(context).width * 1.0,
                                                                              decoration: BoxDecoration(),
                                                                              child: Wrap(
                                                                                spacing: 20.0,
                                                                                runSpacing: 20.0,
                                                                                alignment: WrapAlignment.start,
                                                                                crossAxisAlignment: WrapCrossAlignment.start,
                                                                                direction: Axis.horizontal,
                                                                                runAlignment: WrapAlignment.start,
                                                                                verticalDirection: VerticalDirection.down,
                                                                                clipBehavior: Clip.none,
                                                                                children: [
                                                                                  Container(
                                                                                    width: 100.0,
                                                                                    height: 100.0,
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFFFFECD4),
                                                                                      image: DecorationImage(
                                                                                        fit: BoxFit.contain,
                                                                                        alignment: AlignmentDirectional(0.0, 0.0),
                                                                                        image: Image.network(
                                                                                          valueOrDefault<String>(
                                                                                            listViewLuckyDrawOfferRecord.lukcyDrawOfferImage,
                                                                                            'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                          ),
                                                                                        ).image,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(10.0),
                                                                                    ),
                                                                                  ),
                                                                                  Container(
                                                                                    width: 500.0,
                                                                                    decoration: BoxDecoration(),
                                                                                    child: Column(
                                                                                      mainAxisSize: MainAxisSize.min,
                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                      children: [
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
                                                                                          child: Text(
                                                                                            listViewLuckyDrawOfferRecord.luckyDrawOffrName,
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Poppins',
                                                                                                  color: Color(0xFF464646),
                                                                                                  fontSize: () {
                                                                                                    if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                      return 20.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                      return 22.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                      return 23.0;
                                                                                                    } else {
                                                                                                      return 24.0;
                                                                                                    }
                                                                                                  }(),
                                                                                                  letterSpacing: 0.0,
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                        RichText(
                                                                                          textScaler: MediaQuery.of(context).textScaler,
                                                                                          text: TextSpan(
                                                                                            children: [
                                                                                              TextSpan(
                                                                                                text: 'Start on: ',
                                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                      fontFamily: 'Poppins',
                                                                                                      color: Color(0xFF7C7C7C),
                                                                                                      fontSize: () {
                                                                                                        if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                          return 14.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                          return 14.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                          return 15.0;
                                                                                                        } else {
                                                                                                          return 16.0;
                                                                                                        }
                                                                                                      }(),
                                                                                                      letterSpacing: 0.0,
                                                                                                      fontWeight: FontWeight.w500,
                                                                                                    ),
                                                                                              ),
                                                                                              TextSpan(
                                                                                                text: dateTimeFormat("d/M/y", listViewLuckyDrawOfferRecord.lukcyDrawOfferActivePeriod!),
                                                                                                style: GoogleFonts.getFont(
                                                                                                  'Poppins',
                                                                                                  color: Color(0xFFFF7622),
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                  fontSize: () {
                                                                                                    if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                      return 14.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                      return 14.0;
                                                                                                    } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                      return 15.0;
                                                                                                    } else {
                                                                                                      return 16.0;
                                                                                                    }
                                                                                                  }(),
                                                                                                ),
                                                                                              )
                                                                                            ],
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Readex Pro',
                                                                                                  letterSpacing: 0.0,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                                                                                          child: RichText(
                                                                                            textScaler: MediaQuery.of(context).textScaler,
                                                                                            text: TextSpan(
                                                                                              children: [
                                                                                                TextSpan(
                                                                                                  text: 'Deal Ends: ',
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        fontFamily: 'Poppins',
                                                                                                        color: Color(0xFF7C7C7C),
                                                                                                        fontSize: () {
                                                                                                          if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                            return 15.0;
                                                                                                          } else {
                                                                                                            return 16.0;
                                                                                                          }
                                                                                                        }(),
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                      ),
                                                                                                ),
                                                                                                TextSpan(
                                                                                                  text: dateTimeFormat("d/M/y", listViewLuckyDrawOfferRecord.luckyDrawOfferEndPeriod!),
                                                                                                  style: GoogleFonts.getFont(
                                                                                                    'Poppins',
                                                                                                    color: Color(0xFFFF7622),
                                                                                                    fontWeight: FontWeight.w500,
                                                                                                    fontSize: () {
                                                                                                      if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                        return 14.0;
                                                                                                      } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                        return 15.0;
                                                                                                      } else {
                                                                                                        return 16.0;
                                                                                                      }
                                                                                                    }(),
                                                                                                  ),
                                                                                                )
                                                                                              ],
                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                    fontFamily: 'Readex Pro',
                                                                                                    letterSpacing: 0.0,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                  Container(
                                                                                    decoration: BoxDecoration(),
                                                                                    child: FFButtonWidget(
                                                                                      onPressed: (listViewLuckyDrawOfferRecord.lukcyDrawOfferStatus == 'Draft')
                                                                                          ? null
                                                                                          : () async {
                                                                                              await actions.updateLotteryOfferStatus();

                                                                                              await listViewLuckyDrawOfferRecord.reference.update({
                                                                                                ...mapToFirestore(
                                                                                                  {
                                                                                                    'luckyDraw_offer_participant_id': FieldValue.arrayUnion([
                                                                                                      lotteryListVendorDetailsRecord?.vendorId
                                                                                                    ]),
                                                                                                  },
                                                                                                ),
                                                                                              });

                                                                                              await lotteryListVendorDetailsRecord!.reference.update({
                                                                                                ...mapToFirestore(
                                                                                                  {
                                                                                                    'lot_partip_list': FieldValue.arrayUnion([
                                                                                                      listViewLuckyDrawOfferRecord.reference
                                                                                                    ]),
                                                                                                  },
                                                                                                ),
                                                                                              });

                                                                                              await LuckyDrawParticipantsRecord.collection.doc().set(createLuckyDrawParticipantsRecordData(
                                                                                                    lukcyDrawParticipantRef: lotteryListVendorDetailsRecord?.reference,
                                                                                                    lukcyDrawParticipantName: lotteryListVendorDetailsRecord?.businessName,
                                                                                                    lukcyDrawParticipantId: lotteryListVendorDetailsRecord?.vendorId,
                                                                                                    lukcyDrawPaticipatedDate: getCurrentTimestamp,
                                                                                                    lukcyDrawOfferName: listViewLuckyDrawOfferRecord.luckyDrawOffrName,
                                                                                                    lukcyDrawOfferId: listViewLuckyDrawOfferRecord.lukcyDrawOfferId,
                                                                                                    lukcyDrawOfferRef: listViewLuckyDrawOfferRecord.reference,
                                                                                                  ));

                                                                                              safeSetState(() {});
                                                                                            },
                                                                                      text: listViewLuckyDrawOfferRecord.luckyDrawOfferParticipantId.contains(lotteryListVendorDetailsRecord?.vendorId) ? 'Entered' : 'Enter Competition',
                                                                                      options: FFButtonOptions(
                                                                                        width: 250.0,
                                                                                        height: 40.0,
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                        color: Color(0xFFFF7622),
                                                                                        textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                              fontFamily: 'Readex Pro',
                                                                                              color: Colors.white,
                                                                                              fontSize: () {
                                                                                                if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                  return 14.0;
                                                                                                } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                  return 14.0;
                                                                                                } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                  return 15.0;
                                                                                                } else {
                                                                                                  return 16.0;
                                                                                                }
                                                                                              }(),
                                                                                              letterSpacing: 0.0,
                                                                                            ),
                                                                                        elevation: 0.0,
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        disabledColor: Color(0xFF9F9999),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                      Container(
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        height:
                                                                            1.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Color(0xFFDCDCDC),
                                                                        ),
                                                                      ),
                                                                    ]
                                                                        .divide(SizedBox(
                                                                            height:
                                                                                26.0))
                                                                        .around(SizedBox(
                                                                            height:
                                                                                26.0)),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          );
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ));
      },
    );
  }
}
