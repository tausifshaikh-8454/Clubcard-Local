import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/admin_drawer_widget.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'lottery_list_widget.dart' show LotteryListWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LotteryListModel extends FlutterFlowModel<LotteryListWidget> {
  ///  Local state fields for this page.

  String? refersh;

  ///  State fields for stateful widgets in this page.

  InstantTimer? instantTimer;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  // Model for adminDrawer component.
  late AdminDrawerModel adminDrawerModel1;
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  List<LuckyDrawOfferRecord>? listViewPreviousSnapshot;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;
  // Model for adminDrawer component.
  late AdminDrawerModel adminDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    adminDrawerModel1 = createModel(context, () => AdminDrawerModel());
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
    adminDrawerModel2 = createModel(context, () => AdminDrawerModel());
  }

  @override
  void dispose() {
    instantTimer?.cancel();
    vendDrawerModel1.dispose();
    adminDrawerModel1.dispose();
    tabBarController?.dispose();
    vendDrawerModel2.dispose();
    adminDrawerModel2.dispose();
  }
}
