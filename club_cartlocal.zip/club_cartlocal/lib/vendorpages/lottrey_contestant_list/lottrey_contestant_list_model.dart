import '/backend/backend.dart';
import '/components/admin_drawer_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'lottrey_contestant_list_widget.dart' show LottreyContestantListWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LottreyContestantListModel
    extends FlutterFlowModel<LottreyContestantListWidget> {
  ///  Local state fields for this page.

  String? refersh;

  ///  State fields for stateful widgets in this page.

  // Model for adminDrawer component.
  late AdminDrawerModel adminDrawerModel1;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // Model for adminDrawer component.
  late AdminDrawerModel adminDrawerModel2;

  @override
  void initState(BuildContext context) {
    adminDrawerModel1 = createModel(context, () => AdminDrawerModel());
    adminDrawerModel2 = createModel(context, () => AdminDrawerModel());
  }

  @override
  void dispose() {
    adminDrawerModel1.dispose();
    adminDrawerModel2.dispose();
  }
}
