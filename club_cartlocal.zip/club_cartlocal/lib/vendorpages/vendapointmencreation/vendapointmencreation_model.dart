import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'vendapointmencreation_widget.dart' show VendapointmencreationWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendapointmencreationModel
    extends FlutterFlowModel<VendapointmencreationWidget> {
  ///  Local state fields for this page.

  List<String> apponttagList = [];
  void addToApponttagList(String item) => apponttagList.add(item);
  void removeFromApponttagList(String item) => apponttagList.remove(item);
  void removeAtIndexFromApponttagList(int index) =>
      apponttagList.removeAt(index);
  void insertAtIndexInApponttagList(int index, String item) =>
      apponttagList.insert(index, item);
  void updateApponttagListAtIndex(int index, Function(String) updateFn) =>
      apponttagList[index] = updateFn(apponttagList[index]);

  List<DateTime> starttime = [];
  void addToStarttime(DateTime item) => starttime.add(item);
  void removeFromStarttime(DateTime item) => starttime.remove(item);
  void removeAtIndexFromStarttime(int index) => starttime.removeAt(index);
  void insertAtIndexInStarttime(int index, DateTime item) =>
      starttime.insert(index, item);
  void updateStarttimeAtIndex(int index, Function(DateTime) updateFn) =>
      starttime[index] = updateFn(starttime[index]);

  List<DateTime> endtime = [];
  void addToEndtime(DateTime item) => endtime.add(item);
  void removeFromEndtime(DateTime item) => endtime.remove(item);
  void removeAtIndexFromEndtime(int index) => endtime.removeAt(index);
  void insertAtIndexInEndtime(int index, DateTime item) =>
      endtime.insert(index, item);
  void updateEndtimeAtIndex(int index, Function(DateTime) updateFn) =>
      endtime[index] = updateFn(endtime[index]);

  List<int> timeslotCount = [0];
  void addToTimeslotCount(int item) => timeslotCount.add(item);
  void removeFromTimeslotCount(int item) => timeslotCount.remove(item);
  void removeAtIndexFromTimeslotCount(int index) =>
      timeslotCount.removeAt(index);
  void insertAtIndexInTimeslotCount(int index, int item) =>
      timeslotCount.insert(index, item);
  void updateTimeslotCountAtIndex(int index, Function(int) updateFn) =>
      timeslotCount[index] = updateFn(timeslotCount[index]);

  ///  State fields for stateful widgets in this page.

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for servicename widget.
  FocusNode? servicenameFocusNode;
  TextEditingController? servicenameTextController;
  String? Function(BuildContext, String?)? servicenameTextControllerValidator;
  DateTime? datePicked1;
  DateTime? datePicked2;
  DateTime? datePicked3;
  // State field(s) for serv_RegularPrice widget.
  FocusNode? servRegularPriceFocusNode;
  TextEditingController? servRegularPriceTextController;
  String? Function(BuildContext, String?)?
      servRegularPriceTextControllerValidator;
  // State field(s) for serv_saleprice widget.
  FocusNode? servSalepriceFocusNode;
  TextEditingController? servSalepriceTextController;
  String? Function(BuildContext, String?)? servSalepriceTextControllerValidator;
  // State field(s) for serv_tags widget.
  FocusNode? servTagsFocusNode;
  TextEditingController? servTagsTextController;
  String? Function(BuildContext, String?)? servTagsTextControllerValidator;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for serv_deascr widget.
  FocusNode? servDeascrFocusNode;
  TextEditingController? servDeascrTextController;
  String? Function(BuildContext, String?)? servDeascrTextControllerValidator;

  @override
  void initState(BuildContext context) {
    vendDrawerModel = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel.dispose();
    servicenameFocusNode?.dispose();
    servicenameTextController?.dispose();

    servRegularPriceFocusNode?.dispose();
    servRegularPriceTextController?.dispose();

    servSalepriceFocusNode?.dispose();
    servSalepriceTextController?.dispose();

    servTagsFocusNode?.dispose();
    servTagsTextController?.dispose();

    servDeascrFocusNode?.dispose();
    servDeascrTextController?.dispose();
  }
}
