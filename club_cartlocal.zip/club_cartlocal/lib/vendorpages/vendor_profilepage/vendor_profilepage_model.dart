import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'vendor_profilepage_widget.dart' show VendorProfilepageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendorProfilepageModel extends FlutterFlowModel<VendorProfilepageWidget> {
  ///  Local state fields for this page.

  String? vendRestPass;

  ///  State fields for stateful widgets in this page.

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for BusinessownerName widget.
  FocusNode? businessownerNameFocusNode;
  TextEditingController? businessownerNameTextController;
  String? Function(BuildContext, String?)?
      businessownerNameTextControllerValidator;
  // State field(s) for BusinessownerPhone widget.
  FocusNode? businessownerPhoneFocusNode;
  TextEditingController? businessownerPhoneTextController;
  String? Function(BuildContext, String?)?
      businessownerPhoneTextControllerValidator;
  // State field(s) for Password widget.
  FocusNode? passwordFocusNode;
  TextEditingController? passwordTextController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? passwordTextControllerValidator;
  // State field(s) for ConfirmPassword widget.
  FocusNode? confirmPasswordFocusNode;
  TextEditingController? confirmPasswordTextController;
  late bool confirmPasswordVisibility;
  String? Function(BuildContext, String?)?
      confirmPasswordTextControllerValidator;
  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl1 = '';

  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  // State field(s) for Businessname widget.
  FocusNode? businessnameFocusNode;
  TextEditingController? businessnameTextController;
  String? Function(BuildContext, String?)? businessnameTextControllerValidator;
  // State field(s) for CompanyHouseNo widget.
  FocusNode? companyHouseNoFocusNode;
  TextEditingController? companyHouseNoTextController;
  String? Function(BuildContext, String?)?
      companyHouseNoTextControllerValidator;
  // State field(s) for CompanyVatNo widget.
  FocusNode? companyVatNoFocusNode;
  TextEditingController? companyVatNoTextController;
  String? Function(BuildContext, String?)? companyVatNoTextControllerValidator;
  // State field(s) for BusinessEmail widget.
  FocusNode? businessEmailFocusNode;
  TextEditingController? businessEmailTextController;
  String? Function(BuildContext, String?)? businessEmailTextControllerValidator;
  // State field(s) for BusinessTelephone widget.
  FocusNode? businessTelephoneFocusNode;
  TextEditingController? businessTelephoneTextController;
  String? Function(BuildContext, String?)?
      businessTelephoneTextControllerValidator;
  // State field(s) for BusinessMobile widget.
  FocusNode? businessMobileFocusNode;
  TextEditingController? businessMobileTextController;
  String? Function(BuildContext, String?)?
      businessMobileTextControllerValidator;
  // State field(s) for Businessstreet widget.
  FocusNode? businessstreetFocusNode;
  TextEditingController? businessstreetTextController;
  String? Function(BuildContext, String?)?
      businessstreetTextControllerValidator;
  // State field(s) for BusinessBelongingcity widget.
  FocusNode? businessBelongingcityFocusNode;
  TextEditingController? businessBelongingcityTextController;
  String? Function(BuildContext, String?)?
      businessBelongingcityTextControllerValidator;
  // State field(s) for Businesscountry widget.
  FocusNode? businesscountryFocusNode;
  TextEditingController? businesscountryTextController;
  String? Function(BuildContext, String?)?
      businesscountryTextControllerValidator;
  // State field(s) for BusinessAddress widget.
  FocusNode? businessAddressFocusNode;
  TextEditingController? businessAddressTextController;
  String? Function(BuildContext, String?)?
      businessAddressTextControllerValidator;
  // State field(s) for Businesszipcode widget.
  FocusNode? businesszipcodeFocusNode;
  TextEditingController? businesszipcodeTextController;
  String? Function(BuildContext, String?)?
      businesszipcodeTextControllerValidator;
  // State field(s) for BusinessWebsite widget.
  FocusNode? businessWebsiteFocusNode;
  TextEditingController? businessWebsiteTextController;
  String? Function(BuildContext, String?)?
      businessWebsiteTextControllerValidator;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    passwordVisibility = false;
    confirmPasswordVisibility = false;
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel1.dispose();
    tabBarController?.dispose();
    businessownerNameFocusNode?.dispose();
    businessownerNameTextController?.dispose();

    businessownerPhoneFocusNode?.dispose();
    businessownerPhoneTextController?.dispose();

    passwordFocusNode?.dispose();
    passwordTextController?.dispose();

    confirmPasswordFocusNode?.dispose();
    confirmPasswordTextController?.dispose();

    businessnameFocusNode?.dispose();
    businessnameTextController?.dispose();

    companyHouseNoFocusNode?.dispose();
    companyHouseNoTextController?.dispose();

    companyVatNoFocusNode?.dispose();
    companyVatNoTextController?.dispose();

    businessEmailFocusNode?.dispose();
    businessEmailTextController?.dispose();

    businessTelephoneFocusNode?.dispose();
    businessTelephoneTextController?.dispose();

    businessMobileFocusNode?.dispose();
    businessMobileTextController?.dispose();

    businessstreetFocusNode?.dispose();
    businessstreetTextController?.dispose();

    businessBelongingcityFocusNode?.dispose();
    businessBelongingcityTextController?.dispose();

    businesscountryFocusNode?.dispose();
    businesscountryTextController?.dispose();

    businessAddressFocusNode?.dispose();
    businessAddressTextController?.dispose();

    businesszipcodeFocusNode?.dispose();
    businesszipcodeTextController?.dispose();

    businessWebsiteFocusNode?.dispose();
    businessWebsiteTextController?.dispose();

    vendDrawerModel2.dispose();
  }
}
