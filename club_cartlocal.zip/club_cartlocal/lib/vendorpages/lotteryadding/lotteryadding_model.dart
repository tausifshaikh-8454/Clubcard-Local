import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/admin_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'lotteryadding_widget.dart' show LotteryaddingWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LotteryaddingModel extends FlutterFlowModel<LotteryaddingWidget> {
  ///  Local state fields for this page.

  List<String> tagList = [];
  void addToTagList(String item) => tagList.add(item);
  void removeFromTagList(String item) => tagList.remove(item);
  void removeAtIndexFromTagList(int index) => tagList.removeAt(index);
  void insertAtIndexInTagList(int index, String item) =>
      tagList.insert(index, item);
  void updateTagListAtIndex(int index, Function(String) updateFn) =>
      tagList[index] = updateFn(tagList[index]);

  List<DocumentReference> user = [];
  void addToUser(DocumentReference item) => user.add(item);
  void removeFromUser(DocumentReference item) => user.remove(item);
  void removeAtIndexFromUser(int index) => user.removeAt(index);
  void insertAtIndexInUser(int index, DocumentReference item) =>
      user.insert(index, item);
  void updateUserAtIndex(int index, Function(DocumentReference) updateFn) =>
      user[index] = updateFn(user[index]);

  List<DateTime> startTime = [];
  void addToStartTime(DateTime item) => startTime.add(item);
  void removeFromStartTime(DateTime item) => startTime.remove(item);
  void removeAtIndexFromStartTime(int index) => startTime.removeAt(index);
  void insertAtIndexInStartTime(int index, DateTime item) =>
      startTime.insert(index, item);
  void updateStartTimeAtIndex(int index, Function(DateTime) updateFn) =>
      startTime[index] = updateFn(startTime[index]);

  List<DateTime> endTime = [];
  void addToEndTime(DateTime item) => endTime.add(item);
  void removeFromEndTime(DateTime item) => endTime.remove(item);
  void removeAtIndexFromEndTime(int index) => endTime.removeAt(index);
  void insertAtIndexInEndTime(int index, DateTime item) =>
      endTime.insert(index, item);
  void updateEndTimeAtIndex(int index, Function(DateTime) updateFn) =>
      endTime[index] = updateFn(endTime[index]);

  List<int> timeslotCount = [0];
  void addToTimeslotCount(int item) => timeslotCount.add(item);
  void removeFromTimeslotCount(int item) => timeslotCount.remove(item);
  void removeAtIndexFromTimeslotCount(int index) =>
      timeslotCount.removeAt(index);
  void insertAtIndexInTimeslotCount(int index, int item) =>
      timeslotCount.insert(index, item);
  void updateTimeslotCountAtIndex(int index, Function(int) updateFn) =>
      timeslotCount[index] = updateFn(timeslotCount[index]);

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // Model for adminDrawer component.
  late AdminDrawerModel adminDrawerModel1;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for luckDraw_name widget.
  FocusNode? luckDrawNameFocusNode;
  TextEditingController? luckDrawNameTextController;
  String? Function(BuildContext, String?)? luckDrawNameTextControllerValidator;
  String? _luckDrawNameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Name Of Product is required';
    }

    return null;
  }

  DateTime? datePicked1;
  DateTime? datePicked2;
  // State field(s) for Prod_RegularPrice widget.
  FocusNode? prodRegularPriceFocusNode;
  TextEditingController? prodRegularPriceTextController;
  String? Function(BuildContext, String?)?
      prodRegularPriceTextControllerValidator;
  // State field(s) for prod_saleprice widget.
  FocusNode? prodSalepriceFocusNode;
  TextEditingController? prodSalepriceTextController;
  String? Function(BuildContext, String?)? prodSalepriceTextControllerValidator;
  // State field(s) for luckDraw_Desc widget.
  FocusNode? luckDrawDescFocusNode;
  TextEditingController? luckDrawDescTextController;
  String? Function(BuildContext, String?)? luckDrawDescTextControllerValidator;
  String? _luckDrawDescTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Description is required';
    }

    return null;
  }

  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  LuckyDrawOfferRecord? lotOffer;
  // State field(s) for luckyDraw_id widget.
  FocusNode? luckyDrawIdFocusNode;
  TextEditingController? luckyDrawIdTextController;
  String? Function(BuildContext, String?)? luckyDrawIdTextControllerValidator;
  // Model for adminDrawer component.
  late AdminDrawerModel adminDrawerModel2;

  @override
  void initState(BuildContext context) {
    adminDrawerModel1 = createModel(context, () => AdminDrawerModel());
    luckDrawNameTextControllerValidator = _luckDrawNameTextControllerValidator;
    luckDrawDescTextControllerValidator = _luckDrawDescTextControllerValidator;
    adminDrawerModel2 = createModel(context, () => AdminDrawerModel());
  }

  @override
  void dispose() {
    adminDrawerModel1.dispose();
    luckDrawNameFocusNode?.dispose();
    luckDrawNameTextController?.dispose();

    prodRegularPriceFocusNode?.dispose();
    prodRegularPriceTextController?.dispose();

    prodSalepriceFocusNode?.dispose();
    prodSalepriceTextController?.dispose();

    luckDrawDescFocusNode?.dispose();
    luckDrawDescTextController?.dispose();

    luckyDrawIdFocusNode?.dispose();
    luckyDrawIdTextController?.dispose();

    adminDrawerModel2.dispose();
  }
}
