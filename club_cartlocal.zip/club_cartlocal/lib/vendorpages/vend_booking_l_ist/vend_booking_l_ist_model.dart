import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/bookingstatus_widget.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'vend_booking_l_ist_widget.dart' show VendBookingLIstWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendBookingLIstModel extends FlutterFlowModel<VendBookingLIstWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  DateTime? datePicked;
  // Models for bookingstatus dynamic component.
  late FlutterFlowDynamicModels<BookingstatusModel> bookingstatusModels;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    bookingstatusModels = FlutterFlowDynamicModels(() => BookingstatusModel());
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel1.dispose();
    bookingstatusModels.dispose();
    vendDrawerModel2.dispose();
  }
}
