import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/bookingstatus_widget.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'vend_booking_l_ist_model.dart';
export 'vend_booking_l_ist_model.dart';

class VendBookingLIstWidget extends StatefulWidget {
  const VendBookingLIstWidget({super.key});

  static String routeName = 'VendBookingLIst';
  static String routePath = '/VendBookingLIst';

  @override
  State<VendBookingLIstWidget> createState() => _VendBookingLIstWidgetState();
}

class _VendBookingLIstWidgetState extends State<VendBookingLIstWidget> {
  late VendBookingLIstModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VendBookingLIstModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<VendorDetailsRecord>>(
      stream: queryVendorDetailsRecord(
        queryBuilder: (vendorDetailsRecord) => vendorDetailsRecord.where(
          'vendor_email',
          isEqualTo: currentUserEmail,
        ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Color(0xFFF5F7FB),
            body: Center(
              child: SizedBox(
                width: 60.0,
                height: 60.0,
                child: SpinKitRipple(
                  color: Color(0xFFFF7622),
                  size: 60.0,
                ),
              ),
            ),
          );
        }
        List<VendorDetailsRecord> vendBookingLIstVendorDetailsRecordList =
            snapshot.data!;
        // Return an empty Container when the item does not exist.
        if (snapshot.data!.isEmpty) {
          return Container();
        }
        final vendBookingLIstVendorDetailsRecord =
            vendBookingLIstVendorDetailsRecordList.isNotEmpty
                ? vendBookingLIstVendorDetailsRecordList.first
                : null;

        return Title(
            title: 'VendBookingLIst',
            color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
            child: GestureDetector(
              onTap: () {
                FocusScope.of(context).unfocus();
                FocusManager.instance.primaryFocus?.unfocus();
              },
              child: Scaffold(
                key: scaffoldKey,
                backgroundColor: Color(0xFFF5F7FB),
                drawer: Container(
                  width: MediaQuery.sizeOf(context).width * 0.9,
                  child: Drawer(
                    elevation: 16.0,
                    child: wrapWithModel(
                      model: _model.vendDrawerModel2,
                      updateCallback: () => safeSetState(() {}),
                      child: VendDrawerWidget(
                        parameter1: vendBookingLIstVendorDetailsRecord
                            ?.businessProfileLogo,
                        parameter2:
                            vendBookingLIstVendorDetailsRecord?.vendorUsername,
                        parameter3:
                            vendBookingLIstVendorDetailsRecord?.vendorId,
                        parameter4:
                            vendBookingLIstVendorDetailsRecord?.reference,
                      ),
                    ),
                  ),
                ),
                body: SafeArea(
                  top: true,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (responsiveVisibility(
                        context: context,
                        phone: false,
                        tablet: false,
                        tabletLandscape: false,
                      ))
                        Container(
                          width: MediaQuery.sizeOf(context).width * 0.2,
                          decoration: BoxDecoration(),
                          child: wrapWithModel(
                            model: _model.vendDrawerModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: VendDrawerWidget(
                              parameter1: vendBookingLIstVendorDetailsRecord
                                  ?.businessProfileLogo,
                              parameter2: vendBookingLIstVendorDetailsRecord
                                  ?.businessName,
                              parameter3:
                                  vendBookingLIstVendorDetailsRecord?.vendorId,
                              parameter4:
                                  vendBookingLIstVendorDetailsRecord?.reference,
                            ),
                          ),
                        ),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 0.0, 16.0, 0.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 16.0,
                                  color: Color(0x0E000000),
                                  offset: Offset(
                                    4.0,
                                    4.0,
                                  ),
                                )
                              ],
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(10.0),
                                bottomRight: Radius.circular(10.0),
                                topLeft: Radius.circular(10.0),
                                topRight: Radius.circular(10.0),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 0.0, 20.0),
                                        child: Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  1.0,
                                          height: 80.0,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            boxShadow: [
                                              BoxShadow(
                                                blurRadius: 4.0,
                                                color: Color(0x33000000),
                                                offset: Offset(
                                                  0.0,
                                                  4.0,
                                                ),
                                              )
                                            ],
                                            borderRadius: BorderRadius.only(
                                              bottomLeft: Radius.circular(0.0),
                                              bottomRight: Radius.circular(0.0),
                                              topLeft: Radius.circular(10.0),
                                              topRight: Radius.circular(10.0),
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        20.0, 0.0, 0.0, 0.0),
                                                child: Text(
                                                  'Appointments',
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            Color(0xFF656565),
                                                        fontSize: 26.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                ),
                                              ),
                                              if (responsiveVisibility(
                                                context: context,
                                                desktop: false,
                                              ))
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 20.0, 0.0),
                                                  child: InkWell(
                                                    splashColor:
                                                        Colors.transparent,
                                                    focusColor:
                                                        Colors.transparent,
                                                    hoverColor:
                                                        Colors.transparent,
                                                    highlightColor:
                                                        Colors.transparent,
                                                    onTap: () async {
                                                      scaffoldKey.currentState!
                                                          .openDrawer();
                                                    },
                                                    child: Icon(
                                                      Icons.menu_rounded,
                                                      color: Color(0xFFFF7622),
                                                      size: 30.0,
                                                    ),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            20.0, 0.0, 20.0, 20.0),
                                        child: Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.9,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                          ),
                                          child: Align(
                                            alignment:
                                                AlignmentDirectional(1.0, 0.0),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 20.0, 0.0),
                                                  child: FlutterFlowDropDown<
                                                      String>(
                                                    controller: _model
                                                            .dropDownValueController ??=
                                                        FormFieldController<
                                                            String>(null),
                                                    options: [
                                                      'Schedule',
                                                      'Completed',
                                                      'Not Attended',
                                                      'Canceled'
                                                    ],
                                                    onChanged: (val) =>
                                                        safeSetState(() => _model
                                                                .dropDownValue =
                                                            val),
                                                    width: 200.0,
                                                    height: 40.0,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Sen',
                                                          color:
                                                              Color(0xFF7C7C7C),
                                                          letterSpacing: 0.0,
                                                        ),
                                                    hintText:
                                                        'Filter With options',
                                                    icon: Icon(
                                                      Icons
                                                          .keyboard_arrow_down_rounded,
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondaryText,
                                                      size: 24.0,
                                                    ),
                                                    fillColor: Colors.white,
                                                    elevation: 2.0,
                                                    borderColor:
                                                        Color(0xFFDCDCDC),
                                                    borderWidth: 1.0,
                                                    borderRadius: 8.0,
                                                    margin:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(12.0, 0.0,
                                                                12.0, 0.0),
                                                    hidesUnderline: true,
                                                    isOverButton: false,
                                                    isSearchable: false,
                                                    isMultiSelect: false,
                                                  ),
                                                ),
                                                FFButtonWidget(
                                                  onPressed: () async {
                                                    final _datePickedDate =
                                                        await showDatePicker(
                                                      context: context,
                                                      initialDate:
                                                          getCurrentTimestamp,
                                                      firstDate: DateTime(1900),
                                                      lastDate: DateTime(2050),
                                                      builder:
                                                          (context, child) {
                                                        return wrapInMaterialDatePickerTheme(
                                                          context,
                                                          child!,
                                                          headerBackgroundColor:
                                                              Color(0xFFFF7622),
                                                          headerForegroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .info,
                                                          headerTextStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineLarge
                                                                  .override(
                                                                    fontFamily:
                                                                        'Outfit',
                                                                    fontSize:
                                                                        32.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                          pickerBackgroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .secondaryBackground,
                                                          pickerForegroundColor:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .primaryText,
                                                          selectedDateTimeBackgroundColor:
                                                              Color(0xFFFF7622),
                                                          selectedDateTimeForegroundColor:
                                                              Colors.white,
                                                          actionButtonForegroundColor:
                                                              Colors.white,
                                                          iconSize: 29.0,
                                                        );
                                                      },
                                                    );

                                                    if (_datePickedDate !=
                                                        null) {
                                                      safeSetState(() {
                                                        _model.datePicked =
                                                            DateTime(
                                                          _datePickedDate.year,
                                                          _datePickedDate.month,
                                                          _datePickedDate.day,
                                                        );
                                                      });
                                                    } else if (_model
                                                            .datePicked !=
                                                        null) {
                                                      safeSetState(() {
                                                        _model.datePicked =
                                                            getCurrentTimestamp;
                                                      });
                                                    }
                                                  },
                                                  text: 'Date',
                                                  icon: Icon(
                                                    Icons.edit_calendar,
                                                    color: Color(0xFFFF7622),
                                                    size: 25.0,
                                                  ),
                                                  options: FFButtonOptions(
                                                    width: 100.0,
                                                    height: 40.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(16.0, 0.0,
                                                                16.0, 0.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: Colors.white,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          fontFamily: 'Sen',
                                                          color:
                                                              Color(0xFF7C7C7C),
                                                          letterSpacing: 0.0,
                                                        ),
                                                    elevation: 0.0,
                                                    borderSide: BorderSide(
                                                      color: Color(0xFFDCDCDC),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  20.0, 0.0, 20.0, 0.0),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.only(
                                                bottomLeft:
                                                    Radius.circular(10.0),
                                                bottomRight:
                                                    Radius.circular(10.0),
                                                topLeft: Radius.circular(0.0),
                                                topRight: Radius.circular(0.0),
                                              ),
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Expanded(
                                                  child: StreamBuilder<
                                                      List<BookingsRecord>>(
                                                    stream: queryBookingsRecord(
                                                      queryBuilder:
                                                          (bookingsRecord) =>
                                                              bookingsRecord
                                                                  .where(
                                                                    'appointmentOwnerref',
                                                                    isEqualTo:
                                                                        vendBookingLIstVendorDetailsRecord
                                                                            ?.reference,
                                                                  )
                                                                  .where(
                                                                    'BookingStatus',
                                                                    isEqualTo: valueOrDefault<
                                                                                String>(
                                                                              _model.dropDownValue,
                                                                              'Schedule',
                                                                            ) !=
                                                                            ''
                                                                        ? valueOrDefault<
                                                                            String>(
                                                                            _model.dropDownValue,
                                                                            'Schedule',
                                                                          )
                                                                        : null,
                                                                  )
                                                                  .where(
                                                                    'bookingSlotDateStr',
                                                                    isEqualTo: dateTimeFormat("d/M/y", _model.datePicked) !=
                                                                            ''
                                                                        ? dateTimeFormat(
                                                                            "d/M/y",
                                                                            _model.datePicked)
                                                                        : null,
                                                                  ),
                                                    ),
                                                    builder:
                                                        (context, snapshot) {
                                                      // Customize what your widget looks like when it's loading.
                                                      if (!snapshot.hasData) {
                                                        return Center(
                                                          child: SizedBox(
                                                            width: 60.0,
                                                            height: 60.0,
                                                            child:
                                                                SpinKitRipple(
                                                              color: Color(
                                                                  0xFFFF7622),
                                                              size: 60.0,
                                                            ),
                                                          ),
                                                        );
                                                      }
                                                      List<BookingsRecord>
                                                          listViewBookingsRecordList =
                                                          snapshot.data!;

                                                      return ListView.builder(
                                                        padding:
                                                            EdgeInsets.zero,
                                                        scrollDirection:
                                                            Axis.vertical,
                                                        itemCount:
                                                            listViewBookingsRecordList
                                                                .length,
                                                        itemBuilder: (context,
                                                            listViewIndex) {
                                                          final listViewBookingsRecord =
                                                              listViewBookingsRecordList[
                                                                  listViewIndex];
                                                          return StreamBuilder<
                                                              OffersCollectionRecord>(
                                                            stream: OffersCollectionRecord
                                                                .getDocument(
                                                                    listViewBookingsRecord
                                                                        .appointrefOffer!),
                                                            builder: (context,
                                                                snapshot) {
                                                              // Customize what your widget looks like when it's loading.
                                                              if (!snapshot
                                                                  .hasData) {
                                                                return Center(
                                                                  child:
                                                                      SizedBox(
                                                                    width: 60.0,
                                                                    height:
                                                                        60.0,
                                                                    child:
                                                                        SpinKitRipple(
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      size:
                                                                          60.0,
                                                                    ),
                                                                  ),
                                                                );
                                                              }

                                                              final containerOffersCollectionRecord =
                                                                  snapshot
                                                                      .data!;

                                                              return Container(
                                                                width: MediaQuery.sizeOf(
                                                                            context)
                                                                        .width *
                                                                    1.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  children: [
                                                                    Container(
                                                                      width: MediaQuery.sizeOf(context)
                                                                              .width *
                                                                          1.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      child:
                                                                          Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            20.0,
                                                                            16.0,
                                                                            20.0,
                                                                            16.0),
                                                                        child:
                                                                            Wrap(
                                                                          spacing:
                                                                              0.0,
                                                                          runSpacing:
                                                                              30.0,
                                                                          alignment:
                                                                              WrapAlignment.spaceBetween,
                                                                          crossAxisAlignment:
                                                                              WrapCrossAlignment.center,
                                                                          direction:
                                                                              Axis.horizontal,
                                                                          runAlignment:
                                                                              WrapAlignment.start,
                                                                          verticalDirection:
                                                                              VerticalDirection.down,
                                                                          clipBehavior:
                                                                              Clip.none,
                                                                          children: [
                                                                            Container(
                                                                              decoration: BoxDecoration(),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.min,
                                                                                children: [
                                                                                  Flexible(
                                                                                    child: Container(
                                                                                      width: 100.0,
                                                                                      height: 100.0,
                                                                                      decoration: BoxDecoration(
                                                                                        color: Color(0xFFFFECD4),
                                                                                        image: DecorationImage(
                                                                                          fit: BoxFit.contain,
                                                                                          alignment: AlignmentDirectional(0.0, 0.0),
                                                                                          image: Image.network(
                                                                                            valueOrDefault<String>(
                                                                                              containerOffersCollectionRecord.offrImage,
                                                                                              'https://firebasestorage.googleapis.com/v0/b/clubcartlocal.appspot.com/o/users%2Fplaceholder.png?alt=media&token=43b0e40f-4087-4939-9330-38ca40b00894',
                                                                                            ),
                                                                                          ).image,
                                                                                        ),
                                                                                        borderRadius: BorderRadius.circular(10.0),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Flexible(
                                                                                    child: Padding(
                                                                                      padding: EdgeInsetsDirectional.fromSTEB(26.0, 0.0, 0.0, 0.0),
                                                                                      child: Container(
                                                                                        decoration: BoxDecoration(),
                                                                                        child: Column(
                                                                                          mainAxisSize: MainAxisSize.min,
                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                          children: [
                                                                                            Padding(
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 6.0),
                                                                                              child: Text(
                                                                                                containerOffersCollectionRecord.offerTitle,
                                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                      fontFamily: 'Poppins',
                                                                                                      color: Color(0xFF464646),
                                                                                                      fontSize: () {
                                                                                                        if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                          return 22.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                          return 22.0;
                                                                                                        } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                          return 23.0;
                                                                                                        } else {
                                                                                                          return 24.0;
                                                                                                        }
                                                                                                      }(),
                                                                                                      letterSpacing: 0.0,
                                                                                                      fontWeight: FontWeight.w500,
                                                                                                    ),
                                                                                              ),
                                                                                            ),
                                                                                            Padding(
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                                                                                              child: RichText(
                                                                                                textScaler: MediaQuery.of(context).textScaler,
                                                                                                text: TextSpan(
                                                                                                  children: [
                                                                                                    TextSpan(
                                                                                                      text: 'Booked By ',
                                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                            fontFamily: 'Poppins',
                                                                                                            color: Color(0xFF7C7C7C),
                                                                                                            fontSize: () {
                                                                                                              if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                                return 14.0;
                                                                                                              } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                                return 14.0;
                                                                                                              } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                                return 14.0;
                                                                                                              } else {
                                                                                                                return 16.0;
                                                                                                              }
                                                                                                            }(),
                                                                                                            letterSpacing: 0.0,
                                                                                                            fontWeight: FontWeight.w500,
                                                                                                          ),
                                                                                                    ),
                                                                                                    TextSpan(
                                                                                                      text: listViewBookingsRecord.appointeeName,
                                                                                                      style: GoogleFonts.getFont(
                                                                                                        'Poppins',
                                                                                                        color: Color(0xFFFF7622),
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                        fontSize: () {
                                                                                                          if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                            return 14.0;
                                                                                                          } else {
                                                                                                            return 16.0;
                                                                                                          }
                                                                                                        }(),
                                                                                                      ),
                                                                                                    ),
                                                                                                    TextSpan(
                                                                                                      text: ' for ',
                                                                                                      style: GoogleFonts.getFont(
                                                                                                        'Poppins',
                                                                                                        color: Color(0xFF7C7C7C),
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                        fontSize: () {
                                                                                                          if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                            return 14.0;
                                                                                                          } else {
                                                                                                            return 16.0;
                                                                                                          }
                                                                                                        }(),
                                                                                                      ),
                                                                                                    ),
                                                                                                    TextSpan(
                                                                                                      text: listViewBookingsRecord.bookingSlotDateStr,
                                                                                                      style: GoogleFonts.getFont(
                                                                                                        'Poppins',
                                                                                                        color: Color(0xFFFF7622),
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                        fontSize: () {
                                                                                                          if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                            return 14.0;
                                                                                                          } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                            return 14.0;
                                                                                                          } else {
                                                                                                            return 16.0;
                                                                                                          }
                                                                                                        }(),
                                                                                                      ),
                                                                                                    )
                                                                                                  ],
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        fontFamily: 'Readex Pro',
                                                                                                        letterSpacing: 0.0,
                                                                                                      ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                            Padding(
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                                                                                              child: Row(
                                                                                                mainAxisSize: MainAxisSize.min,
                                                                                                children: [
                                                                                                  Padding(
                                                                                                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 10.0, 0.0),
                                                                                                    child: FaIcon(
                                                                                                      FontAwesomeIcons.clock,
                                                                                                      color: Color(0xFFFF7622),
                                                                                                      size: 22.0,
                                                                                                    ),
                                                                                                  ),
                                                                                                  Text(
                                                                                                    listViewBookingsRecord.bookTimeSlot,
                                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                          fontFamily: 'Poppins',
                                                                                                          color: Color(0xFF7C7C7C),
                                                                                                          fontSize: () {
                                                                                                            if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                                                                                                              return 14.0;
                                                                                                            } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                                                                                                              return 14.0;
                                                                                                            } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                                                                                                              return 14.0;
                                                                                                            } else {
                                                                                                              return 16.0;
                                                                                                            }
                                                                                                          }(),
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w500,
                                                                                                        ),
                                                                                                  ),
                                                                                                ],
                                                                                              ),
                                                                                            ),
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            if (listViewBookingsRecord.bookingStatus ==
                                                                                'Schedule')
                                                                              Container(
                                                                                decoration: BoxDecoration(),
                                                                                child: Row(
                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                  children: [
                                                                                    Container(
                                                                                      height: 50.0,
                                                                                      decoration: BoxDecoration(
                                                                                        color: Colors.white,
                                                                                      ),
                                                                                      child: wrapWithModel(
                                                                                        model: _model.bookingstatusModels.getModel(
                                                                                          listViewBookingsRecord.reference.id,
                                                                                          listViewIndex,
                                                                                        ),
                                                                                        updateCallback: () => safeSetState(() {}),
                                                                                        updateOnChange: true,
                                                                                        child: BookingstatusWidget(
                                                                                          key: Key(
                                                                                            'Keywx9_${listViewBookingsRecord.reference.id}',
                                                                                          ),
                                                                                          parameter1: listViewBookingsRecord.reference,
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                    StreamBuilder<List<ServiceSlotsRecord>>(
                                                                                      stream: queryServiceSlotsRecord(
                                                                                        queryBuilder: (serviceSlotsRecord) => serviceSlotsRecord
                                                                                            .where(
                                                                                              'vend_ref',
                                                                                              isEqualTo: vendBookingLIstVendorDetailsRecord?.reference,
                                                                                            )
                                                                                            .where(
                                                                                              'offerref',
                                                                                              isEqualTo: containerOffersCollectionRecord.reference,
                                                                                            )
                                                                                            .where(
                                                                                              'timeSlots',
                                                                                              isEqualTo: listViewBookingsRecord.bookTimeSlot,
                                                                                            ),
                                                                                        singleRecord: true,
                                                                                      ),
                                                                                      builder: (context, snapshot) {
                                                                                        // Customize what your widget looks like when it's loading.
                                                                                        if (!snapshot.hasData) {
                                                                                          return Center(
                                                                                            child: SizedBox(
                                                                                              width: 60.0,
                                                                                              height: 60.0,
                                                                                              child: SpinKitRipple(
                                                                                                color: Color(0xFFFF7622),
                                                                                                size: 60.0,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }
                                                                                        List<ServiceSlotsRecord> containerServiceSlotsRecordList = snapshot.data!;
                                                                                        final containerServiceSlotsRecord = containerServiceSlotsRecordList.isNotEmpty ? containerServiceSlotsRecordList.first : null;

                                                                                        return Container(
                                                                                          decoration: BoxDecoration(),
                                                                                          child: Row(
                                                                                            mainAxisSize: MainAxisSize.min,
                                                                                            mainAxisAlignment: MainAxisAlignment.end,
                                                                                            children: [
                                                                                              FFButtonWidget(
                                                                                                onPressed: () async {
                                                                                                  await listViewBookingsRecord.reference.update(createBookingsRecordData(
                                                                                                    bookingStatus: 'Cancel',
                                                                                                  ));

                                                                                                  await containerServiceSlotsRecord!.reference.update({
                                                                                                    ...createServiceSlotsRecordData(
                                                                                                      isslotbooked: false,
                                                                                                    ),
                                                                                                    ...mapToFirestore(
                                                                                                      {
                                                                                                        'bookedBy': FieldValue.delete(),
                                                                                                      },
                                                                                                    ),
                                                                                                  });
                                                                                                },
                                                                                                text: 'Cancel Appointment',
                                                                                                options: FFButtonOptions(
                                                                                                  height: 50.0,
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                                  iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                                  color: Colors.white,
                                                                                                  textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                                        fontFamily: 'Sen',
                                                                                                        color: Color(0xFF7C7C7C),
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w500,
                                                                                                      ),
                                                                                                  elevation: 0.0,
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0xFFDCDCDC),
                                                                                                  ),
                                                                                                  borderRadius: BorderRadius.circular(10.0),
                                                                                                  hoverColor: Color(0xFFFF7622),
                                                                                                  hoverTextColor: Colors.white,
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            Align(
                                                                              alignment: AlignmentDirectional(-1.0, 0.0),
                                                                              child: Text(
                                                                                () {
                                                                                  if (listViewBookingsRecord.bookingStatus == 'Cancel') {
                                                                                    return 'This Booking Is Cancel';
                                                                                  } else if (listViewBookingsRecord.bookingStatus == 'Completed') {
                                                                                    return 'Appointment Completed';
                                                                                  } else if (listViewBookingsRecord.bookingStatus == 'Not Attended') {
                                                                                    return 'Not Attended';
                                                                                  } else {
                                                                                    return 'Appointment Scheduled';
                                                                                  }
                                                                                }(),
                                                                                textAlign: TextAlign.start,
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Sen',
                                                                                      color: () {
                                                                                        if (listViewBookingsRecord.bookingStatus == 'Cancel') {
                                                                                          return Color(0xFFF87575);
                                                                                        } else if (listViewBookingsRecord.bookingStatus == 'Completed') {
                                                                                          return Color(0xFF5EAD5E);
                                                                                        } else if (listViewBookingsRecord.bookingStatus == 'Not Attended') {
                                                                                          return Color(0xFFF0802B);
                                                                                        } else {
                                                                                          return Color(0xFF969696);
                                                                                        }
                                                                                      }(),
                                                                                      fontSize: 18.0,
                                                                                      letterSpacing: 0.0,
                                                                                      fontWeight: FontWeight.w500,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width: MediaQuery.sizeOf(context)
                                                                              .width *
                                                                          1.0,
                                                                      height:
                                                                          1.0,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Color(
                                                                            0xFFDCDCDC),
                                                                      ),
                                                                    ),
                                                                  ]
                                                                      .divide(SizedBox(
                                                                          height:
                                                                              26.0))
                                                                      .around(SizedBox(
                                                                          height:
                                                                              26.0)),
                                                                ),
                                                              );
                                                            },
                                                          );
                                                        },
                                                      );
                                                    },
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ));
      },
    );
  }
}
