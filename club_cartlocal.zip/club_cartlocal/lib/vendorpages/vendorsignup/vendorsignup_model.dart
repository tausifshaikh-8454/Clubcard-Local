import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/index.dart';
import 'vendorsignup_widget.dart' show VendorsignupWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendorsignupModel extends FlutterFlowModel<VendorsignupWidget> {
  ///  Local state fields for this page.

  String? phoneNumber;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for businessName widget.
  FocusNode? businessNameFocusNode;
  TextEditingController? businessNameTextController;
  String? Function(BuildContext, String?)? businessNameTextControllerValidator;
  String? _businessNameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Business Name is required';
    }

    return null;
  }

  // State field(s) for Companyhouseno widget.
  FocusNode? companyhousenoFocusNode;
  TextEditingController? companyhousenoTextController;
  String? Function(BuildContext, String?)?
      companyhousenoTextControllerValidator;
  String? _companyhousenoTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Company House No is required';
    }

    return null;
  }

  // State field(s) for Companyvatno widget.
  FocusNode? companyvatnoFocusNode;
  TextEditingController? companyvatnoTextController;
  String? Function(BuildContext, String?)? companyvatnoTextControllerValidator;
  // State field(s) for BusinessEmail widget.
  FocusNode? businessEmailFocusNode;
  TextEditingController? businessEmailTextController;
  String? Function(BuildContext, String?)? businessEmailTextControllerValidator;
  String? _businessEmailTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Business Email is required';
    }

    return null;
  }

  // State field(s) for Businesstelephone widget.
  FocusNode? businesstelephoneFocusNode;
  TextEditingController? businesstelephoneTextController;
  String? Function(BuildContext, String?)?
      businesstelephoneTextControllerValidator;
  String? _businesstelephoneTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Business Telephone is required';
    }

    if (!RegExp('^[0-9]').hasMatch(val)) {
      return 'Please enter in digits';
    }
    return null;
  }

  // State field(s) for businessAddress widget.
  FocusNode? businessAddressFocusNode;
  TextEditingController? businessAddressTextController;
  String? Function(BuildContext, String?)?
      businessAddressTextControllerValidator;
  String? _businessAddressTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Enter Address is required';
    }

    return null;
  }

  // State field(s) for businessstreet widget.
  FocusNode? businessstreetFocusNode;
  TextEditingController? businessstreetTextController;
  String? Function(BuildContext, String?)?
      businessstreetTextControllerValidator;
  String? _businessstreetTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Business street is required';
    }

    return null;
  }

  // State field(s) for cityname widget.
  FocusNode? citynameFocusNode;
  TextEditingController? citynameTextController;
  String? Function(BuildContext, String?)? citynameTextControllerValidator;
  String? _citynameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Belonging city is required';
    }

    return null;
  }

  // State field(s) for websiteurl widget.
  FocusNode? websiteurlFocusNode;
  TextEditingController? websiteurlTextController;
  String? Function(BuildContext, String?)? websiteurlTextControllerValidator;
  // State field(s) for Businesscountry widget.
  FocusNode? businesscountryFocusNode;
  TextEditingController? businesscountryTextController;
  String? Function(BuildContext, String?)?
      businesscountryTextControllerValidator;
  String? _businesscountryTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'country is required';
    }

    return null;
  }

  // State field(s) for Businesszipcode widget.
  FocusNode? businesszipcodeFocusNode;
  TextEditingController? businesszipcodeTextController;
  String? Function(BuildContext, String?)?
      businesszipcodeTextControllerValidator;
  String? _businesszipcodeTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return ' zipcode is required';
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    businessNameTextControllerValidator = _businessNameTextControllerValidator;
    companyhousenoTextControllerValidator =
        _companyhousenoTextControllerValidator;
    businessEmailTextControllerValidator =
        _businessEmailTextControllerValidator;
    businesstelephoneTextControllerValidator =
        _businesstelephoneTextControllerValidator;
    businessAddressTextControllerValidator =
        _businessAddressTextControllerValidator;
    businessstreetTextControllerValidator =
        _businessstreetTextControllerValidator;
    citynameTextControllerValidator = _citynameTextControllerValidator;
    businesscountryTextControllerValidator =
        _businesscountryTextControllerValidator;
    businesszipcodeTextControllerValidator =
        _businesszipcodeTextControllerValidator;
  }

  @override
  void dispose() {
    businessNameFocusNode?.dispose();
    businessNameTextController?.dispose();

    companyhousenoFocusNode?.dispose();
    companyhousenoTextController?.dispose();

    companyvatnoFocusNode?.dispose();
    companyvatnoTextController?.dispose();

    businessEmailFocusNode?.dispose();
    businessEmailTextController?.dispose();

    businesstelephoneFocusNode?.dispose();
    businesstelephoneTextController?.dispose();

    businessAddressFocusNode?.dispose();
    businessAddressTextController?.dispose();

    businessstreetFocusNode?.dispose();
    businessstreetTextController?.dispose();

    citynameFocusNode?.dispose();
    citynameTextController?.dispose();

    websiteurlFocusNode?.dispose();
    websiteurlTextController?.dispose();

    businesscountryFocusNode?.dispose();
    businesscountryTextController?.dispose();

    businesszipcodeFocusNode?.dispose();
    businesszipcodeTextController?.dispose();
  }
}
