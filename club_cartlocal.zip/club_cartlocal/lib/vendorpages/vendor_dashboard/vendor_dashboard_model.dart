import '/auth/base_auth_user_provider.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'vendor_dashboard_widget.dart' show VendorDashboardWidget;
import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendorDashboardModel extends FlutterFlowModel<VendorDashboardWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel1.dispose();
    vendDrawerModel2.dispose();
  }
}
