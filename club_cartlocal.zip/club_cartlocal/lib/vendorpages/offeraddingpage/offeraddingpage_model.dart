import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'offeraddingpage_widget.dart' show OfferaddingpageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OfferaddingpageModel extends FlutterFlowModel<OfferaddingpageWidget> {
  ///  Local state fields for this page.

  List<String> tagList = [];
  void addToTagList(String item) => tagList.add(item);
  void removeFromTagList(String item) => tagList.remove(item);
  void removeAtIndexFromTagList(int index) => tagList.removeAt(index);
  void insertAtIndexInTagList(int index, String item) =>
      tagList.insert(index, item);
  void updateTagListAtIndex(int index, Function(String) updateFn) =>
      tagList[index] = updateFn(tagList[index]);

  List<DocumentReference> user = [];
  void addToUser(DocumentReference item) => user.add(item);
  void removeFromUser(DocumentReference item) => user.remove(item);
  void removeAtIndexFromUser(int index) => user.removeAt(index);
  void insertAtIndexInUser(int index, DocumentReference item) =>
      user.insert(index, item);
  void updateUserAtIndex(int index, Function(DocumentReference) updateFn) =>
      user[index] = updateFn(user[index]);

  List<DateTime> startTime = [];
  void addToStartTime(DateTime item) => startTime.add(item);
  void removeFromStartTime(DateTime item) => startTime.remove(item);
  void removeAtIndexFromStartTime(int index) => startTime.removeAt(index);
  void insertAtIndexInStartTime(int index, DateTime item) =>
      startTime.insert(index, item);
  void updateStartTimeAtIndex(int index, Function(DateTime) updateFn) =>
      startTime[index] = updateFn(startTime[index]);

  List<int> timeslotCount = [0];
  void addToTimeslotCount(int item) => timeslotCount.add(item);
  void removeFromTimeslotCount(int item) => timeslotCount.remove(item);
  void removeAtIndexFromTimeslotCount(int index) =>
      timeslotCount.removeAt(index);
  void insertAtIndexInTimeslotCount(int index, int item) =>
      timeslotCount.insert(index, item);
  void updateTimeslotCountAtIndex(int index, Function(int) updateFn) =>
      timeslotCount[index] = updateFn(timeslotCount[index]);

  DateTime? startDate;

  DateTime? endDate;

  ///  State fields for stateful widgets in this page.

  final formKey1 = GlobalKey<FormState>();
  final formKey2 = GlobalKey<FormState>();
  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel1;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for productname widget.
  FocusNode? productnameFocusNode;
  TextEditingController? productnameTextController;
  String? Function(BuildContext, String?)? productnameTextControllerValidator;
  String? _productnameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // State field(s) for cateDropDown widget.
  String? cateDropDownValue;
  FormFieldController<String>? cateDropDownValueController;
  DateTime? datePicked1;
  DateTime? datePicked2;
  // State field(s) for Prod_RegularPrice widget.
  FocusNode? prodRegularPriceFocusNode;
  TextEditingController? prodRegularPriceTextController;
  String? Function(BuildContext, String?)?
      prodRegularPriceTextControllerValidator;
  String? _prodRegularPriceTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (!RegExp('^[0-9]').hasMatch(val)) {
      return 'Please enter in digits';
    }
    return null;
  }

  // State field(s) for prod_saleprice widget.
  FocusNode? prodSalepriceFocusNode;
  TextEditingController? prodSalepriceTextController;
  String? Function(BuildContext, String?)? prodSalepriceTextControllerValidator;
  String? _prodSalepriceTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (!RegExp('^[0-9]').hasMatch(val)) {
      return 'Please enter in digits';
    }
    return null;
  }

  // State field(s) for products_tags widget.
  FocusNode? productsTagsFocusNode;
  TextEditingController? productsTagsTextController;
  String? Function(BuildContext, String?)? productsTagsTextControllerValidator;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for product_deascr widget.
  FocusNode? productDeascrFocusNode;
  TextEditingController? productDeascrTextController;
  String? Function(BuildContext, String?)? productDeascrTextControllerValidator;
  String? _productDeascrTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  OffersCollectionRecord? productCreatedraft;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  OffersCollectionRecord? productCreate;
  // State field(s) for offertype widget.
  String? offertypeValue;
  FormFieldController<String>? offertypeValueController;
  // State field(s) for offerid widget.
  FocusNode? offeridFocusNode;
  TextEditingController? offeridTextController;
  String? Function(BuildContext, String?)? offeridTextControllerValidator;
  String? _offeridTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // Model for vendDrawer component.
  late VendDrawerModel vendDrawerModel2;

  @override
  void initState(BuildContext context) {
    vendDrawerModel1 = createModel(context, () => VendDrawerModel());
    productnameTextControllerValidator = _productnameTextControllerValidator;
    prodRegularPriceTextControllerValidator =
        _prodRegularPriceTextControllerValidator;
    prodSalepriceTextControllerValidator =
        _prodSalepriceTextControllerValidator;
    productDeascrTextControllerValidator =
        _productDeascrTextControllerValidator;
    offeridTextControllerValidator = _offeridTextControllerValidator;
    vendDrawerModel2 = createModel(context, () => VendDrawerModel());
  }

  @override
  void dispose() {
    vendDrawerModel1.dispose();
    productnameFocusNode?.dispose();
    productnameTextController?.dispose();

    prodRegularPriceFocusNode?.dispose();
    prodRegularPriceTextController?.dispose();

    prodSalepriceFocusNode?.dispose();
    prodSalepriceTextController?.dispose();

    productsTagsFocusNode?.dispose();
    productsTagsTextController?.dispose();

    productDeascrFocusNode?.dispose();
    productDeascrTextController?.dispose();

    offeridFocusNode?.dispose();
    offeridTextController?.dispose();

    vendDrawerModel2.dispose();
  }
}
