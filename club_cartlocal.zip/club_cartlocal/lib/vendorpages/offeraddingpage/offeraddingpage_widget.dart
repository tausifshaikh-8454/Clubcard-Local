import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/vend_drawer_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'offeraddingpage_model.dart';
export 'offeraddingpage_model.dart';

class OfferaddingpageWidget extends StatefulWidget {
  const OfferaddingpageWidget({
    super.key,
    required this.vendref,
    required this.producttype,
  });

  final VendorDetailsRecord? vendref;
  final String? producttype;

  static String routeName = 'Offeraddingpage';
  static String routePath = '/offeraddingpage';

  @override
  State<OfferaddingpageWidget> createState() => _OfferaddingpageWidgetState();
}

class _OfferaddingpageWidgetState extends State<OfferaddingpageWidget> {
  late OfferaddingpageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => OfferaddingpageModel());

    _model.productnameTextController ??= TextEditingController();
    _model.productnameFocusNode ??= FocusNode();

    _model.prodRegularPriceTextController ??= TextEditingController();
    _model.prodRegularPriceFocusNode ??= FocusNode();

    _model.prodSalepriceTextController ??= TextEditingController();
    _model.prodSalepriceFocusNode ??= FocusNode();

    _model.productsTagsTextController ??= TextEditingController();
    _model.productsTagsFocusNode ??= FocusNode();

    _model.productDeascrTextController ??= TextEditingController();
    _model.productDeascrFocusNode ??= FocusNode();

    _model.offeridTextController ??= TextEditingController(
        text: 'O-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
      random_data.randomInteger(0, 1000),
      formatType: FormatType.custom,
      format: '-',
      locale: '',
    )}');
    _model.offeridFocusNode ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<VendorDetailsRecord>>(
      stream: queryVendorDetailsRecord(
        queryBuilder: (vendorDetailsRecord) => vendorDetailsRecord.where(
          'vendor_email',
          isEqualTo: currentUserEmail,
        ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Color(0xFFF5F7FB),
            body: Center(
              child: SizedBox(
                width: 60.0,
                height: 60.0,
                child: SpinKitRipple(
                  color: Color(0xFFFF7622),
                  size: 60.0,
                ),
              ),
            ),
          );
        }
        List<VendorDetailsRecord> offeraddingpageVendorDetailsRecordList =
            snapshot.data!;
        final offeraddingpageVendorDetailsRecord =
            offeraddingpageVendorDetailsRecordList.isNotEmpty
                ? offeraddingpageVendorDetailsRecordList.first
                : null;

        return Title(
            title: 'Offeraddingpage',
            color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
            child: Scaffold(
              key: scaffoldKey,
              backgroundColor: Color(0xFFF5F7FB),
              drawer: Container(
                width: MediaQuery.sizeOf(context).width * 0.9,
                child: Drawer(
                  elevation: 16.0,
                  child: wrapWithModel(
                    model: _model.vendDrawerModel2,
                    updateCallback: () => safeSetState(() {}),
                    child: VendDrawerWidget(
                      parameter1: offeraddingpageVendorDetailsRecord
                          ?.businessProfileLogo,
                      parameter2:
                          offeraddingpageVendorDetailsRecord?.businessName,
                      parameter3: offeraddingpageVendorDetailsRecord?.vendorId,
                      parameter4: offeraddingpageVendorDetailsRecord?.reference,
                    ),
                  ),
                ),
              ),
              body: SafeArea(
                top: true,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (responsiveVisibility(
                      context: context,
                      phone: false,
                      tablet: false,
                      tabletLandscape: false,
                    ))
                      Container(
                        width: MediaQuery.sizeOf(context).width * 0.2,
                        decoration: BoxDecoration(),
                        child: wrapWithModel(
                          model: _model.vendDrawerModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: VendDrawerWidget(
                            parameter1: offeraddingpageVendorDetailsRecord
                                ?.businessProfileLogo,
                            parameter2: offeraddingpageVendorDetailsRecord
                                ?.businessName,
                            parameter3:
                                offeraddingpageVendorDetailsRecord?.vendorId,
                            parameter4:
                                offeraddingpageVendorDetailsRecord?.reference,
                          ),
                        ),
                      ),
                    Expanded(
                      flex: 1,
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 16.0, 16.0, 16.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 16.0,
                                color: Color(0x10000000),
                                offset: Offset(
                                  4.0,
                                  4.0,
                                ),
                              )
                            ],
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(10.0),
                              bottomRight: Radius.circular(10.0),
                              topLeft: Radius.circular(0.0),
                              topRight: Radius.circular(0.0),
                            ),
                          ),
                          alignment: AlignmentDirectional(0.0, 0.0),
                          child: SingleChildScrollView(
                            primary: false,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 26.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 1.0,
                                    height: 80.0,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      boxShadow: [
                                        BoxShadow(
                                          blurRadius: 4.0,
                                          color: Color(0x33000000),
                                          offset: Offset(
                                            0.0,
                                            2.0,
                                          ),
                                        )
                                      ],
                                      borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(0.0),
                                        bottomRight: Radius.circular(0.0),
                                        topLeft: Radius.circular(10.0),
                                        topRight: Radius.circular(10.0),
                                      ),
                                      border: Border.all(
                                        color: Color(0xFFDCDCDC),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(-1.0, 0.0),
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    20.0, 0.0, 0.0, 0.0),
                                            child: Text(
                                              'Offers list',
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily: 'Poppins',
                                                    color: Color(0xFF656565),
                                                    fontSize: 26.0,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                            ),
                                          ),
                                        ),
                                        if (responsiveVisibility(
                                          context: context,
                                          desktop: false,
                                        ))
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 20.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                scaffoldKey.currentState!
                                                    .openDrawer();
                                              },
                                              child: Icon(
                                                Icons.menu_rounded,
                                                color: Color(0xFFFF7622),
                                                size: 30.0,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 1.0,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(10.0),
                                        bottomRight: Radius.circular(10.0),
                                        topLeft: Radius.circular(0.0),
                                        topRight: Radius.circular(0.0),
                                      ),
                                    ),
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 54.0),
                                      child: Wrap(
                                        spacing: 20.0,
                                        runSpacing: 20.0,
                                        alignment: WrapAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.start,
                                        direction: Axis.horizontal,
                                        runAlignment: WrapAlignment.center,
                                        verticalDirection:
                                            VerticalDirection.down,
                                        clipBehavior: Clip.none,
                                        children: [
                                          Container(
                                            width: () {
                                              if (MediaQuery.sizeOf(context)
                                                      .width <
                                                  kBreakpointSmall) {
                                                return MediaQuery.sizeOf(
                                                        context)
                                                    .width;
                                              } else if (MediaQuery.sizeOf(
                                                          context)
                                                      .width <
                                                  kBreakpointMedium) {
                                                return MediaQuery.sizeOf(
                                                        context)
                                                    .width;
                                              } else if (MediaQuery.sizeOf(
                                                          context)
                                                      .width <
                                                  kBreakpointLarge) {
                                                return 500.0;
                                              } else {
                                                return 500.0;
                                              }
                                            }(),
                                            constraints: BoxConstraints(
                                              maxWidth: 500.0,
                                            ),
                                            decoration: BoxDecoration(),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(20.0, 0.0,
                                                                0.0, 16.0),
                                                    child: Text(
                                                      widget!.producttype ==
                                                              'Services'
                                                          ? 'Add a service'
                                                          : 'Add a product',
                                                      textAlign:
                                                          TextAlign.start,
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily:
                                                                'Poppins',
                                                            color: Color(
                                                                0xFF3D3D3D),
                                                            fontSize: 26.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  child: Form(
                                                    key: _model.formKey1,
                                                    autovalidateMode:
                                                        AutovalidateMode
                                                            .disabled,
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  15.0,
                                                                  0.0,
                                                                  15.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 600.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFFFECD4),
                                                          image:
                                                              DecorationImage(
                                                            fit: BoxFit.contain,
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0.0, 0.0),
                                                            image:
                                                                Image.network(
                                                              _model
                                                                  .uploadedFileUrl,
                                                            ).image,
                                                          ),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              blurRadius: 4.0,
                                                              color: Color(
                                                                  0x33000000),
                                                              offset: Offset(
                                                                0.0,
                                                                2.0,
                                                              ),
                                                            )
                                                          ],
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      20.0),
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            Align(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      1.0, 1.0),
                                                              child: Padding(
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        20.0,
                                                                        20.0),
                                                                child:
                                                                    Container(
                                                                  width: 50.0,
                                                                  height: 50.0,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Colors
                                                                        .white,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            50.0),
                                                                  ),
                                                                  child:
                                                                      InkWell(
                                                                    splashColor:
                                                                        Colors
                                                                            .transparent,
                                                                    focusColor:
                                                                        Colors
                                                                            .transparent,
                                                                    hoverColor:
                                                                        Colors
                                                                            .transparent,
                                                                    highlightColor:
                                                                        Colors
                                                                            .transparent,
                                                                    onTap:
                                                                        () async {
                                                                      final selectedMedia =
                                                                          await selectMediaWithSourceBottomSheet(
                                                                        context:
                                                                            context,
                                                                        maxWidth:
                                                                            1200.00,
                                                                        maxHeight:
                                                                            1200.00,
                                                                        imageQuality:
                                                                            100,
                                                                        allowPhoto:
                                                                            true,
                                                                        includeDimensions:
                                                                            true,
                                                                      );
                                                                      if (selectedMedia !=
                                                                              null &&
                                                                          selectedMedia.every((m) => validateFileFormat(
                                                                              m.storagePath,
                                                                              context))) {
                                                                        safeSetState(() =>
                                                                            _model.isDataUploading =
                                                                                true);
                                                                        var selectedUploadedFiles =
                                                                            <FFUploadedFile>[];

                                                                        var downloadUrls =
                                                                            <String>[];
                                                                        try {
                                                                          showUploadMessage(
                                                                            context,
                                                                            'Uploading file...',
                                                                            showLoading:
                                                                                true,
                                                                          );
                                                                          selectedUploadedFiles = selectedMedia
                                                                              .map((m) => FFUploadedFile(
                                                                                    name: m.storagePath.split('/').last,
                                                                                    bytes: m.bytes,
                                                                                    height: m.dimensions?.height,
                                                                                    width: m.dimensions?.width,
                                                                                    blurHash: m.blurHash,
                                                                                  ))
                                                                              .toList();

                                                                          downloadUrls = (await Future.wait(
                                                                            selectedMedia.map(
                                                                              (m) async => await uploadData(m.storagePath, m.bytes),
                                                                            ),
                                                                          ))
                                                                              .where((u) => u != null)
                                                                              .map((u) => u!)
                                                                              .toList();
                                                                        } finally {
                                                                          ScaffoldMessenger.of(context)
                                                                              .hideCurrentSnackBar();
                                                                          _model.isDataUploading =
                                                                              false;
                                                                        }
                                                                        if (selectedUploadedFiles.length == selectedMedia.length &&
                                                                            downloadUrls.length ==
                                                                                selectedMedia.length) {
                                                                          safeSetState(
                                                                              () {
                                                                            _model.uploadedLocalFile =
                                                                                selectedUploadedFiles.first;
                                                                            _model.uploadedFileUrl =
                                                                                downloadUrls.first;
                                                                          });
                                                                          showUploadMessage(
                                                                              context,
                                                                              'Success!');
                                                                        } else {
                                                                          safeSetState(
                                                                              () {});
                                                                          showUploadMessage(
                                                                              context,
                                                                              'Failed to upload data');
                                                                          return;
                                                                        }
                                                                      }
                                                                    },
                                                                    child: Icon(
                                                                      Icons
                                                                          .camera_alt_outlined,
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      size:
                                                                          24.0,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: () {
                                              if (MediaQuery.sizeOf(context)
                                                      .width <
                                                  kBreakpointSmall) {
                                                return MediaQuery.sizeOf(
                                                        context)
                                                    .width;
                                              } else if (MediaQuery.sizeOf(
                                                          context)
                                                      .width <
                                                  kBreakpointMedium) {
                                                return MediaQuery.sizeOf(
                                                        context)
                                                    .width;
                                              } else if (MediaQuery.sizeOf(
                                                          context)
                                                      .width <
                                                  kBreakpointLarge) {
                                                return 500.0;
                                              } else {
                                                return 500.0;
                                              }
                                            }(),
                                            constraints: BoxConstraints(
                                              maxWidth: 500.0,
                                            ),
                                            decoration: BoxDecoration(),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  1.0, -1.0),
                                              child: Stack(
                                                alignment: AlignmentDirectional(
                                                    1.0, -1.0),
                                                children: [
                                                  Form(
                                                    key: _model.formKey2,
                                                    autovalidateMode:
                                                        AutovalidateMode
                                                            .disabled,
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  20.0,
                                                                  40.0,
                                                                  20.0,
                                                                  40.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        26.0),
                                                            child: Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  0.9,
                                                              child:
                                                                  TextFormField(
                                                                controller: _model
                                                                    .productnameTextController,
                                                                focusNode: _model
                                                                    .productnameFocusNode,
                                                                autofocus:
                                                                    false,
                                                                textInputAction:
                                                                    TextInputAction
                                                                        .done,
                                                                obscureText:
                                                                    false,
                                                                decoration:
                                                                    InputDecoration(
                                                                  isDense: true,
                                                                  labelStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFFBDBDBD),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  hintText: widget!
                                                                              .producttype ==
                                                                          'Services'
                                                                      ? 'Name of Service'
                                                                      : 'Name of Product',
                                                                  hintStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFFBDBDBD),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  enabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Color(
                                                                          0xFFDCDCDC),
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  focusedBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  errorBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .error,
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  focusedErrorBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .error,
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  filled: true,
                                                                  fillColor:
                                                                      Colors
                                                                          .white,
                                                                ),
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF464646),
                                                                      fontSize:
                                                                          18.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                                cursorColor:
                                                                    Colors
                                                                        .black,
                                                                validator: _model
                                                                    .productnameTextControllerValidator
                                                                    .asValidator(
                                                                        context),
                                                              ),
                                                            ),
                                                          ),
                                                          if (_model
                                                                  .offertypeValue ==
                                                              'Products')
                                                            Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                FlutterFlowDropDown<
                                                                    String>(
                                                                  controller: _model
                                                                          .cateDropDownValueController ??=
                                                                      FormFieldController<
                                                                              String>(
                                                                          null),
                                                                  options: [
                                                                    'Deals',
                                                                    'Perishables'
                                                                  ],
                                                                  onChanged: (val) =>
                                                                      safeSetState(() =>
                                                                          _model.cateDropDownValue =
                                                                              val),
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      0.9,
                                                                  height: 50.0,
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFF464646),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  hintText:
                                                                      'Select Offer Category',
                                                                  icon: Icon(
                                                                    Icons
                                                                        .keyboard_arrow_down_rounded,
                                                                    color: Color(
                                                                        0xFF464646),
                                                                    size: 30.0,
                                                                  ),
                                                                  fillColor:
                                                                      Colors
                                                                          .white,
                                                                  elevation:
                                                                      0.0,
                                                                  borderColor:
                                                                      Color(
                                                                          0xFFDCDCDC),
                                                                  borderWidth:
                                                                      1.0,
                                                                  borderRadius:
                                                                      10.0,
                                                                  margin: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          12.0,
                                                                          0.0,
                                                                          12.0,
                                                                          0.0),
                                                                  hidesUnderline:
                                                                      true,
                                                                  isOverButton:
                                                                      false,
                                                                  isSearchable:
                                                                      false,
                                                                  isMultiSelect:
                                                                      false,
                                                                ),
                                                                Expanded(
                                                                  child:
                                                                      Padding(
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            20.0,
                                                                            0.0,
                                                                            20.0),
                                                                    child:
                                                                        Container(
                                                                      width: MediaQuery.sizeOf(context)
                                                                              .width *
                                                                          1.0,
                                                                      height:
                                                                          300.0,
                                                                      child: custom_widgets
                                                                          .DateRangePicker(
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            1.0,
                                                                        height:
                                                                            300.0,
                                                                        calendarBackgroundColor:
                                                                            Color(0xFFFFF9F9),
                                                                        dateColor:
                                                                            Color(0xFF979797),
                                                                        rangeColor:
                                                                            Color(0xFFFF7622),
                                                                        labelText:
                                                                            'Please Select Offer Date',
                                                                        pickStartDate:
                                                                            (startDate) async {
                                                                          _model.startDate =
                                                                              startDate;
                                                                          safeSetState(
                                                                              () {});
                                                                        },
                                                                        pickEndDate:
                                                                            (endDate) async {
                                                                          _model.endDate =
                                                                              endDate;
                                                                          safeSetState(
                                                                              () {});
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          if (_model
                                                                  .offertypeValue ==
                                                              'Services')
                                                            Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  0.9,
                                                              decoration:
                                                                  BoxDecoration(),
                                                              child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                children: [
                                                                  Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .max,
                                                                    children: [
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            20.0,
                                                                            0.0,
                                                                            0.0),
                                                                        child:
                                                                            Container(
                                                                          width:
                                                                              MediaQuery.sizeOf(context).width * 0.9,
                                                                          height:
                                                                              50.0,
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color:
                                                                                Colors.white,
                                                                            borderRadius:
                                                                                BorderRadius.circular(10.0),
                                                                            border:
                                                                                Border.all(
                                                                              color: Color(0xFFDCDCDC),
                                                                              width: 1.0,
                                                                            ),
                                                                          ),
                                                                          child:
                                                                              Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                0.0),
                                                                            child:
                                                                                Row(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                              children: [
                                                                                Text(
                                                                                  () {
                                                                                    if ((widget!.producttype == 'Products') && (_model.datePicked1 == null)) {
                                                                                      return 'Expiry Date';
                                                                                    } else if ((widget!.producttype == 'Services') && (_model.datePicked1 == null)) {
                                                                                      return 'Booking Date';
                                                                                    } else {
                                                                                      return dateTimeFormat("d/M/y", _model.datePicked1);
                                                                                    }
                                                                                  }(),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        fontFamily: 'Sen',
                                                                                        color: Colors.black,
                                                                                        fontSize: 16.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                InkWell(
                                                                                  splashColor: Colors.transparent,
                                                                                  focusColor: Colors.transparent,
                                                                                  hoverColor: Colors.transparent,
                                                                                  highlightColor: Colors.transparent,
                                                                                  onTap: () async {
                                                                                    final _datePicked1Date = await showDatePicker(
                                                                                      context: context,
                                                                                      initialDate: getCurrentTimestamp,
                                                                                      firstDate: getCurrentTimestamp,
                                                                                      lastDate: DateTime(2050),
                                                                                      builder: (context, child) {
                                                                                        return wrapInMaterialDatePickerTheme(
                                                                                          context,
                                                                                          child!,
                                                                                          headerBackgroundColor: Color(0xFFFF7622),
                                                                                          headerForegroundColor: Colors.white,
                                                                                          headerTextStyle: FlutterFlowTheme.of(context).headlineLarge.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                fontSize: 24.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                          pickerBackgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                          pickerForegroundColor: FlutterFlowTheme.of(context).primaryText,
                                                                                          selectedDateTimeBackgroundColor: Color(0xFFFF7622),
                                                                                          selectedDateTimeForegroundColor: Colors.white,
                                                                                          actionButtonForegroundColor: Color(0xFFFF7622),
                                                                                          iconSize: 24.0,
                                                                                        );
                                                                                      },
                                                                                    );

                                                                                    if (_datePicked1Date != null) {
                                                                                      safeSetState(() {
                                                                                        _model.datePicked1 = DateTime(
                                                                                          _datePicked1Date.year,
                                                                                          _datePicked1Date.month,
                                                                                          _datePicked1Date.day,
                                                                                        );
                                                                                      });
                                                                                    } else if (_model.datePicked1 != null) {
                                                                                      safeSetState(() {
                                                                                        _model.datePicked1 = getCurrentTimestamp;
                                                                                      });
                                                                                    }
                                                                                    _model.startDate = getCurrentTimestamp;
                                                                                    safeSetState(() {});
                                                                                    _model.endDate = _model.datePicked1;
                                                                                    safeSetState(() {});
                                                                                  },
                                                                                  child: Icon(
                                                                                    Icons.calendar_month_outlined,
                                                                                    color: Color(0xFFFF7622),
                                                                                    size: 24.0,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            20.0,
                                                                            0.0,
                                                                            10.0),
                                                                        child:
                                                                            Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceBetween,
                                                                          children: [
                                                                            Align(
                                                                              alignment: AlignmentDirectional(-1.0, 0.0),
                                                                              child: Text(
                                                                                'Add time slots',
                                                                                style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                      fontFamily: 'Sen',
                                                                                      color: Color(0xFF7C7C7C),
                                                                                      fontSize: 18.0,
                                                                                      letterSpacing: 0.0,
                                                                                    ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            10.0),
                                                                        child:
                                                                            Stack(
                                                                          children: [
                                                                            Container(
                                                                              width: MediaQuery.sizeOf(context).width * 0.9,
                                                                              decoration: BoxDecoration(),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.min,
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Flexible(
                                                                                    child: Container(
                                                                                      width: MediaQuery.sizeOf(context).width * 0.45,
                                                                                      height: 50.0,
                                                                                      decoration: BoxDecoration(
                                                                                        color: Colors.white,
                                                                                        borderRadius: BorderRadius.circular(10.0),
                                                                                        border: Border.all(
                                                                                          color: Color(0xFFDCDCDC),
                                                                                          width: 1.0,
                                                                                        ),
                                                                                      ),
                                                                                      child: Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 10.0, 0.0),
                                                                                        child: Row(
                                                                                          mainAxisSize: MainAxisSize.max,
                                                                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                          children: [
                                                                                            Text(
                                                                                              valueOrDefault<String>(
                                                                                                dateTimeFormat("jm", _model.datePicked2),
                                                                                                'Start time',
                                                                                              ),
                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                    fontFamily: 'Sen',
                                                                                                    color: Color(0xFF464646),
                                                                                                    fontSize: 16.0,
                                                                                                    letterSpacing: 0.0,
                                                                                                  ),
                                                                                            ),
                                                                                            InkWell(
                                                                                              splashColor: Colors.transparent,
                                                                                              focusColor: Colors.transparent,
                                                                                              hoverColor: Colors.transparent,
                                                                                              highlightColor: Colors.transparent,
                                                                                              onTap: () async {
                                                                                                final _datePicked2Time = await showTimePicker(
                                                                                                  context: context,
                                                                                                  initialTime: TimeOfDay.fromDateTime((_model.datePicked1 ?? DateTime.now())),
                                                                                                  builder: (context, child) {
                                                                                                    return wrapInMaterialTimePickerTheme(
                                                                                                      context,
                                                                                                      child!,
                                                                                                      headerBackgroundColor: Color(0xFFFF7622),
                                                                                                      headerForegroundColor: Colors.white,
                                                                                                      headerTextStyle: FlutterFlowTheme.of(context).headlineLarge.override(
                                                                                                            fontFamily: 'Poppins',
                                                                                                            fontSize: 24.0,
                                                                                                            letterSpacing: 0.0,
                                                                                                            fontWeight: FontWeight.w600,
                                                                                                          ),
                                                                                                      pickerBackgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                                      pickerForegroundColor: FlutterFlowTheme.of(context).primaryText,
                                                                                                      selectedDateTimeBackgroundColor: Color(0xFFFF7622),
                                                                                                      selectedDateTimeForegroundColor: Colors.white,
                                                                                                      actionButtonForegroundColor: Color(0xFFFF7622),
                                                                                                      iconSize: 24.0,
                                                                                                    );
                                                                                                  },
                                                                                                );
                                                                                                if (_datePicked2Time != null) {
                                                                                                  safeSetState(() {
                                                                                                    _model.datePicked2 = DateTime(
                                                                                                      (_model.datePicked1 ?? DateTime.now()).year,
                                                                                                      (_model.datePicked1 ?? DateTime.now()).month,
                                                                                                      (_model.datePicked1 ?? DateTime.now()).day,
                                                                                                      _datePicked2Time.hour,
                                                                                                      _datePicked2Time.minute,
                                                                                                    );
                                                                                                  });
                                                                                                } else if (_model.datePicked2 != null) {
                                                                                                  safeSetState(() {
                                                                                                    _model.datePicked2 = _model.datePicked1;
                                                                                                  });
                                                                                                }
                                                                                              },
                                                                                              child: FaIcon(
                                                                                                FontAwesomeIcons.clock,
                                                                                                color: Color(0xFFFF7622),
                                                                                                size: 24.0,
                                                                                              ),
                                                                                            ),
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ].divide(SizedBox(width: 10.0)),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      Align(
                                                                        alignment: AlignmentDirectional(
                                                                            1.0,
                                                                            0.0),
                                                                        child:
                                                                            FFButtonWidget(
                                                                          onPressed:
                                                                              () async {
                                                                            _model.addToStartTime(_model.datePicked2!);
                                                                            safeSetState(() {});
                                                                          },
                                                                          text:
                                                                              'Add',
                                                                          options:
                                                                              FFButtonOptions(
                                                                            width:
                                                                                100.0,
                                                                            height:
                                                                                30.0,
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                16.0,
                                                                                0.0,
                                                                                16.0,
                                                                                0.0),
                                                                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                0.0,
                                                                                0.0,
                                                                                0.0),
                                                                            color:
                                                                                Color(0xFFFF7622),
                                                                            textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                  fontFamily: 'Readex Pro',
                                                                                  color: Colors.white,
                                                                                  letterSpacing: 0.0,
                                                                                ),
                                                                            elevation:
                                                                                0.0,
                                                                            borderRadius:
                                                                                BorderRadius.circular(8.0),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            20.0,
                                                                            0.0,
                                                                            26.0),
                                                                        child:
                                                                            Container(
                                                                          width:
                                                                              MediaQuery.sizeOf(context).width * 0.9,
                                                                          decoration:
                                                                              BoxDecoration(),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children:
                                                                                [
                                                                              Builder(
                                                                                builder: (context) {
                                                                                  final strtimecol = _model.startTime.map((e) => e).toList();

                                                                                  return Column(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    children: List.generate(strtimecol.length, (strtimecolIndex) {
                                                                                      final strtimecolItem = strtimecol[strtimecolIndex];
                                                                                      return Row(
                                                                                        mainAxisSize: MainAxisSize.max,
                                                                                        children: [
                                                                                          Padding(
                                                                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 10.0, 0.0),
                                                                                            child: Text(
                                                                                              (strtimecolIndex + 1).toString(),
                                                                                              style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                    fontFamily: 'Sen',
                                                                                                    color: Color(0xFF464646),
                                                                                                    fontSize: 16.0,
                                                                                                    letterSpacing: 0.0,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                          Expanded(
                                                                                            child: Padding(
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                                                                                              child: Container(
                                                                                                width: 100.0,
                                                                                                height: 50.0,
                                                                                                decoration: BoxDecoration(
                                                                                                  color: Colors.white,
                                                                                                  boxShadow: [
                                                                                                    BoxShadow(
                                                                                                      blurRadius: 16.0,
                                                                                                      color: Color(0x0D000000),
                                                                                                      offset: Offset(
                                                                                                        4.0,
                                                                                                        4.0,
                                                                                                      ),
                                                                                                    )
                                                                                                  ],
                                                                                                  borderRadius: BorderRadius.circular(10.0),
                                                                                                  border: Border.all(
                                                                                                    color: Color(0xFFDCDCDC),
                                                                                                    width: 1.0,
                                                                                                  ),
                                                                                                ),
                                                                                                child: Padding(
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 10.0, 0.0),
                                                                                                  child: Row(
                                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                                    children: [
                                                                                                      Text(
                                                                                                        dateTimeFormat("jm", strtimecolItem),
                                                                                                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                              fontFamily: 'Sen',
                                                                                                              color: Color(0xFF464646),
                                                                                                              fontSize: 16.0,
                                                                                                              letterSpacing: 0.0,
                                                                                                            ),
                                                                                                      ),
                                                                                                    ],
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Align(
                                                                                            alignment: AlignmentDirectional(0.0, 0.0),
                                                                                            child: Padding(
                                                                                              padding: EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 0.0, 0.0),
                                                                                              child: InkWell(
                                                                                                splashColor: Colors.transparent,
                                                                                                focusColor: Colors.transparent,
                                                                                                hoverColor: Colors.transparent,
                                                                                                highlightColor: Colors.transparent,
                                                                                                onTap: () async {
                                                                                                  _model.removeFromStartTime(strtimecolItem);
                                                                                                  safeSetState(() {});
                                                                                                },
                                                                                                child: Icon(
                                                                                                  Icons.cancel_outlined,
                                                                                                  color: Color(0xFFFF7622),
                                                                                                  size: 25.0,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    }),
                                                                                  );
                                                                                },
                                                                              ),
                                                                            ].divide(SizedBox(width: 10.0)),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        26.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .min,
                                                              children: [
                                                                Flexible(
                                                                  child:
                                                                      Padding(
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            20.0,
                                                                            0.0),
                                                                    child:
                                                                        Container(
                                                                      width: MediaQuery.sizeOf(context)
                                                                              .width *
                                                                          0.47,
                                                                      child:
                                                                          TextFormField(
                                                                        controller:
                                                                            _model.prodRegularPriceTextController,
                                                                        focusNode:
                                                                            _model.prodRegularPriceFocusNode,
                                                                        autofocus:
                                                                            false,
                                                                        textInputAction:
                                                                            TextInputAction.done,
                                                                        obscureText:
                                                                            false,
                                                                        decoration:
                                                                            InputDecoration(
                                                                          isDense:
                                                                              true,
                                                                          hintText:
                                                                              'Regular Price',
                                                                          hintStyle: FlutterFlowTheme.of(context)
                                                                              .labelMedium
                                                                              .override(
                                                                                fontFamily: 'Sen',
                                                                                color: Color(0xFFBDBDBD),
                                                                                letterSpacing: 0.0,
                                                                              ),
                                                                          enabledBorder:
                                                                              OutlineInputBorder(
                                                                            borderSide:
                                                                                BorderSide(
                                                                              color: Color(0xFFDCDCDC),
                                                                              width: 1.0,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(10.0),
                                                                          ),
                                                                          focusedBorder:
                                                                              OutlineInputBorder(
                                                                            borderSide:
                                                                                BorderSide(
                                                                              color: Color(0xFFFF7622),
                                                                              width: 1.0,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(10.0),
                                                                          ),
                                                                          errorBorder:
                                                                              OutlineInputBorder(
                                                                            borderSide:
                                                                                BorderSide(
                                                                              color: FlutterFlowTheme.of(context).error,
                                                                              width: 1.0,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(10.0),
                                                                          ),
                                                                          focusedErrorBorder:
                                                                              OutlineInputBorder(
                                                                            borderSide:
                                                                                BorderSide(
                                                                              color: FlutterFlowTheme.of(context).error,
                                                                              width: 1.0,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(10.0),
                                                                          ),
                                                                          filled:
                                                                              true,
                                                                          fillColor:
                                                                              Colors.white,
                                                                          prefixIcon:
                                                                              Icon(
                                                                            Icons.currency_pound_rounded,
                                                                            color:
                                                                                Color(0xFFFF7622),
                                                                            size:
                                                                                18.0,
                                                                          ),
                                                                        ),
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              fontFamily: 'Sen',
                                                                              color: Color(0xFF464646),
                                                                              fontSize: 18.0,
                                                                              letterSpacing: 0.0,
                                                                            ),
                                                                        keyboardType: const TextInputType
                                                                            .numberWithOptions(
                                                                            decimal:
                                                                                true),
                                                                        cursorColor:
                                                                            Colors.black,
                                                                        validator: _model
                                                                            .prodRegularPriceTextControllerValidator
                                                                            .asValidator(context),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Flexible(
                                                                  child:
                                                                      Container(
                                                                    width: MediaQuery.sizeOf(context)
                                                                            .width *
                                                                        0.47,
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          _model
                                                                              .prodSalepriceTextController,
                                                                      focusNode:
                                                                          _model
                                                                              .prodSalepriceFocusNode,
                                                                      autofocus:
                                                                          false,
                                                                      textInputAction:
                                                                          TextInputAction
                                                                              .done,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        isDense:
                                                                            true,
                                                                        labelStyle: FlutterFlowTheme.of(context)
                                                                            .labelMedium
                                                                            .override(
                                                                              fontFamily: 'Sen',
                                                                              color: Color(0xFFBDBDBD),
                                                                              letterSpacing: 0.0,
                                                                            ),
                                                                        hintText:
                                                                            'Sale Price',
                                                                        hintStyle: FlutterFlowTheme.of(context)
                                                                            .labelMedium
                                                                            .override(
                                                                              fontFamily: 'Sen',
                                                                              color: Color(0xFFBDBDBD),
                                                                              letterSpacing: 0.0,
                                                                            ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0xFFDCDCDC),
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(10.0),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0xFFFF7622),
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(10.0),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                FlutterFlowTheme.of(context).error,
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(10.0),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                FlutterFlowTheme.of(context).error,
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                          borderRadius:
                                                                              BorderRadius.circular(10.0),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                        prefixIcon:
                                                                            Icon(
                                                                          Icons
                                                                              .currency_pound_rounded,
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          size:
                                                                              18.0,
                                                                        ),
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Sen',
                                                                            color:
                                                                                Color(0xFF464646),
                                                                            fontSize:
                                                                                18.0,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                      keyboardType: const TextInputType
                                                                          .numberWithOptions(
                                                                          decimal:
                                                                              true),
                                                                      cursorColor:
                                                                          Colors
                                                                              .black,
                                                                      validator: _model
                                                                          .prodSalepriceTextControllerValidator
                                                                          .asValidator(
                                                                              context),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Stack(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, 0.0),
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            26.0),
                                                                child:
                                                                    Container(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      0.9,
                                                                  child:
                                                                      TextFormField(
                                                                    controller:
                                                                        _model
                                                                            .productsTagsTextController,
                                                                    focusNode:
                                                                        _model
                                                                            .productsTagsFocusNode,
                                                                    onFieldSubmitted:
                                                                        (_) async {
                                                                      _model.addToTagList(_model
                                                                          .productsTagsTextController
                                                                          .text);
                                                                      safeSetState(
                                                                          () {});
                                                                      safeSetState(
                                                                          () {
                                                                        _model
                                                                            .productsTagsTextController
                                                                            ?.clear();
                                                                      });
                                                                    },
                                                                    autofocus:
                                                                        false,
                                                                    textInputAction:
                                                                        TextInputAction
                                                                            .done,
                                                                    obscureText:
                                                                        false,
                                                                    decoration:
                                                                        InputDecoration(
                                                                      isDense:
                                                                          true,
                                                                      labelStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .labelMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Sen',
                                                                            color:
                                                                                Color(0xFFBDBDBD),
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                      hintText:
                                                                          'Tags',
                                                                      hintStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .labelMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Sen',
                                                                            color:
                                                                                Color(0xFFBDBDBD),
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                      enabledBorder:
                                                                          OutlineInputBorder(
                                                                        borderSide:
                                                                            BorderSide(
                                                                          color:
                                                                              Color(0xFFDCDCDC),
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(10.0),
                                                                      ),
                                                                      focusedBorder:
                                                                          OutlineInputBorder(
                                                                        borderSide:
                                                                            BorderSide(
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(10.0),
                                                                      ),
                                                                      errorBorder:
                                                                          OutlineInputBorder(
                                                                        borderSide:
                                                                            BorderSide(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).error,
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(10.0),
                                                                      ),
                                                                      focusedErrorBorder:
                                                                          OutlineInputBorder(
                                                                        borderSide:
                                                                            BorderSide(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).error,
                                                                          width:
                                                                              1.0,
                                                                        ),
                                                                        borderRadius:
                                                                            BorderRadius.circular(10.0),
                                                                      ),
                                                                      filled:
                                                                          true,
                                                                      fillColor:
                                                                          Colors
                                                                              .white,
                                                                    ),
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF464646),
                                                                          fontSize:
                                                                              18.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                    maxLines: 3,
                                                                    cursorColor:
                                                                        Colors
                                                                            .black,
                                                                    validator: _model
                                                                        .productsTagsTextControllerValidator
                                                                        .asValidator(
                                                                            context),
                                                                  ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            20.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                child:
                                                                    FlutterFlowChoiceChips(
                                                                  options: _model
                                                                      .tagList
                                                                      .map((label) =>
                                                                          ChipData(
                                                                              label))
                                                                      .toList(),
                                                                  onChanged:
                                                                      (val) async {
                                                                    safeSetState(() =>
                                                                        _model.choiceChipsValue =
                                                                            val?.firstOrNull);
                                                                    _model.removeFromTagList(
                                                                        _model
                                                                            .choiceChipsValue!);
                                                                    safeSetState(
                                                                        () {});
                                                                  },
                                                                  selectedChipStyle:
                                                                      ChipStyle(
                                                                    backgroundColor:
                                                                        Color(
                                                                            0x00000000),
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF464646),
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                    iconColor:
                                                                        FlutterFlowTheme.of(context)
                                                                            .info,
                                                                    iconSize:
                                                                        16.0,
                                                                    elevation:
                                                                        0.0,
                                                                    borderColor:
                                                                        Color(
                                                                            0xFFDCDCDC),
                                                                    borderWidth:
                                                                        1.0,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  unselectedChipStyle:
                                                                      ChipStyle(
                                                                    backgroundColor:
                                                                        Color(
                                                                            0x00000000),
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFF464646),
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                    iconColor:
                                                                        Color(
                                                                            0xFF464646),
                                                                    iconSize:
                                                                        16.0,
                                                                    elevation:
                                                                        0.0,
                                                                    borderColor:
                                                                        Color(
                                                                            0xFFDCDCDC),
                                                                    borderWidth:
                                                                        1.0,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  chipSpacing:
                                                                      8.0,
                                                                  rowSpacing:
                                                                      8.0,
                                                                  multiselect:
                                                                      false,
                                                                  alignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  controller: _model
                                                                          .choiceChipsValueController ??=
                                                                      FormFieldController<
                                                                          List<
                                                                              String>>(
                                                                    [],
                                                                  ),
                                                                  wrapped: true,
                                                                ),
                                                              ),
                                                              Align(
                                                                alignment:
                                                                    AlignmentDirectional(
                                                                        1.0,
                                                                        -1.0),
                                                                child: Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          10.0,
                                                                          10.0,
                                                                          60.0),
                                                                  child:
                                                                      FlutterFlowIconButton(
                                                                    borderRadius:
                                                                        50.0,
                                                                    buttonSize:
                                                                        40.0,
                                                                    fillColor:
                                                                        Color(
                                                                            0xFFFF7622),
                                                                    icon: Icon(
                                                                      Icons.add,
                                                                      color: Colors
                                                                          .white,
                                                                      size:
                                                                          25.0,
                                                                    ),
                                                                    showLoadingIndicator:
                                                                        true,
                                                                    onPressed:
                                                                        () async {
                                                                      _model.addToTagList(_model
                                                                          .productsTagsTextController
                                                                          .text);
                                                                      safeSetState(
                                                                          () {});
                                                                      safeSetState(
                                                                          () {
                                                                        _model
                                                                            .productsTagsTextController
                                                                            ?.clear();
                                                                      });
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        26.0),
                                                            child: Container(
                                                              width: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .width *
                                                                  0.9,
                                                              child:
                                                                  TextFormField(
                                                                controller: _model
                                                                    .productDeascrTextController,
                                                                focusNode: _model
                                                                    .productDeascrFocusNode,
                                                                autofocus:
                                                                    false,
                                                                obscureText:
                                                                    false,
                                                                decoration:
                                                                    InputDecoration(
                                                                  isDense: true,
                                                                  labelStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFFBDBDBD),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  hintText:
                                                                      'Description',
                                                                  hintStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFFBDBDBD),
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  enabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Color(
                                                                          0xFFDCDCDC),
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  focusedBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  errorBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .error,
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  focusedErrorBorder:
                                                                      OutlineInputBorder(
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .error,
                                                                      width:
                                                                          1.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10.0),
                                                                  ),
                                                                  filled: true,
                                                                  fillColor:
                                                                      Colors
                                                                          .white,
                                                                ),
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF464646),
                                                                      fontSize:
                                                                          18.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                                maxLines: 3,
                                                                cursorColor:
                                                                    Colors
                                                                        .black,
                                                                validator: _model
                                                                    .productDeascrTextControllerValidator
                                                                    .asValidator(
                                                                        context),
                                                              ),
                                                            ),
                                                          ),
                                                          if (widget!
                                                                  .producttype ==
                                                              'Products')
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          34.0),
                                                              child:
                                                                  FFButtonWidget(
                                                                onPressed:
                                                                    () async {
                                                                  if ((_model.startDate ==
                                                                          null) &&
                                                                      (_model.endDate ==
                                                                          null)) {
                                                                    await showDialog(
                                                                      context:
                                                                          context,
                                                                      builder:
                                                                          (alertDialogContext) {
                                                                        return AlertDialog(
                                                                          title:
                                                                              Text('Please select the offer date'),
                                                                          actions: [
                                                                            TextButton(
                                                                              onPressed: () => Navigator.pop(alertDialogContext),
                                                                              child: Text('Ok'),
                                                                            ),
                                                                          ],
                                                                        );
                                                                      },
                                                                    );
                                                                  } else {
                                                                    if (_model.formKey1.currentState ==
                                                                            null ||
                                                                        !_model
                                                                            .formKey1
                                                                            .currentState!
                                                                            .validate()) {
                                                                      return;
                                                                    }
                                                                    if (_model.uploadedLocalFile ==
                                                                            null ||
                                                                        (_model.uploadedLocalFile.bytes ??
                                                                                [])
                                                                            .isEmpty) {
                                                                      await showDialog(
                                                                        context:
                                                                            context,
                                                                        builder:
                                                                            (alertDialogContext) {
                                                                          return AlertDialog(
                                                                            title:
                                                                                Text('Please Upload Image'),
                                                                            actions: [
                                                                              TextButton(
                                                                                onPressed: () => Navigator.pop(alertDialogContext),
                                                                                child: Text('Ok'),
                                                                              ),
                                                                            ],
                                                                          );
                                                                        },
                                                                      );
                                                                      return;
                                                                    }
                                                                    if (_model.formKey2.currentState ==
                                                                            null ||
                                                                        !_model
                                                                            .formKey2
                                                                            .currentState!
                                                                            .validate()) {
                                                                      return;
                                                                    }
                                                                    if (_model
                                                                            .offertypeValue ==
                                                                        null) {
                                                                      return;
                                                                    }

                                                                    var offersCollectionRecordReference = OffersCollectionRecord
                                                                        .collection
                                                                        .doc(_model
                                                                            .offeridTextController
                                                                            .text);
                                                                    await offersCollectionRecordReference
                                                                        .set({
                                                                      ...createOffersCollectionRecordData(
                                                                        offerTitle: _model
                                                                            .productnameTextController
                                                                            .text,
                                                                        offerPrice: int.tryParse(_model
                                                                            .prodSalepriceTextController
                                                                            .text),
                                                                        regularPrice: int.tryParse(_model
                                                                            .prodRegularPriceTextController
                                                                            .text),
                                                                        offferShortDescription: _model
                                                                            .productDeascrTextController
                                                                            .text,
                                                                        offrImage:
                                                                            _model.uploadedFileUrl,
                                                                        vendorId:
                                                                            offeraddingpageVendorDetailsRecord?.vendorId,
                                                                        offerStatus:
                                                                            'Draft',
                                                                        vendorName:
                                                                            offeraddingpageVendorDetailsRecord?.businessName,
                                                                        offerType:
                                                                            _model.offertypeValue,
                                                                        vendRef: widget!
                                                                            .vendref
                                                                            ?.reference,
                                                                        offerCreatedDate:
                                                                            getCurrentTimestamp,
                                                                      ),
                                                                      ...mapToFirestore(
                                                                        {
                                                                          'Tags':
                                                                              _model.tagList,
                                                                        },
                                                                      ),
                                                                    });
                                                                    _model.productCreatedraft =
                                                                        OffersCollectionRecord
                                                                            .getDocumentFromData({
                                                                      ...createOffersCollectionRecordData(
                                                                        offerTitle: _model
                                                                            .productnameTextController
                                                                            .text,
                                                                        offerPrice: int.tryParse(_model
                                                                            .prodSalepriceTextController
                                                                            .text),
                                                                        regularPrice: int.tryParse(_model
                                                                            .prodRegularPriceTextController
                                                                            .text),
                                                                        offferShortDescription: _model
                                                                            .productDeascrTextController
                                                                            .text,
                                                                        offrImage:
                                                                            _model.uploadedFileUrl,
                                                                        vendorId:
                                                                            offeraddingpageVendorDetailsRecord?.vendorId,
                                                                        offerStatus:
                                                                            'Draft',
                                                                        vendorName:
                                                                            offeraddingpageVendorDetailsRecord?.businessName,
                                                                        offerType:
                                                                            _model.offertypeValue,
                                                                        vendRef: widget!
                                                                            .vendref
                                                                            ?.reference,
                                                                        offerCreatedDate:
                                                                            getCurrentTimestamp,
                                                                      ),
                                                                      ...mapToFirestore(
                                                                        {
                                                                          'Tags':
                                                                              _model.tagList,
                                                                        },
                                                                      ),
                                                                    }, offersCollectionRecordReference);
                                                                    if (_model
                                                                            .offertypeValue ==
                                                                        'Products') {
                                                                      await _model
                                                                          .productCreatedraft!
                                                                          .reference
                                                                          .update(
                                                                              createOffersCollectionRecordData(
                                                                        offerCategory:
                                                                            _model.cateDropDownValue,
                                                                        offerNumber:
                                                                            'O-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
                                                                          random_data.randomInteger(
                                                                              0,
                                                                              1000),
                                                                          formatType:
                                                                              FormatType.custom,
                                                                          format:
                                                                              '-',
                                                                          locale:
                                                                              '',
                                                                        )}',
                                                                      ));
                                                                    } else {
                                                                      await _model
                                                                          .productCreatedraft!
                                                                          .reference
                                                                          .update({
                                                                        ...createOffersCollectionRecordData(
                                                                          offerNumber:
                                                                              'AP-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
                                                                            random_data.randomInteger(0,
                                                                                1000),
                                                                            formatType:
                                                                                FormatType.custom,
                                                                            format:
                                                                                '-',
                                                                            locale:
                                                                                '',
                                                                          )}',
                                                                        ),
                                                                        ...mapToFirestore(
                                                                          {
                                                                            'startTimeStr':
                                                                                _model.startTime.map((e) => dateTimeFormat("jm", e)).toList(),
                                                                          },
                                                                        ),
                                                                      });
                                                                    }

                                                                    safeSetState(
                                                                        () {
                                                                      _model
                                                                          .offertypeValueController
                                                                          ?.reset();
                                                                      _model
                                                                          .cateDropDownValueController
                                                                          ?.reset();
                                                                    });
                                                                    safeSetState(
                                                                        () {
                                                                      _model
                                                                          .choiceChipsValueController
                                                                          ?.reset();
                                                                    });
                                                                    safeSetState(
                                                                        () {
                                                                      _model.offeridTextController
                                                                              ?.text =
                                                                          'O-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
                                                                        random_data.randomInteger(
                                                                            0,
                                                                            1000),
                                                                        formatType:
                                                                            FormatType.custom,
                                                                        format:
                                                                            '-',
                                                                        locale:
                                                                            '',
                                                                      )}';

                                                                      _model
                                                                          .prodSalepriceTextController
                                                                          ?.clear();
                                                                      _model
                                                                          .productsTagsTextController
                                                                          ?.clear();
                                                                      _model
                                                                          .prodRegularPriceTextController
                                                                          ?.clear();
                                                                      _model
                                                                          .productDeascrTextController
                                                                          ?.clear();
                                                                      _model
                                                                          .productnameTextController
                                                                          ?.clear();
                                                                    });
                                                                    safeSetState(
                                                                        () {
                                                                      _model.isDataUploading =
                                                                          false;
                                                                      _model.uploadedLocalFile =
                                                                          FFUploadedFile(
                                                                              bytes: Uint8List.fromList([]));
                                                                      _model.uploadedFileUrl =
                                                                          '';
                                                                    });

                                                                    _model.tagList =
                                                                        [];
                                                                    safeSetState(
                                                                        () {});
                                                                    ScaffoldMessenger.of(
                                                                            context)
                                                                        .showSnackBar(
                                                                      SnackBar(
                                                                        content:
                                                                            Text(
                                                                          'Offer added succesfully',
                                                                          style:
                                                                              GoogleFonts.getFont(
                                                                            'Poppins',
                                                                            color:
                                                                                Color(0xFF7C7C7C),
                                                                            fontWeight:
                                                                                FontWeight.w500,
                                                                            fontSize:
                                                                                18.0,
                                                                          ),
                                                                        ),
                                                                        duration:
                                                                            Duration(milliseconds: 4000),
                                                                        backgroundColor:
                                                                            FlutterFlowTheme.of(context).secondary,
                                                                      ),
                                                                    );
                                                                    if (_model
                                                                            .offertypeValue ==
                                                                        'Products') {
                                                                      context.pushNamed(
                                                                          OfferListingPageWidget
                                                                              .routeName);
                                                                    } else {
                                                                      context.pushNamed(
                                                                          ServiceListspageWidget
                                                                              .routeName);
                                                                    }
                                                                  }

                                                                  safeSetState(
                                                                      () {});
                                                                },
                                                                text:
                                                                    'Save to drafts',
                                                                options:
                                                                    FFButtonOptions(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      0.9,
                                                                  height: 45.0,
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          16.0,
                                                                          0.0,
                                                                          16.0,
                                                                          0.0),
                                                                  iconPadding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  color: Colors
                                                                      .white,
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFF7C7C7C),
                                                                        fontSize:
                                                                            18.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.normal,
                                                                      ),
                                                                  elevation:
                                                                      0.0,
                                                                  borderSide:
                                                                      BorderSide(
                                                                    color: Color(
                                                                        0xFFDCDCDC),
                                                                    width: 1.0,
                                                                  ),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10.0),
                                                                ),
                                                              ),
                                                            ),
                                                          FutureBuilder<int>(
                                                            future:
                                                                queryOffersCollectionRecordCount(
                                                              queryBuilder:
                                                                  (offersCollectionRecord) =>
                                                                      offersCollectionRecord
                                                                          .where(
                                                                'Vendor_id',
                                                                isEqualTo:
                                                                    offeraddingpageVendorDetailsRecord
                                                                        ?.vendorId,
                                                              ),
                                                            ),
                                                            builder: (context,
                                                                snapshot) {
                                                              // Customize what your widget looks like when it's loading.
                                                              if (!snapshot
                                                                  .hasData) {
                                                                return Center(
                                                                  child:
                                                                      SizedBox(
                                                                    width: 60.0,
                                                                    height:
                                                                        60.0,
                                                                    child:
                                                                        SpinKitRipple(
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      size:
                                                                          60.0,
                                                                    ),
                                                                  ),
                                                                );
                                                              }
                                                              int containerCount =
                                                                  snapshot
                                                                      .data!;

                                                              return Container(
                                                                decoration:
                                                                    BoxDecoration(),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    FFButtonWidget(
                                                                      onPressed: () {
                                                                        if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                                'Vendor Free Plan') &&
                                                                            (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                                containerCount
                                                                                    .toString())) {
                                                                          return true;
                                                                        } else if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                                'Vendor Starter Plan') &&
                                                                            (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                                containerCount
                                                                                    .toString())) {
                                                                          return true;
                                                                        } else if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                                'Vendor Growth Plan') &&
                                                                            (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                                containerCount
                                                                                    .toString())) {
                                                                          return true;
                                                                        } else if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                                'Vendor Premium Plan') &&
                                                                            (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                                containerCount.toString())) {
                                                                          return true;
                                                                        } else {
                                                                          return false;
                                                                        }
                                                                      }()
                                                                          ? null
                                                                          : () async {
                                                                              if ((_model.startDate == null) && (_model.endDate == null)) {
                                                                                await showDialog(
                                                                                  context: context,
                                                                                  builder: (alertDialogContext) {
                                                                                    return AlertDialog(
                                                                                      title: Text('Please select the offer date'),
                                                                                      actions: [
                                                                                        TextButton(
                                                                                          onPressed: () => Navigator.pop(alertDialogContext),
                                                                                          child: Text('Ok'),
                                                                                        ),
                                                                                      ],
                                                                                    );
                                                                                  },
                                                                                );
                                                                              } else {
                                                                                if (_model.formKey1.currentState == null || !_model.formKey1.currentState!.validate()) {
                                                                                  return;
                                                                                }
                                                                                if (_model.uploadedLocalFile == null || (_model.uploadedLocalFile.bytes ?? []).isEmpty) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Please Upload Image'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  return;
                                                                                }
                                                                                if (_model.formKey2.currentState == null || !_model.formKey2.currentState!.validate()) {
                                                                                  return;
                                                                                }
                                                                                if (_model.offertypeValue == null) {
                                                                                  return;
                                                                                }

                                                                                var offersCollectionRecordReference = OffersCollectionRecord.collection.doc(_model.offeridTextController.text);
                                                                                await offersCollectionRecordReference.set({
                                                                                  ...createOffersCollectionRecordData(
                                                                                    offerTitle: _model.productnameTextController.text,
                                                                                    offerPrice: int.tryParse(_model.prodSalepriceTextController.text),
                                                                                    regularPrice: int.tryParse(_model.prodRegularPriceTextController.text),
                                                                                    offferShortDescription: _model.productDeascrTextController.text,
                                                                                    offerPublisheDate: _model.startDate,
                                                                                    offrImage: _model.uploadedFileUrl,
                                                                                    vendorId: offeraddingpageVendorDetailsRecord?.vendorId,
                                                                                    offerStatus: 'Live',
                                                                                    vendorName: offeraddingpageVendorDetailsRecord?.businessName,
                                                                                    offerExpiryDate: _model.endDate,
                                                                                    offerType: _model.offertypeValue,
                                                                                    vendRef: widget!.vendref?.reference,
                                                                                    offerCreatedDate: getCurrentTimestamp,
                                                                                  ),
                                                                                  ...mapToFirestore(
                                                                                    {
                                                                                      'Tags': _model.tagList,
                                                                                    },
                                                                                  ),
                                                                                });
                                                                                _model.productCreate = OffersCollectionRecord.getDocumentFromData({
                                                                                  ...createOffersCollectionRecordData(
                                                                                    offerTitle: _model.productnameTextController.text,
                                                                                    offerPrice: int.tryParse(_model.prodSalepriceTextController.text),
                                                                                    regularPrice: int.tryParse(_model.prodRegularPriceTextController.text),
                                                                                    offferShortDescription: _model.productDeascrTextController.text,
                                                                                    offerPublisheDate: _model.startDate,
                                                                                    offrImage: _model.uploadedFileUrl,
                                                                                    vendorId: offeraddingpageVendorDetailsRecord?.vendorId,
                                                                                    offerStatus: 'Live',
                                                                                    vendorName: offeraddingpageVendorDetailsRecord?.businessName,
                                                                                    offerExpiryDate: _model.endDate,
                                                                                    offerType: _model.offertypeValue,
                                                                                    vendRef: widget!.vendref?.reference,
                                                                                    offerCreatedDate: getCurrentTimestamp,
                                                                                  ),
                                                                                  ...mapToFirestore(
                                                                                    {
                                                                                      'Tags': _model.tagList,
                                                                                    },
                                                                                  ),
                                                                                }, offersCollectionRecordReference);

                                                                                await ReleaseNotificationRecord.createDoc(widget!.vendref!.reference).set(createReleaseNotificationRecordData(
                                                                                  notiInfo: _model.productCreate?.offerTitle,
                                                                                  notiCreated: getCurrentTimestamp,
                                                                                  createdBy: widget!.vendref?.reference,
                                                                                  vendId: offeraddingpageVendorDetailsRecord?.vendorId,
                                                                                  offerImage: _model.productCreate?.offrImage,
                                                                                  offerRef: _model.productCreate?.reference,
                                                                                  offerName: _model.productCreate?.offerTitle,
                                                                                  vendName: offeraddingpageVendorDetailsRecord?.businessName,
                                                                                  offerStartDate: _model.productCreate?.offerPublisheDate,
                                                                                ));
                                                                                if (_model.productCreate?.offerType == 'Products') {
                                                                                  await _model.productCreate!.reference.update(createOffersCollectionRecordData(
                                                                                    offerCategory: _model.cateDropDownValue,
                                                                                    offerNumber: _model.offeridTextController.text,
                                                                                  ));
                                                                                } else {
                                                                                  await _model.productCreate!.reference.update({
                                                                                    ...createOffersCollectionRecordData(
                                                                                      offerNumber: _model.offeridTextController.text,
                                                                                    ),
                                                                                    ...mapToFirestore(
                                                                                      {
                                                                                        'startTimeStr': _model.startTime.map((e) => dateTimeFormat("jm", e)).toList(),
                                                                                      },
                                                                                    ),
                                                                                  });
                                                                                  await actions.createServiceSlotsAction(
                                                                                    _model.startTime.map((e) => dateTimeFormat("jm", e)).toList(),
                                                                                    widget!.vendref!.reference,
                                                                                    _model.productCreate!.reference,
                                                                                    _model.productCreate!.offerExpiryDate!,
                                                                                  );
                                                                                }

                                                                                safeSetState(() {
                                                                                  _model.offertypeValueController?.reset();
                                                                                  _model.cateDropDownValueController?.reset();
                                                                                });
                                                                                safeSetState(() {
                                                                                  _model.choiceChipsValueController?.reset();
                                                                                });
                                                                                safeSetState(() {
                                                                                  _model.offeridTextController?.text = 'O-${dateTimeFormat("yyMM", getCurrentTimestamp)}${formatNumber(
                                                                                    random_data.randomInteger(0, 1000),
                                                                                    formatType: FormatType.custom,
                                                                                    format: '-',
                                                                                    locale: '',
                                                                                  )}';

                                                                                  _model.prodSalepriceTextController?.clear();
                                                                                  _model.productsTagsTextController?.clear();
                                                                                  _model.prodRegularPriceTextController?.clear();
                                                                                  _model.productDeascrTextController?.clear();
                                                                                  _model.productnameTextController?.clear();
                                                                                });
                                                                                safeSetState(() {
                                                                                  _model.isDataUploading = false;
                                                                                  _model.uploadedLocalFile = FFUploadedFile(bytes: Uint8List.fromList([]));
                                                                                  _model.uploadedFileUrl = '';
                                                                                });

                                                                                _model.tagList = [];
                                                                                safeSetState(() {});
                                                                                ScaffoldMessenger.of(context).showSnackBar(
                                                                                  SnackBar(
                                                                                    content: Text(
                                                                                      'Offer added succesfully',
                                                                                      style: GoogleFonts.getFont(
                                                                                        'Poppins',
                                                                                        color: Color(0xFF7C7C7C),
                                                                                        fontWeight: FontWeight.w500,
                                                                                        fontSize: 18.0,
                                                                                      ),
                                                                                    ),
                                                                                    duration: Duration(milliseconds: 4000),
                                                                                    backgroundColor: FlutterFlowTheme.of(context).secondary,
                                                                                  ),
                                                                                );
                                                                                if (_model.offertypeValue == 'Products') {
                                                                                  context.pushNamed(OfferListingPageWidget.routeName);
                                                                                } else {
                                                                                  context.pushNamed(ServiceListspageWidget.routeName);
                                                                                }
                                                                              }

                                                                              safeSetState(() {});
                                                                            },
                                                                      text: widget!.producttype ==
                                                                              'Services'
                                                                          ? 'Publish Service'
                                                                          : 'Publish Product',
                                                                      options:
                                                                          FFButtonOptions(
                                                                        width: MediaQuery.sizeOf(context).width *
                                                                            0.9,
                                                                        height:
                                                                            45.0,
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        color: Color(
                                                                            0xFFFF7622),
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .titleSmall
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Colors.white,
                                                                              fontSize: 18.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.w500,
                                                                            ),
                                                                        elevation:
                                                                            0.8,
                                                                        borderRadius:
                                                                            BorderRadius.circular(10.0),
                                                                        disabledColor:
                                                                            Color(0xFF7C7C7C),
                                                                        disabledTextColor:
                                                                            Colors.white,
                                                                      ),
                                                                    ),
                                                                    if (() {
                                                                      if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                              'Vendor Free Plan') &&
                                                                          (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                              containerCount
                                                                                  .toString())) {
                                                                        return true;
                                                                      } else if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                              'Vendor Starter Plan') &&
                                                                          (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                              containerCount
                                                                                  .toString())) {
                                                                        return true;
                                                                      } else if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                              'Vendor Growth Plan') &&
                                                                          (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                              containerCount
                                                                                  .toString())) {
                                                                        return true;
                                                                      } else if ((offeraddingpageVendorDetailsRecord?.subsPackname ==
                                                                              'Vendor Premium Plan') &&
                                                                          (offeraddingpageVendorDetailsRecord?.offerLimit ==
                                                                              containerCount.toString())) {
                                                                        return true;
                                                                      } else {
                                                                        return false;
                                                                      }
                                                                    }())
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            10.0,
                                                                            10.0,
                                                                            0.0),
                                                                        child:
                                                                            Text(
                                                                          'Please Upgrade The plan',
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .override(
                                                                                fontFamily: 'Sen',
                                                                                color: Color(0xFF464646),
                                                                                fontSize: 16.0,
                                                                                letterSpacing: 0.0,
                                                                              ),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              );
                                                            },
                                                          ),
                                                          Opacity(
                                                            opacity: 0.0,
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          26.0),
                                                              child:
                                                                  FlutterFlowDropDown<
                                                                      String>(
                                                                controller: _model
                                                                        .offertypeValueController ??=
                                                                    FormFieldController<
                                                                        String>(
                                                                  _model.offertypeValue ??=
                                                                      widget!
                                                                          .producttype,
                                                                ),
                                                                options: [
                                                                  'Products',
                                                                  'Services'
                                                                ],
                                                                onChanged: (val) =>
                                                                    safeSetState(() =>
                                                                        _model.offertypeValue =
                                                                            val),
                                                                width: MediaQuery.sizeOf(
                                                                            context)
                                                                        .width *
                                                                    1.0,
                                                                height: 50.0,
                                                                textStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF464646),
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                                hintText:
                                                                    'Select Product type',
                                                                icon: Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_rounded,
                                                                  color: Color(
                                                                      0xFF464646),
                                                                  size: 30.0,
                                                                ),
                                                                fillColor: Color(
                                                                    0xFFDCDCDC),
                                                                elevation: 0.0,
                                                                borderColor: Color(
                                                                    0xFFDCDCDC),
                                                                borderWidth:
                                                                    1.0,
                                                                borderRadius:
                                                                    10.0,
                                                                margin: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        12.0,
                                                                        0.0,
                                                                        12.0,
                                                                        0.0),
                                                                hidesUnderline:
                                                                    true,
                                                                disabled: widget!
                                                                            .producttype !=
                                                                        null &&
                                                                    widget!.producttype !=
                                                                        '',
                                                                isOverButton:
                                                                    false,
                                                                isSearchable:
                                                                    false,
                                                                isMultiSelect:
                                                                    false,
                                                              ),
                                                            ),
                                                          ),
                                                          Opacity(
                                                            opacity: 0.0,
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          26.0),
                                                              child: Container(
                                                                width: MediaQuery.sizeOf(
                                                                            context)
                                                                        .width *
                                                                    0.9,
                                                                child:
                                                                    TextFormField(
                                                                  controller: _model
                                                                      .offeridTextController,
                                                                  focusNode: _model
                                                                      .offeridFocusNode,
                                                                  autofocus:
                                                                      false,
                                                                  readOnly:
                                                                      true,
                                                                  obscureText:
                                                                      false,
                                                                  decoration:
                                                                      InputDecoration(
                                                                    isDense:
                                                                        true,
                                                                    labelStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .labelMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFFBDBDBD),
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                    hintText:
                                                                        'Name Of Product',
                                                                    hintStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .labelMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Sen',
                                                                          color:
                                                                              Color(0xFFBDBDBD),
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                    enabledBorder:
                                                                        OutlineInputBorder(
                                                                      borderSide:
                                                                          BorderSide(
                                                                        color: Color(
                                                                            0xFFDCDCDC),
                                                                        width:
                                                                            1.0,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10.0),
                                                                    ),
                                                                    focusedBorder:
                                                                        OutlineInputBorder(
                                                                      borderSide:
                                                                          BorderSide(
                                                                        color: Color(
                                                                            0xFFDCDCDC),
                                                                        width:
                                                                            1.0,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10.0),
                                                                    ),
                                                                    errorBorder:
                                                                        OutlineInputBorder(
                                                                      borderSide:
                                                                          BorderSide(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .error,
                                                                        width:
                                                                            1.0,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10.0),
                                                                    ),
                                                                    focusedErrorBorder:
                                                                        OutlineInputBorder(
                                                                      borderSide:
                                                                          BorderSide(
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .error,
                                                                        width:
                                                                            1.0,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10.0),
                                                                    ),
                                                                    filled:
                                                                        true,
                                                                    fillColor:
                                                                        Colors
                                                                            .white,
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Sen',
                                                                        color: Color(
                                                                            0xFF464646),
                                                                        fontSize:
                                                                            18.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  cursorColor:
                                                                      Colors
                                                                          .black,
                                                                  validator: _model
                                                                      .offeridTextControllerValidator
                                                                      .asValidator(
                                                                          context),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ));
      },
    );
  }
}
