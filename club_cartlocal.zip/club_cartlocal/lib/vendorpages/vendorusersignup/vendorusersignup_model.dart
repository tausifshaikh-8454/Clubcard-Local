import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/index.dart';
import 'vendorusersignup_widget.dart' show VendorusersignupWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendorusersignupModel extends FlutterFlowModel<VendorusersignupWidget> {
  ///  Local state fields for this page.

  String? phoneNumber;

  String? uniqueid = '';

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // Stores action output result for [Custom Action - generateUniqueUserId] action in vendorusersignup widget.
  String? uniVendId;
  // State field(s) for businessownername widget.
  FocusNode? businessownernameFocusNode;
  TextEditingController? businessownernameTextController;
  String? Function(BuildContext, String?)?
      businessownernameTextControllerValidator;
  String? _businessownernameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'SurName is required';
    }

    return null;
  }

  // State field(s) for businessownerSurname widget.
  FocusNode? businessownerSurnameFocusNode;
  TextEditingController? businessownerSurnameTextController;
  String? Function(BuildContext, String?)?
      businessownerSurnameTextControllerValidator;
  String? _businessownerSurnameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Name is required';
    }

    return null;
  }

  // State field(s) for Businessowneremail widget.
  FocusNode? businessowneremailFocusNode;
  TextEditingController? businessowneremailTextController;
  String? Function(BuildContext, String?)?
      businessowneremailTextControllerValidator;
  String? _businessowneremailTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Email is required';
    }

    return null;
  }

  // State field(s) for passwordforlogin widget.
  FocusNode? passwordforloginFocusNode;
  TextEditingController? passwordforloginTextController;
  late bool passwordforloginVisibility;
  String? Function(BuildContext, String?)?
      passwordforloginTextControllerValidator;
  String? _passwordforloginTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Password is required';
    }

    if (!RegExp(
            '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}\$')
        .hasMatch(val)) {
      return 'Your password must be at least 8 characters long \nand include an uppercase letter, \na lowercase letter, a number, and a special character';
    }
    return null;
  }

  // State field(s) for confrmpass widget.
  FocusNode? confrmpassFocusNode;
  TextEditingController? confrmpassTextController;
  late bool confrmpassVisibility;
  String? Function(BuildContext, String?)? confrmpassTextControllerValidator;
  String? _confrmpassTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Password is required';
    }

    if (!RegExp(
            '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}\$')
        .hasMatch(val)) {
      return 'Your password must be at least 8 characters long \nand include an uppercase letter,\na lowercase letter, a number, and a special character';
    }
    return null;
  }

  // State field(s) for Checkbox widget.
  bool? checkboxValue;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  VendorDetailsRecord? vendOutput;

  @override
  void initState(BuildContext context) {
    businessownernameTextControllerValidator =
        _businessownernameTextControllerValidator;
    businessownerSurnameTextControllerValidator =
        _businessownerSurnameTextControllerValidator;
    businessowneremailTextControllerValidator =
        _businessowneremailTextControllerValidator;
    passwordforloginVisibility = false;
    passwordforloginTextControllerValidator =
        _passwordforloginTextControllerValidator;
    confrmpassVisibility = false;
    confrmpassTextControllerValidator = _confrmpassTextControllerValidator;
  }

  @override
  void dispose() {
    businessownernameFocusNode?.dispose();
    businessownernameTextController?.dispose();

    businessownerSurnameFocusNode?.dispose();
    businessownerSurnameTextController?.dispose();

    businessowneremailFocusNode?.dispose();
    businessowneremailTextController?.dispose();

    passwordforloginFocusNode?.dispose();
    passwordforloginTextController?.dispose();

    confrmpassFocusNode?.dispose();
    confrmpassTextController?.dispose();
  }
}
