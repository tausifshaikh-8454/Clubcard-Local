import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'vend_subs_test_model.dart';
export 'vend_subs_test_model.dart';

class VendSubsTestWidget extends StatefulWidget {
  const VendSubsTestWidget({
    super.key,
    required this.vendref,
  });

  final DocumentReference? vendref;

  static String routeName = 'Vend-subs-test';
  static String routePath = '/Vend-subs-test';

  @override
  State<VendSubsTestWidget> createState() => _VendSubsTestWidgetState();
}

class _VendSubsTestWidgetState extends State<VendSubsTestWidget> {
  late VendSubsTestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VendSubsTestModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.uniqueid = await actions.generateUniqueUserId();
      _model.uniqusid = _model.uniqueid;
      safeSetState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Title(
        title: 'Vend-subs-test',
        color: FlutterFlowTheme.of(context).primary.withAlpha(0XFF),
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: Color(0xFFF1F4F8),
            body: SafeArea(
              top: true,
              child: Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Container(
                  width: MediaQuery.sizeOf(context).width * 1.0,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: MediaQuery.sizeOf(context).width * 1.0,
                          height: 350.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: Image.asset(
                                'assets/images/Signup-bg.webp',
                              ).image,
                            ),
                          ),
                          child: Align(
                            alignment: AlignmentDirectional(0.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Flexible(
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          20.0, 0.0, 20.0, 0.0),
                                      child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                        child: SvgPicture.asset(
                                          'assets/images/Logo.svg',
                                          width: 400.0,
                                          height: 150.0,
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsets.all(20.0),
                                  child: Text(
                                    'Choose Your Plan',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: Color(0xFF656565),
                                          fontSize: () {
                                            if (MediaQuery.sizeOf(context)
                                                    .width <
                                                kBreakpointSmall) {
                                              return 24.0;
                                            } else if (MediaQuery.sizeOf(
                                                        context)
                                                    .width <
                                                kBreakpointMedium) {
                                              return 24.0;
                                            } else if (MediaQuery.sizeOf(
                                                        context)
                                                    .width <
                                                kBreakpointLarge) {
                                              return 34.0;
                                            } else {
                                              return 44.0;
                                            }
                                          }(),
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                Align(
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 1.0,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 30.0),
                                          child: Wrap(
                                            spacing: 20.0,
                                            runSpacing: 20.0,
                                            alignment: WrapAlignment.center,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.start,
                                            direction: Axis.horizontal,
                                            runAlignment: WrapAlignment.start,
                                            verticalDirection:
                                                VerticalDirection.down,
                                            clipBehavior: Clip.none,
                                            children: [
                                              Container(
                                                width: 250.0,
                                                height: 420.0,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  boxShadow: [
                                                    BoxShadow(
                                                      blurRadius: 16.0,
                                                      color: Color(0x10000000),
                                                      offset: Offset(
                                                        4.0,
                                                        4.0,
                                                      ),
                                                    )
                                                  ],
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          14.0),
                                                  border: Border.all(
                                                    color: Color(0xFFDBDBDB),
                                                    width: 1.0,
                                                  ),
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      width: MediaQuery.sizeOf(
                                                                  context)
                                                              .width *
                                                          1.0,
                                                      height: 60.0,
                                                      decoration: BoxDecoration(
                                                        color:
                                                            Color(0xFFFF7622),
                                                        borderRadius:
                                                            BorderRadius.only(
                                                          bottomLeft:
                                                              Radius.circular(
                                                                  0.0),
                                                          bottomRight:
                                                              Radius.circular(
                                                                  0.0),
                                                          topLeft:
                                                              Radius.circular(
                                                                  12.0),
                                                          topRight:
                                                              Radius.circular(
                                                                  12.0),
                                                        ),
                                                      ),
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.0, 0.0),
                                                      child: Text(
                                                        'Free Trial',
                                                        style: FlutterFlowTheme
                                                                .of(context)
                                                            .bodyMedium
                                                            .override(
                                                              fontFamily:
                                                                  'Poppins',
                                                              color:
                                                                  Colors.white,
                                                              fontSize: 24.0,
                                                              letterSpacing:
                                                                  0.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                            ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  15.0,
                                                                  0.0,
                                                                  15.0),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      AlignmentDirectional(
                                                                          0.0,
                                                                          -1.0),
                                                                  child: Icon(
                                                                    Icons
                                                                        .currency_pound_sharp,
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    size: 30.0,
                                                                  ),
                                                                ),
                                                                RichText(
                                                                  textScaler: MediaQuery.of(
                                                                          context)
                                                                      .textScaler,
                                                                  text:
                                                                      TextSpan(
                                                                    children: [
                                                                      TextSpan(
                                                                        text:
                                                                            '0',
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Color(0xFFFF7622),
                                                                              fontSize: 44.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.w600,
                                                                            ),
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            'per Month',
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              16.0,
                                                                        ),
                                                                      )
                                                                    ],
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          fontSize:
                                                                              44.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            Text(
                                                              '1 product for unlimited days',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Readex Pro',
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    fontSize:
                                                                        15.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                0.9,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          10.0),
                                                              child: Text(
                                                                'Features: ',
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF7C7C7C),
                                                                      fontSize:
                                                                          18.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Free Package: Promote your first product at no cost.\n\n A great way to experience our platform without any commitment.\n\n',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Sen',
                                                                    color: Color(
                                                                        0xFF7C7C7C),
                                                                    fontSize:
                                                                        12.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  14.0,
                                                                  0.0,
                                                                  14.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 1.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFDBDBDB),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          14.0,
                                                                          0.0,
                                                                          14.0),
                                                              child:
                                                                  AuthUserStreamWidget(
                                                                builder:
                                                                    (context) =>
                                                                        FFButtonWidget(
                                                                  onPressed:
                                                                      () async {
                                                                    var _shouldSetState =
                                                                        false;
                                                                    _model.custDataFree =
                                                                        await StripeGroup
                                                                            .createCustomerCall
                                                                            .call(
                                                                      email:
                                                                          currentUserEmail,
                                                                      name:
                                                                          currentUserDisplayName,
                                                                    );

                                                                    _shouldSetState =
                                                                        true;
                                                                    await Future
                                                                        .wait([
                                                                      Future(
                                                                          () async {
                                                                        await widget!
                                                                            .vendref!
                                                                            .update(createVendorDetailsRecordData(
                                                                          offerLimit:
                                                                              '1',
                                                                          subsPackname:
                                                                              'Vendor Free Plan',
                                                                        ));
                                                                      }),
                                                                      Future(
                                                                          () async {
                                                                        var subscriptionsRecordReference = SubscriptionsRecord
                                                                            .collection
                                                                            .doc();
                                                                        await subscriptionsRecordReference
                                                                            .set(createSubscriptionsRecordData(
                                                                          subscribUser:
                                                                              currentUserEmail,
                                                                          subsPackName:
                                                                              'Vendor Free Plan',
                                                                          subsAmount:
                                                                              0.00,
                                                                          subsCustId: StripeGroup
                                                                              .createCustomerCall
                                                                              .custid(
                                                                            (_model.custDataFree?.jsonBody ??
                                                                                ''),
                                                                          ),
                                                                        ));
                                                                        _model.subscrptionFreeDoc = SubscriptionsRecord.getDocumentFromData(
                                                                            createSubscriptionsRecordData(
                                                                              subscribUser: currentUserEmail,
                                                                              subsPackName: 'Vendor Free Plan',
                                                                              subsAmount: 0.00,
                                                                              subsCustId: StripeGroup.createCustomerCall.custid(
                                                                                (_model.custDataFree?.jsonBody ?? ''),
                                                                              ),
                                                                            ),
                                                                            subscriptionsRecordReference);
                                                                        _shouldSetState =
                                                                            true;
                                                                      }),
                                                                      Future(
                                                                          () async {
                                                                        await currentUserReference!
                                                                            .update(createUsersRecordData(
                                                                          subsPakName:
                                                                              'Vendor Free Plan',
                                                                        ));
                                                                      }),
                                                                    ]);
                                                                    if ((_model
                                                                            .custDataFree
                                                                            ?.succeeded ??
                                                                        true)) {
                                                                      _model.subscCreationFree = await StripeGroup
                                                                          .createSusbscriptionfreeCall
                                                                          .call(
                                                                        customer: _model
                                                                            .subscrptionFreeDoc
                                                                            ?.subsCustId,
                                                                        priceID:
                                                                            'price_1QQMYgL3aBEbReILFcntUECp',
                                                                      );

                                                                      _shouldSetState =
                                                                          true;

                                                                      await _model
                                                                          .subscrptionFreeDoc!
                                                                          .reference
                                                                          .update(
                                                                              createSubscriptionsRecordData(
                                                                        subsId: StripeGroup
                                                                            .createSusbscriptionfreeCall
                                                                            .subscriptionid(
                                                                          (_model.subscCreationFree?.jsonBody ??
                                                                              ''),
                                                                        ),
                                                                        subsItemId: StripeGroup
                                                                            .createSusbscriptionfreeCall
                                                                            .itemid(
                                                                          (_model.subscCreationFree?.jsonBody ??
                                                                              ''),
                                                                        ),
                                                                        productId: StripeGroup
                                                                            .createSusbscriptionfreeCall
                                                                            .productid(
                                                                          (_model.subscCreationFree?.jsonBody ??
                                                                              ''),
                                                                        ),
                                                                        subsPriceId: StripeGroup
                                                                            .createSusbscriptionfreeCall
                                                                            .priceid(
                                                                          (_model.subscCreationFree?.jsonBody ??
                                                                              ''),
                                                                        ),
                                                                      ));
                                                                    } else {
                                                                      if (_shouldSetState)
                                                                        safeSetState(
                                                                            () {});
                                                                      return;
                                                                    }

                                                                    context
                                                                        .goNamed(
                                                                      VendorDashboardWidget
                                                                          .routeName,
                                                                      queryParameters:
                                                                          {
                                                                        'venid':
                                                                            serializeParam(
                                                                          valueOrDefault(
                                                                              currentUserDocument?.userId,
                                                                              ''),
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                      }.withoutNulls,
                                                                    );

                                                                    if (_shouldSetState)
                                                                      safeSetState(
                                                                          () {});
                                                                  },
                                                                  text: valueOrDefault(
                                                                              currentUserDocument?.subsPakName,
                                                                              '') ==
                                                                          'Vendor Free Plan'
                                                                      ? 'Current Plan'
                                                                      : 'Start now',
                                                                  options:
                                                                      FFButtonOptions(
                                                                    width: MediaQuery.sizeOf(context)
                                                                            .width *
                                                                        0.9,
                                                                    height:
                                                                        40.0,
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                    iconPadding:
                                                                        EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              Colors.white,
                                                                          fontSize:
                                                                              20.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                    elevation:
                                                                        0.0,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            20.0),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                width: 250.0,
                                                height: 420.0,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  boxShadow: [
                                                    BoxShadow(
                                                      blurRadius: 16.0,
                                                      color: Color(0x10000000),
                                                      offset: Offset(
                                                        6.0,
                                                        6.0,
                                                      ),
                                                    )
                                                  ],
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12.0),
                                                  border: Border.all(
                                                    color: Color(0xFFDBDBDB),
                                                    width: 1.0,
                                                  ),
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.0, 0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 60.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFFF7622),
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            bottomLeft:
                                                                Radius.circular(
                                                                    0.0),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    0.0),
                                                            topLeft:
                                                                Radius.circular(
                                                                    12.0),
                                                            topRight:
                                                                Radius.circular(
                                                                    12.0),
                                                          ),
                                                        ),
                                                        child: Align(
                                                          alignment:
                                                              AlignmentDirectional(
                                                                  0.0, 0.0),
                                                          child: Text(
                                                            'Starter',
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      24.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  15.0,
                                                                  0.0,
                                                                  15.0),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Icon(
                                                                  Icons
                                                                      .currency_pound_sharp,
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  size: 30.0,
                                                                ),
                                                                RichText(
                                                                  textScaler: MediaQuery.of(
                                                                          context)
                                                                      .textScaler,
                                                                  text:
                                                                      TextSpan(
                                                                    children: [
                                                                      TextSpan(
                                                                        text:
                                                                            '9',
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Color(0xFFFF7622),
                                                                              fontSize: 44.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.w600,
                                                                            ),
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            '.99',
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              16.0,
                                                                        ),
                                                                      ),
                                                                      TextSpan(
                                                                        text:
                                                                            ' per Month',
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              16.0,
                                                                        ),
                                                                      )
                                                                    ],
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          fontSize:
                                                                              44.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            Text(
                                                              '3 products for unlimited days',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Readex Pro',
                                                                    color: Color(
                                                                        0xFFFF7622),
                                                                    fontSize:
                                                                        15.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                0.9,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          10.0),
                                                              child: Text(
                                                                'Features: ',
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF7C7C7C),
                                                                      fontSize:
                                                                          18.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'You can promote up to three products.\n\nThis package includes essential features to help increase your visibility.\n\n\n',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Sen',
                                                                    color: Color(
                                                                        0xFF7C7C7C),
                                                                    fontSize:
                                                                        12.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  14.0,
                                                                  0.0,
                                                                  14.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 1.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFDBDBDB),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          14.0,
                                                                          0.0,
                                                                          14.0),
                                                              child:
                                                                  FFButtonWidget(
                                                                onPressed:
                                                                    () async {
                                                                  _model.custDataStrtr =
                                                                      await StripeGroup
                                                                          .createCustomerCall
                                                                          .call(
                                                                    email:
                                                                        currentUserEmail,
                                                                    name:
                                                                        currentUserDisplayName,
                                                                  );

                                                                  await Future
                                                                      .wait([
                                                                    Future(
                                                                        () async {
                                                                      await widget!
                                                                          .vendref!
                                                                          .update(
                                                                              createVendorDetailsRecordData(
                                                                        offerLimit:
                                                                            '3',
                                                                        subsPackname:
                                                                            'Vendor Starter Plan',
                                                                      ));
                                                                    }),
                                                                    Future(
                                                                        () async {
                                                                      var subscriptionsRecordReference = SubscriptionsRecord
                                                                          .collection
                                                                          .doc();
                                                                      await subscriptionsRecordReference
                                                                          .set(
                                                                              createSubscriptionsRecordData(
                                                                        subscribUser:
                                                                            currentUserEmail,
                                                                        subsPackName:
                                                                            'Vendor Starter Plan',
                                                                        subsAmount:
                                                                            9.99,
                                                                        subsCustId: StripeGroup
                                                                            .createCustomerCall
                                                                            .custid(
                                                                          (_model.custDataStrtr?.jsonBody ??
                                                                              ''),
                                                                        ),
                                                                      ));
                                                                      _model.subscrptionStrtr = SubscriptionsRecord.getDocumentFromData(
                                                                          createSubscriptionsRecordData(
                                                                            subscribUser:
                                                                                currentUserEmail,
                                                                            subsPackName:
                                                                                'Vendor Starter Plan',
                                                                            subsAmount:
                                                                                9.99,
                                                                            subsCustId:
                                                                                StripeGroup.createCustomerCall.custid(
                                                                              (_model.custDataStrtr?.jsonBody ?? ''),
                                                                            ),
                                                                          ),
                                                                          subscriptionsRecordReference);
                                                                    }),
                                                                    Future(
                                                                        () async {
                                                                      await currentUserReference!
                                                                          .update(
                                                                              createUsersRecordData(
                                                                        subsPakName:
                                                                            'Vendor Starter Plan',
                                                                      ));
                                                                    }),
                                                                  ]);
                                                                  if ((_model
                                                                          .custDataStrtr
                                                                          ?.succeeded ??
                                                                      true)) {
                                                                    _model.chrgeUserStrter =
                                                                        await StripeGroup
                                                                            .checkOutSessionsCall
                                                                            .call(
                                                                      customer: _model
                                                                          .subscrptionStrtr
                                                                          ?.subsCustId,
                                                                      mode:
                                                                          'subscription',
                                                                      quantity:
                                                                          1,
                                                                      key:
                                                                          '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',
                                                                      successUrl:
                                                                          'https://app.clubcardlocal.com/vendsuccess',
                                                                      cancelUrl:
                                                                          'https://app.clubcardlocal.com/vendPaymentfailed',
                                                                      priceID:
                                                                          'price_1QQMYlL3aBEbReILX0X7iCdR',
                                                                    );

                                                                    await _model
                                                                        .subscrptionStrtr!
                                                                        .reference
                                                                        .update(
                                                                            createSubscriptionsRecordData(
                                                                      subscSessionid: StripeGroup
                                                                          .checkOutSessionsCall
                                                                          .sessionid(
                                                                        (_model.chrgeUserStrter?.jsonBody ??
                                                                            ''),
                                                                      ),
                                                                      paymentMethod:
                                                                          'Card',
                                                                      paymentStaus:
                                                                          'Paid',
                                                                    ));
                                                                    await launchURL(
                                                                        StripeGroup
                                                                            .checkOutSessionsCall
                                                                            .url(
                                                                      (_model.chrgeUserStrter
                                                                              ?.jsonBody ??
                                                                          ''),
                                                                    )!);
                                                                  } else {
                                                                    await showDialog(
                                                                      context:
                                                                          context,
                                                                      builder:
                                                                          (alertDialogContext) {
                                                                        return AlertDialog(
                                                                          title:
                                                                              Text('Not Charged'),
                                                                          actions: [
                                                                            TextButton(
                                                                              onPressed: () => Navigator.pop(alertDialogContext),
                                                                              child: Text('Ok'),
                                                                            ),
                                                                          ],
                                                                        );
                                                                      },
                                                                    );
                                                                  }

                                                                  safeSetState(
                                                                      () {});
                                                                },
                                                                text:
                                                                    'Start now',
                                                                options:
                                                                    FFButtonOptions(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      1.0,
                                                                  height: 40.0,
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          16.0,
                                                                          0.0,
                                                                          16.0,
                                                                          0.0),
                                                                  iconPadding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            20.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  elevation:
                                                                      0.0,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20.0),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                width: 250.0,
                                                height: 420.0,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  boxShadow: [
                                                    BoxShadow(
                                                      blurRadius: 16.0,
                                                      color: Color(0x10000000),
                                                      offset: Offset(
                                                        6.0,
                                                        6.0,
                                                      ),
                                                    )
                                                  ],
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12.0),
                                                  border: Border.all(
                                                    color: Color(0xFFDBDBDB),
                                                    width: 1.0,
                                                  ),
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.0, 0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 60.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFFF7622),
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            bottomLeft:
                                                                Radius.circular(
                                                                    0.0),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    0.0),
                                                            topLeft:
                                                                Radius.circular(
                                                                    12.0),
                                                            topRight:
                                                                Radius.circular(
                                                                    12.0),
                                                          ),
                                                        ),
                                                        child: Align(
                                                          alignment:
                                                              AlignmentDirectional(
                                                                  0.0, 0.0),
                                                          child: Text(
                                                            'Growth',
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      24.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  15.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                        ),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Icon(
                                                              Icons
                                                                  .currency_pound_sharp,
                                                              color: Color(
                                                                  0xFFFF7622),
                                                              size: 30.0,
                                                            ),
                                                            RichText(
                                                              textScaler:
                                                                  MediaQuery.of(
                                                                          context)
                                                                      .textScaler,
                                                              text: TextSpan(
                                                                children: [
                                                                  TextSpan(
                                                                    text: '19',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          fontSize:
                                                                              44.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                        ),
                                                                  ),
                                                                  TextSpan(
                                                                    text: '.99',
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          16.0,
                                                                    ),
                                                                  ),
                                                                  TextSpan(
                                                                    text:
                                                                        ' per Month',
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          16.0,
                                                                    ),
                                                                  )
                                                                ],
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Poppins',
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      fontSize:
                                                                          44.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                    ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      '8 products for unlimited days',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily:
                                                                'Readex Pro',
                                                            color: Color(
                                                                0xFFFF7622),
                                                            fontSize: 15.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  10.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                0.9,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          10.0),
                                                              child: Text(
                                                                'Features: ',
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF7C7C7C),
                                                                      fontSize:
                                                                          18.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Promote up to eight products.\n\nIncludes all features from the Starter Package.\n\nplus access to additional promotional options at preferential rates.',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Sen',
                                                                    color: Color(
                                                                        0xFF7C7C7C),
                                                                    fontSize:
                                                                        12.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  14.0,
                                                                  0.0,
                                                                  14.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 1.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFDBDBDB),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          14.0,
                                                                          0.0,
                                                                          14.0),
                                                              child:
                                                                  FFButtonWidget(
                                                                onPressed:
                                                                    () async {
                                                                  final firestoreBatch =
                                                                      FirebaseFirestore
                                                                          .instance
                                                                          .batch();
                                                                  try {
                                                                    _model.custDataGrwth =
                                                                        await StripeGroup
                                                                            .createCustomerCall
                                                                            .call(
                                                                      email:
                                                                          currentUserEmail,
                                                                      name:
                                                                          currentUserDisplayName,
                                                                    );

                                                                    await Future
                                                                        .wait([
                                                                      Future(
                                                                          () async {
                                                                        firestoreBatch.update(
                                                                            widget!.vendref!,
                                                                            createVendorDetailsRecordData(
                                                                              offerLimit: '8',
                                                                              subsPackname: 'Vendor Growth Plan',
                                                                            ));
                                                                      }),
                                                                      Future(
                                                                          () async {
                                                                        var subscriptionsRecordReference = SubscriptionsRecord
                                                                            .collection
                                                                            .doc();
                                                                        firestoreBatch.set(
                                                                            subscriptionsRecordReference,
                                                                            createSubscriptionsRecordData(
                                                                              subscribUser: currentUserEmail,
                                                                              subsAmount: 19.99,
                                                                              subsCustId: StripeGroup.createCustomerCall.custid(
                                                                                (_model.custDataGrwth?.jsonBody ?? ''),
                                                                              ),
                                                                              subsPackName: 'Vendor Growth Plan',
                                                                            ));
                                                                        _model.subscrpGrth = SubscriptionsRecord.getDocumentFromData(
                                                                            createSubscriptionsRecordData(
                                                                              subscribUser: currentUserEmail,
                                                                              subsAmount: 19.99,
                                                                              subsCustId: StripeGroup.createCustomerCall.custid(
                                                                                (_model.custDataGrwth?.jsonBody ?? ''),
                                                                              ),
                                                                              subsPackName: 'Vendor Growth Plan',
                                                                            ),
                                                                            subscriptionsRecordReference);
                                                                      }),
                                                                      Future(
                                                                          () async {
                                                                        firestoreBatch.update(
                                                                            currentUserReference!,
                                                                            createUsersRecordData(
                                                                              subsPakName: 'Vendor Growth Plan',
                                                                            ));
                                                                      }),
                                                                    ]);
                                                                    if ((_model
                                                                            .custDataGrwth
                                                                            ?.succeeded ??
                                                                        true)) {
                                                                      _model.chrgeUserGrwth = await StripeGroup
                                                                          .checkOutSessionsCall
                                                                          .call(
                                                                        customer: _model
                                                                            .subscrpGrth
                                                                            ?.subsCustId,
                                                                        mode:
                                                                            'subscription',
                                                                        quantity:
                                                                            1,
                                                                        key:
                                                                            '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',
                                                                        successUrl:
                                                                            'https://app.clubcardlocal.com/vendsuccess',
                                                                        cancelUrl:
                                                                            'https://app.clubcardlocal.com/vendPaymentfailed',
                                                                        priceID:
                                                                            'price_1QQMYiL3aBEbReILV2fEPPI9',
                                                                      );

                                                                      firestoreBatch.update(
                                                                          _model.subscrpGrth!.reference,
                                                                          createSubscriptionsRecordData(
                                                                            subscSessionid:
                                                                                StripeGroup.checkOutSessionsCall.sessionid(
                                                                              (_model.chrgeUserGrwth?.jsonBody ?? ''),
                                                                            ),
                                                                            paymentMethod:
                                                                                'Card',
                                                                            paymentStaus:
                                                                                'Paid',
                                                                          ));
                                                                      await launchURL(StripeGroup
                                                                          .checkOutSessionsCall
                                                                          .url(
                                                                        (_model.chrgeUserGrwth?.jsonBody ??
                                                                            ''),
                                                                      )!);
                                                                    } else {
                                                                      await showDialog(
                                                                        context:
                                                                            context,
                                                                        builder:
                                                                            (alertDialogContext) {
                                                                          return AlertDialog(
                                                                            title:
                                                                                Text('Not Charged'),
                                                                            actions: [
                                                                              TextButton(
                                                                                onPressed: () => Navigator.pop(alertDialogContext),
                                                                                child: Text('Ok'),
                                                                              ),
                                                                            ],
                                                                          );
                                                                        },
                                                                      );
                                                                    }
                                                                  } finally {
                                                                    await firestoreBatch
                                                                        .commit();
                                                                  }

                                                                  safeSetState(
                                                                      () {});
                                                                },
                                                                text:
                                                                    'Start now',
                                                                options:
                                                                    FFButtonOptions(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      1.0,
                                                                  height: 40.0,
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          16.0,
                                                                          0.0,
                                                                          16.0,
                                                                          0.0),
                                                                  iconPadding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            20.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  elevation:
                                                                      0.0,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20.0),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                width: 250.0,
                                                height: 420.0,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12.0),
                                                  border: Border.all(
                                                    color: Color(0xFFDBDBDB),
                                                    width: 1.0,
                                                  ),
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.0, 0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 60.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFFF7622),
                                                          borderRadius:
                                                              BorderRadius.only(
                                                            bottomLeft:
                                                                Radius.circular(
                                                                    0.0),
                                                            bottomRight:
                                                                Radius.circular(
                                                                    0.0),
                                                            topLeft:
                                                                Radius.circular(
                                                                    12.0),
                                                            topRight:
                                                                Radius.circular(
                                                                    12.0),
                                                          ),
                                                        ),
                                                        child: Align(
                                                          alignment:
                                                              AlignmentDirectional(
                                                                  0.0, 0.0),
                                                          child: Text(
                                                            'Premium',
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      24.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  14.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                        ),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Icon(
                                                              Icons
                                                                  .currency_pound_sharp,
                                                              color: Color(
                                                                  0xFFFF7622),
                                                              size: 30.0,
                                                            ),
                                                            RichText(
                                                              textScaler:
                                                                  MediaQuery.of(
                                                                          context)
                                                                      .textScaler,
                                                              text: TextSpan(
                                                                children: [
                                                                  TextSpan(
                                                                    text: '34',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              Color(0xFFFF7622),
                                                                          fontSize:
                                                                              44.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                        ),
                                                                  ),
                                                                  TextSpan(
                                                                    text: '.99',
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          16.0,
                                                                    ),
                                                                  ),
                                                                  TextSpan(
                                                                    text:
                                                                        ' per Month',
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          16.0,
                                                                    ),
                                                                  )
                                                                ],
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Poppins',
                                                                      color: Color(
                                                                          0xFFFF7622),
                                                                      fontSize:
                                                                          44.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                    ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      '15 products for unlimited days',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily:
                                                                'Readex Pro',
                                                            color: Color(
                                                                0xFFFF7622),
                                                            fontSize: 15.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  10.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                0.9,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          10.0),
                                                              child: Text(
                                                                'Features: ',
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Sen',
                                                                      color: Color(
                                                                          0xFF7C7C7C),
                                                                      fontSize:
                                                                          18.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'You can promote up to fifteen products.\n\nIncludes all features from the Growth Package.\n\n Making it ideal for vendors looking to maximize their presence.',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Sen',
                                                                    color: Color(
                                                                        0xFF7C7C7C),
                                                                    fontSize:
                                                                        12.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  14.0,
                                                                  0.0,
                                                                  14.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        height: 1.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color:
                                                              Color(0xFFDBDBDB),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: Container(
                                                        width:
                                                            MediaQuery.sizeOf(
                                                                        context)
                                                                    .width *
                                                                1.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          14.0,
                                                                          0.0,
                                                                          14.0),
                                                              child:
                                                                  FFButtonWidget(
                                                                onPressed:
                                                                    () async {
                                                                  final firestoreBatch =
                                                                      FirebaseFirestore
                                                                          .instance
                                                                          .batch();
                                                                  try {
                                                                    _model.createCustPrem =
                                                                        await StripeGroup
                                                                            .createCustomerCall
                                                                            .call(
                                                                      email:
                                                                          currentUserEmail,
                                                                      name:
                                                                          currentUserDisplayName,
                                                                    );

                                                                    await Future
                                                                        .wait([
                                                                      Future(
                                                                          () async {
                                                                        firestoreBatch.update(
                                                                            widget!.vendref!,
                                                                            createVendorDetailsRecordData(
                                                                              offerLimit: '15',
                                                                              subsPackname: 'Vendor Premium Plan',
                                                                            ));
                                                                      }),
                                                                      Future(
                                                                          () async {
                                                                        var subscriptionsRecordReference = SubscriptionsRecord
                                                                            .collection
                                                                            .doc();
                                                                        firestoreBatch.set(
                                                                            subscriptionsRecordReference,
                                                                            createSubscriptionsRecordData(
                                                                              subscribUser: currentUserEmail,
                                                                              subsPackName: 'Vendor Premium Plan',
                                                                              subsAmount: 34.99,
                                                                              subsCustId: StripeGroup.createCustomerCall.custid(
                                                                                (_model.createCustPrem?.jsonBody ?? ''),
                                                                              ),
                                                                            ));
                                                                        _model.subscriptionPremim = SubscriptionsRecord.getDocumentFromData(
                                                                            createSubscriptionsRecordData(
                                                                              subscribUser: currentUserEmail,
                                                                              subsPackName: 'Vendor Premium Plan',
                                                                              subsAmount: 34.99,
                                                                              subsCustId: StripeGroup.createCustomerCall.custid(
                                                                                (_model.createCustPrem?.jsonBody ?? ''),
                                                                              ),
                                                                            ),
                                                                            subscriptionsRecordReference);
                                                                      }),
                                                                      Future(
                                                                          () async {
                                                                        firestoreBatch.update(
                                                                            currentUserReference!,
                                                                            createUsersRecordData(
                                                                              subsPakName: 'Vendor Premium Plan',
                                                                            ));
                                                                      }),
                                                                    ]);
                                                                    if ((_model
                                                                            .createCustPrem
                                                                            ?.succeeded ??
                                                                        true)) {
                                                                      _model.chargeUserPrem = await StripeGroup
                                                                          .checkOutSessionsCall
                                                                          .call(
                                                                        customer: StripeGroup
                                                                            .createCustomerCall
                                                                            .custid(
                                                                          (_model.createCustPrem?.jsonBody ??
                                                                              ''),
                                                                        ),
                                                                        mode:
                                                                            'subscription',
                                                                        successUrl:
                                                                            'https://app.clubcardlocal.com/vendsuccess',
                                                                        cancelUrl:
                                                                            'https://app.clubcardlocal.com/vendpaymentfailed',
                                                                        priceID:
                                                                            'price_1QQMYdL3aBEbReILBWnsED1b',
                                                                        quantity:
                                                                            1,
                                                                        key:
                                                                            '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',
                                                                      );

                                                                      firestoreBatch.update(
                                                                          _model.subscriptionPremim!.reference,
                                                                          createSubscriptionsRecordData(
                                                                            subscSessionid:
                                                                                StripeGroup.checkOutSessionsCall.sessionid(
                                                                              (_model.chargeUserPrem?.jsonBody ?? ''),
                                                                            ),
                                                                            paymentMethod:
                                                                                'Card',
                                                                            paymentStaus:
                                                                                'Paid',
                                                                          ));
                                                                      await launchURL(StripeGroup
                                                                          .checkOutSessionsCall
                                                                          .url(
                                                                        (_model.chargeUserPrem?.jsonBody ??
                                                                            ''),
                                                                      )!);
                                                                    } else {
                                                                      await showDialog(
                                                                        context:
                                                                            context,
                                                                        builder:
                                                                            (alertDialogContext) {
                                                                          return AlertDialog(
                                                                            title:
                                                                                Text('Not charged'),
                                                                            actions: [
                                                                              TextButton(
                                                                                onPressed: () => Navigator.pop(alertDialogContext),
                                                                                child: Text('Ok'),
                                                                              ),
                                                                            ],
                                                                          );
                                                                        },
                                                                      );
                                                                    }
                                                                  } finally {
                                                                    await firestoreBatch
                                                                        .commit();
                                                                  }

                                                                  safeSetState(
                                                                      () {});
                                                                },
                                                                text:
                                                                    'Start now',
                                                                options:
                                                                    FFButtonOptions(
                                                                  width: MediaQuery.sizeOf(
                                                                              context)
                                                                          .width *
                                                                      1.0,
                                                                  height: 40.0,
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          16.0,
                                                                          0.0,
                                                                          16.0,
                                                                          0.0),
                                                                  iconPadding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  color: Color(
                                                                      0xFFFF7622),
                                                                  textStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            20.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                  elevation:
                                                                      0.0,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20.0),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
