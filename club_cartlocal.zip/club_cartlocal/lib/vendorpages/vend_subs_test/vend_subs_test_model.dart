import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'vend_subs_test_widget.dart' show VendSubsTestWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VendSubsTestModel extends FlutterFlowModel<VendSubsTestWidget> {
  ///  Local state fields for this page.

  String? subrurlparam;

  String? uniqusid = '';

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - generateUniqueUserId] action in Vend-subs-test widget.
  String? uniqueid;
  // Stores action output result for [Backend Call - API (CreateCustomer)] action in Button widget.
  ApiCallResponse? custDataFree;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  SubscriptionsRecord? subscrptionFreeDoc;
  // Stores action output result for [Backend Call - API (createSusbscriptionfree)] action in Button widget.
  ApiCallResponse? subscCreationFree;
  // Stores action output result for [Backend Call - API (CreateCustomer)] action in Button widget.
  ApiCallResponse? custDataStrtr;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  SubscriptionsRecord? subscrptionStrtr;
  // Stores action output result for [Backend Call - API (checkOutSessions)] action in Button widget.
  ApiCallResponse? chrgeUserStrter;
  // Stores action output result for [Backend Call - API (CreateCustomer)] action in Button widget.
  ApiCallResponse? custDataGrwth;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  SubscriptionsRecord? subscrpGrth;
  // Stores action output result for [Backend Call - API (checkOutSessions)] action in Button widget.
  ApiCallResponse? chrgeUserGrwth;
  // Stores action output result for [Backend Call - API (CreateCustomer)] action in Button widget.
  ApiCallResponse? createCustPrem;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  SubscriptionsRecord? subscriptionPremim;
  // Stores action output result for [Backend Call - API (checkOutSessions)] action in Button widget.
  ApiCallResponse? chargeUserPrem;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
